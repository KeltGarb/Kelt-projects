﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2024.1.5),
    on December 18, 2025, at 22:19
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import plugins
plugins.activatePlugins()
prefs.hardware['audioLib'] = 'ptb'
prefs.hardware['audioLatencyMode'] = '3'
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout, hardware
from psychopy.tools import environmenttools
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER, priority)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

import psychopy.iohub as io
from psychopy.hardware import keyboard

# --- Setup global variables (available in all functions) ---
# create a device manager to handle hardware (keyboards, mice, mirophones, speakers, etc.)
deviceManager = hardware.DeviceManager()
# ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
# store info about the experiment session
psychopyVersion = '2024.1.5'
expName = 'UnifiedF1Project418KELTON_GARBER'  # from the Builder filename that created this script
# information about this experiment
expInfo = {
    'participant': f"{randint(0, 999999):06.0f}",
    'Condition': ['1','2'],
    'session': '001',
    'date|hid': data.getDateStr(),
    'expName|hid': expName,
    'psychopyVersion|hid': psychopyVersion,
}

# --- Define some variables which will change depending on pilot mode ---
'''
To run in pilot mode, either use the run/pilot toggle in Builder, Coder and Runner, 
or run the experiment with `--pilot` as an argument. To change what pilot 
#mode does, check out the 'Pilot mode' tab in preferences.
'''
# work out from system args whether we are running in pilot mode
PILOTING = core.setPilotModeFromArgs()
# start off with values from experiment settings
_fullScr = True
_winSize = [1536, 864]
_loggingLevel = logging.getLevel('warning')
# if in pilot mode, apply overrides according to preferences
if PILOTING:
    # force windowed mode
    if prefs.piloting['forceWindowed']:
        _fullScr = False
        # set window size
        _winSize = prefs.piloting['forcedWindowSize']
    # override logging level
    _loggingLevel = logging.getLevel(
        prefs.piloting['pilotLoggingLevel']
    )

def showExpInfoDlg(expInfo):
    """
    Show participant info dialog.
    Parameters
    ==========
    expInfo : dict
        Information about this experiment.
    
    Returns
    ==========
    dict
        Information about this experiment.
    """
    # show participant info dialog
    dlg = gui.DlgFromDict(
        dictionary=expInfo, sortKeys=False, title=expName, alwaysOnTop=True
    )
    if dlg.OK == False:
        core.quit()  # user pressed cancel
    # return expInfo
    return expInfo


def setupData(expInfo, dataDir=None):
    """
    Make an ExperimentHandler to handle trials and saving.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    dataDir : Path, str or None
        Folder to save the data to, leave as None to create a folder in the current directory.    
    Returns
    ==========
    psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    # remove dialog-specific syntax from expInfo
    for key, val in expInfo.copy().items():
        newKey, _ = data.utils.parsePipeSyntax(key)
        expInfo[newKey] = expInfo.pop(key)
    
    # data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
    if dataDir is None:
        dataDir = _thisDir
    filename = u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])
    # make sure filename is relative to dataDir
    if os.path.isabs(filename):
        dataDir = os.path.commonprefix([dataDir, filename])
        filename = os.path.relpath(filename, dataDir)
    
    # an ExperimentHandler isn't essential but helps with data saving
    thisExp = data.ExperimentHandler(
        name=expName, version='',
        extraInfo=expInfo, runtimeInfo=None,
        originPath='C:\\Users\\kelto\\OneDrive\\Documents\\PSY 418\\418 FINAL KELTON GARBER\\UnifiedF1Project418KELTON_GARBER.py',
        savePickle=True, saveWideText=True,
        dataFileName=dataDir + os.sep + filename, sortColumns='time'
    )
    thisExp.setPriority('thisRow.t', priority.CRITICAL)
    thisExp.setPriority('expName', priority.LOW)
    # return experiment handler
    return thisExp


def setupLogging(filename):
    """
    Setup a log file and tell it what level to log at.
    
    Parameters
    ==========
    filename : str or pathlib.Path
        Filename to save log file and data files as, doesn't need an extension.
    
    Returns
    ==========
    psychopy.logging.LogFile
        Text stream to receive inputs from the logging system.
    """
    # this outputs to the screen, not a file
    logging.console.setLevel(_loggingLevel)
    # save a log file for detail verbose info
    logFile = logging.LogFile(filename+'.log', level=_loggingLevel)
    
    return logFile


def setupWindow(expInfo=None, win=None):
    """
    Setup the Window
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    win : psychopy.visual.Window
        Window to setup - leave as None to create a new window.
    
    Returns
    ==========
    psychopy.visual.Window
        Window in which to run this experiment.
    """
    if PILOTING:
        logging.debug('Fullscreen settings ignored as running in pilot mode.')
    
    if win is None:
        # if not given a window to setup, make one
        win = visual.Window(
            size=_winSize, fullscr=_fullScr, screen=1,
            winType='pyglet', allowStencil=False,
            monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
            backgroundImage='', backgroundFit='none',
            blendMode='avg', useFBO=True,
            units='height', 
            checkTiming=False  # we're going to do this ourselves in a moment
        )
    else:
        # if we have a window, just set the attributes which are safe to set
        win.color = [0,0,0]
        win.colorSpace = 'rgb'
        win.backgroundImage = ''
        win.backgroundFit = 'none'
        win.units = 'height'
    if expInfo is not None:
        # get/measure frame rate if not already in expInfo
        if win._monitorFrameRate is None:
            win.getActualFrameRate(infoMsg='Attempting to measure frame rate of screen, please wait...')
        expInfo['frameRate'] = win._monitorFrameRate
    win.mouseVisible = False
    win.hideMessage()
    # show a visual indicator if we're in piloting mode
    if PILOTING and prefs.piloting['showPilotingIndicator']:
        win.showPilotingIndicator()
    
    return win


def setupDevices(expInfo, thisExp, win):
    """
    Setup whatever devices are available (mouse, keyboard, speaker, eyetracker, etc.) and add them to 
    the device manager (deviceManager)
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window in which to run this experiment.
    Returns
    ==========
    bool
        True if completed successfully.
    """
    # --- Setup input devices ---
    ioConfig = {}
    
    # Setup iohub keyboard
    ioConfig['Keyboard'] = dict(use_keymap='psychopy')
    
    ioSession = '1'
    if 'session' in expInfo:
        ioSession = str(expInfo['session'])
    ioServer = io.launchHubServer(window=win, **ioConfig)
    # store ioServer object in the device manager
    deviceManager.ioServer = ioServer
    
    # create a default keyboard (e.g. to check for escape)
    if deviceManager.getDevice('defaultKeyboard') is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='iohub'
        )
    if deviceManager.getDevice('key_resp') is None:
        # initialise key_resp
        key_resp = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp',
        )
    if deviceManager.getDevice('key_resp_14') is None:
        # initialise key_resp_14
        key_resp_14 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_14',
        )
    if deviceManager.getDevice('key_resp_13') is None:
        # initialise key_resp_13
        key_resp_13 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_13',
        )
    if deviceManager.getDevice('key_resp_37') is None:
        # initialise key_resp_37
        key_resp_37 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_37',
        )
    if deviceManager.getDevice('key_resp_2') is None:
        # initialise key_resp_2
        key_resp_2 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_2',
        )
    if deviceManager.getDevice('_key_resp_38') is None:
        # initialise _key_resp_38
        _key_resp_38 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='_key_resp_38',
        )
    if deviceManager.getDevice('key_resp_3') is None:
        # initialise key_resp_3
        key_resp_3 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_3',
        )
    if deviceManager.getDevice('key_resp_39') is None:
        # initialise key_resp_39
        key_resp_39 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_39',
        )
    if deviceManager.getDevice('key_resp_4') is None:
        # initialise key_resp_4
        key_resp_4 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_4',
        )
    if deviceManager.getDevice('key_resp_40') is None:
        # initialise key_resp_40
        key_resp_40 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_40',
        )
    if deviceManager.getDevice('key_resp_5') is None:
        # initialise key_resp_5
        key_resp_5 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_5',
        )
    if deviceManager.getDevice('key_resp_41') is None:
        # initialise key_resp_41
        key_resp_41 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_41',
        )
    if deviceManager.getDevice('key_resp_6') is None:
        # initialise key_resp_6
        key_resp_6 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_6',
        )
    if deviceManager.getDevice('key_resp_42') is None:
        # initialise key_resp_42
        key_resp_42 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_42',
        )
    if deviceManager.getDevice('key_resp_7') is None:
        # initialise key_resp_7
        key_resp_7 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_7',
        )
    if deviceManager.getDevice('key_resp_43') is None:
        # initialise key_resp_43
        key_resp_43 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_43',
        )
    if deviceManager.getDevice('key_resp_8') is None:
        # initialise key_resp_8
        key_resp_8 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_8',
        )
    if deviceManager.getDevice('key_resp_44') is None:
        # initialise key_resp_44
        key_resp_44 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_44',
        )
    if deviceManager.getDevice('key_resp_9') is None:
        # initialise key_resp_9
        key_resp_9 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_9',
        )
    if deviceManager.getDevice('key_resp_45') is None:
        # initialise key_resp_45
        key_resp_45 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_45',
        )
    if deviceManager.getDevice('key_resp_10') is None:
        # initialise key_resp_10
        key_resp_10 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_10',
        )
    if deviceManager.getDevice('key_resp_46') is None:
        # initialise key_resp_46
        key_resp_46 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_46',
        )
    if deviceManager.getDevice('key_resp_11') is None:
        # initialise key_resp_11
        key_resp_11 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_11',
        )
    if deviceManager.getDevice('key_resp_47') is None:
        # initialise key_resp_47
        key_resp_47 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_47',
        )
    if deviceManager.getDevice('key_resp_12') is None:
        # initialise key_resp_12
        key_resp_12 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_12',
        )
    if deviceManager.getDevice('key_resp_38') is None:
        # initialise key_resp_38
        key_resp_38 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_38',
        )
    if deviceManager.getDevice('key_resp_15') is None:
        # initialise key_resp_15
        key_resp_15 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_15',
        )
    if deviceManager.getDevice('key_resp_21') is None:
        # initialise key_resp_21
        key_resp_21 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_21',
        )
    if deviceManager.getDevice('key_resp_18') is None:
        # initialise key_resp_18
        key_resp_18 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_18',
        )
    if deviceManager.getDevice('key_resp_16') is None:
        # initialise key_resp_16
        key_resp_16 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_16',
        )
    if deviceManager.getDevice('key_resp_19') is None:
        # initialise key_resp_19
        key_resp_19 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_19',
        )
    if deviceManager.getDevice('key_resp_17') is None:
        # initialise key_resp_17
        key_resp_17 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_17',
        )
    if deviceManager.getDevice('key_resp_20') is None:
        # initialise key_resp_20
        key_resp_20 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_20',
        )
    if deviceManager.getDevice('key_resp_22') is None:
        # initialise key_resp_22
        key_resp_22 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_22',
        )
    if deviceManager.getDevice('key_resp_24') is None:
        # initialise key_resp_24
        key_resp_24 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_24',
        )
    if deviceManager.getDevice('key_resp_25') is None:
        # initialise key_resp_25
        key_resp_25 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_25',
        )
    if deviceManager.getDevice('key_resp_36') is None:
        # initialise key_resp_36
        key_resp_36 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_36',
        )
    if deviceManager.getDevice('key_resp_26') is None:
        # initialise key_resp_26
        key_resp_26 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_26',
        )
    if deviceManager.getDevice('key_resp_30') is None:
        # initialise key_resp_30
        key_resp_30 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_30',
        )
    if deviceManager.getDevice('key_resp_31') is None:
        # initialise key_resp_31
        key_resp_31 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_31',
        )
    if deviceManager.getDevice('key_resp_27') is None:
        # initialise key_resp_27
        key_resp_27 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_27',
        )
    if deviceManager.getDevice('key_resp_32') is None:
        # initialise key_resp_32
        key_resp_32 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_32',
        )
    if deviceManager.getDevice('key_resp_28') is None:
        # initialise key_resp_28
        key_resp_28 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_28',
        )
    if deviceManager.getDevice('key_resp_33') is None:
        # initialise key_resp_33
        key_resp_33 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_33',
        )
    if deviceManager.getDevice('key_resp_29') is None:
        # initialise key_resp_29
        key_resp_29 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_29',
        )
    if deviceManager.getDevice('key_resp_35') is None:
        # initialise key_resp_35
        key_resp_35 = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_resp_35',
        )
    # return True if completed successfully
    return True

def pauseExperiment(thisExp, win=None, timers=[], playbackComponents=[]):
    """
    Pause this experiment, preventing the flow from advancing to the next routine until resumed.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    timers : list, tuple
        List of timers to reset once pausing is finished.
    playbackComponents : list, tuple
        List of any components with a `pause` method which need to be paused.
    """
    # if we are not paused, do nothing
    if thisExp.status != PAUSED:
        return
    
    # pause any playback components
    for comp in playbackComponents:
        comp.pause()
    # prevent components from auto-drawing
    win.stashAutoDraw()
    # make sure we have a keyboard
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        defaultKeyboard = deviceManager.addKeyboard(
            deviceClass='keyboard',
            deviceName='defaultKeyboard',
            backend='ioHub',
        )
    # run a while loop while we wait to unpause
    while thisExp.status == PAUSED:
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=['escape']):
            endExperiment(thisExp, win=win)
        # flip the screen
        win.flip()
    # if stop was requested while paused, quit
    if thisExp.status == FINISHED:
        endExperiment(thisExp, win=win)
    # resume any playback components
    for comp in playbackComponents:
        comp.play()
    # restore auto-drawn components
    win.retrieveAutoDraw()
    # reset any timers
    for timer in timers:
        timer.reset()


def run(expInfo, thisExp, win, globalClock=None, thisSession=None):
    """
    Run the experiment flow.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    psychopy.visual.Window
        Window in which to run this experiment.
    globalClock : psychopy.core.clock.Clock or None
        Clock to get global time from - supply None to make a new one.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    # mark experiment as started
    thisExp.status = STARTED
    # make sure variables created by exec are available globally
    exec = environmenttools.setExecEnvironment(globals())
    # get device handles from dict of input devices
    ioServer = deviceManager.ioServer
    # get/create a default keyboard (e.g. to check for escape)
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='ioHub'
        )
    eyetracker = deviceManager.getDevice('eyetracker')
    # make sure we're running in the directory for this experiment
    os.chdir(_thisDir)
    # get filename from ExperimentHandler for convenience
    filename = thisExp.dataFileName
    frameTolerance = 0.001  # how close to onset before 'same' frame
    endExpNow = False  # flag for 'escape' or other condition => quit the exp
    # get frame duration from frame rate in expInfo
    if 'frameRate' in expInfo and expInfo['frameRate'] is not None:
        frameDur = 1.0 / round(expInfo['frameRate'])
    else:
        frameDur = 1.0 / 60.0  # could not measure, so guess
    
    # Start Code - component code to be run after the window creation
    
    # --- Initialize components for Routine "introduction" ---
    text_2 = visual.TextStim(win=win, name='text_2',
        text='Welcome to my experiment!\n\nHere you will be making your own racing team to try and win. Do not lose your job or break your budget, it is as simple as that!\n\nPress spacebar to continue when you are ready.',
        font='Arial',
        pos=(0, 0.1), height=0.05, wrapWidth=1.4, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_resp = keyboard.Keyboard(deviceName='key_resp')
    
    # --- Initialize components for Routine "initialize_setup" ---
    # Run 'Begin Experiment' code from code
    # team
    startingBudget = int(140000000)  # salary cap
    budget = startingBudget # assign
    
    team = { # all team info
        'name': 'PSY418/518 Racing Team',
        'budget': startingBudget,
        'engineSupplier': None,
        'driver': None,
        'driverRatings': None,
        'carParts': {},      
        'pitCrew': None,
        'personnel': {},     
        'facilities': {}
    }
    
    # drivers
    driverOptions = {
        'A': {
            'name': 'Driver A',
            'price': 21000000,
            'ratings': {
                'Pace': 88,
                'Experience': 84,
                'Overtaking': 85,
                'Defending': 82,
                'Aggression': 91,
            },
        },
        'B': {
            'name': 'Driver B',
            'price': 10000000,
            'ratings': {
                'Pace': 80,
                'Experience': 75,
                'Overtaking': 77,
                'Defending': 74,
                'Aggression': 68,
            },
        },
        'C': {
            'name': 'Driver C',
            'price': 7500000,
            'ratings': {
                'Pace': 77,
                'Experience': 81,
                'Overtaking': 74,
                'Defending': 73,
                'Aggression': 88,
            },
        },
        'D': {
            'name': 'Driver D',
            'price': 12000000,
            'ratings': {
                'Pace': 82,
                'Experience': 79,
                'Overtaking': 80,
                'Defending': 78,
                'Aggression': 59,
            },
        },
        'E': {
            'name': 'Driver E',
            'price': 8000000,
            'ratings': {
                'Pace': 79,
                'Experience': 69,
                'Overtaking': 76,
                'Defending': 72,
                'Aggression': 94,
            },
        },
        'F': {
            'name': 'Driver F',
            'price': 5500000,
            'ratings': {
                'Pace': 73,
                'Experience': 68,
                'Overtaking': 71,
                'Defending': 69,
                'Aggression': 63,
            },
        },
        'G': {
            'name': 'Driver G',
            'price': 18000000,
            'ratings': {
                'Pace': 85,
                'Experience': 81,
                'Overtaking': 83,
                'Defending': 80,
                'Aggression': 77,
            },
        },
        'H': {
            'name': 'Driver H',
            'price': 25000000,
            'ratings': {
                'Pace': 90,
                'Experience': 87,
                'Overtaking': 88,
                'Defending': 86,
                'Aggression': 85,
            },
        },
        'I': {
            'name': 'Driver I',
            'price': 35000000,
            'ratings': {
                'Pace': 93,
                'Experience': 91,
                'Overtaking': 90,
                'Defending': 89,
                'Aggression': 66,
            },
        },
        'J': {
            'name': 'Driver J',
            'price': 8500000,
            'ratings': {
                'Pace': 78,
                'Experience': 78,
                'Overtaking': 75,
                'Defending': 71,
                'Aggression': 92,
            },
        },
    }
    
    # engines
    engineOptions = {
        'Auronix Powerworks': 25000000,
        'Veltro Dynamics': 22000000,
        'Shenlong Motorsport Engines': 20000000,
        'Harrowfield Engineering': 18000000,
    }
    
    # front wings
    frontWingOptions = {
        'Option 1': 900000,
        'Option 2': 1400000,
        'Option 3': 1600000,
        'Option 4': 2200000,
        'Option 5': 3000000,
    }
    
    # rear wings
    rearWingOptions = {
        'Option 1': 800000,
        'Option 2': 1200000,
        'Option 3': 1500000,
        'Option 4': 2000000,
        'Option 5': 2700000,
    }
    
    # chassis
    chassisOptions = {
        'Option 1': 1300000,
        'Option 2': 1800000,
        'Option 3': 1500000,
        'Option 4': 2000000,
        'Option 5': 2700000,
    }
    
    # underfloors
    underfloorOptions = {
        'Option 1': 1500000,
        'Option 2': 2000000,
        'Option 3': 2700000,
        'Option 4': 3400000,
        'Option 5': 4200000,
    }
    
    # pitcrews
    pitCrewOptions = {
        'Crew A': 1000000,
        'Crew B': 1800000,
        'Crew C': 2500000,
        'Crew D': 3200000,
        'Crew E': 4000000,
    }
    
    # engineers 
    engineerOptions = {
        'Option 1': 4500000,  # Ben Holloway
        'Option 2': 3200000,  # Lucca Mendez
        'Option 3': 2400000,  # Rajan Patel
        'Option 4': 1700000,  # Oskar Nilsson
        'Option 5': 1200000,  # Julien Carriere
    }
    
    # designers
    designerOptions = {
        'Option 1': 6000000,  # Clara Weissmann
        'Option 2': 4800000,  # Tomas Requena
        'Option 3': 3500000,  # Elliot Shaw
        'Option 4': 2400000,  # Hiroshi Tanabe
        'Option 5': 1800000,  # Marta Ricci
    }
    
    # design facilities
    designFacilityOptions = {
        'Option 1': 8000000,
        'Option 2': 14000000,
        'Option 3': 20000000,
        'Option 4': 28000000,
        'Option 5': 35000000,
    }
    
    # production & research facilities
    productionAndResearchFacilityOptions = {
        'Option 1': 10000000,
        'Option 2': 18000000,
        'Option 3': 24000000,
        'Option 4': 32000000,
        'Option 5': 40000000,
    }
    
    # make letter keys consistent throughout choice selections
    letter_to_option = {
        'A': 'Option 1',
        'B': 'Option 2',
        'C': 'Option 3',
        'D': 'Option 4',
        'E': 'Option 5',
    }
    
    frontWingRatings = {} # store ratings
    rearWingRatings = {} # store ratings
    chassisRatings = {} # store ratings
    underfloorRatings = {} # store ratings
    engineRatings = {} # store ratings
    # dev parts for each pause
    Dev1_fw = 0
    Dev1_rw = 0
    Dev1_ch = 0
    Dev1_uf = 0
    Dev1_en = 0
    Dev1_ny = 0
    
    Dev2_fw = 0
    Dev2_rw = 0
    Dev2_ch = 0
    Dev2_uf = 0
    Dev2_en = 0
    Dev2_ny = 0
    
    Dev3_fw = 0
    Dev3_rw = 0
    Dev3_ch = 0
    Dev3_uf = 0
    Dev3_en = 0
    Dev3_ny = 0
    
    Dev4_fw = 0
    Dev4_rw = 0
    Dev4_ch = 0
    Dev4_uf = 0
    Dev4_en = 0
    
    Dev5_fw = 0
    Dev5_rw = 0
    Dev5_ch = 0
    Dev5_uf = 0
    Dev5_en = 0
    
    Dev6_fw = 0
    Dev6_rw = 0
    Dev6_ch = 0
    Dev6_uf = 0
    Dev6_en = 0
    
    
    # 1 = high, 2 = low
    condition = expInfo['Condition']
    boardPressure = condition # assign
    
    if condition == '1': # high pressure condition
        firingThreshold = 30
        confidenceDropRate = 1.5
        fundingMultiplier = 1.3
    else:  # low pressure condition
        firingThreshold = 10
        confidenceDropRate = 0.75
        fundingMultiplier = 1.0
    
    boardConfidence = 100   # starts fully confident in you
    fired = False
    bankrupt = False
    
    season = 1
    # dev for cars
    currentCarDev = {
        'frontWing': 0,
        'rearWing': 0,
        'chassis': 0,
        'underfloor': 0,
        'engine': 0
    }
    nextYearCarDev = 0
    
    # races done at this point
    raceIndexS1 = 0
    
    budgetString = "Current budget: $" + str(team['budget'])
    
    # AI performance
    driverPerf = 80.0   # average-ish driver rating
    carPerf = 80.0      # average-ish car rating
    
    # season 1 points total
    s1SeasonPoints = 0
    s1LastRacePosition = None
    s1LastRacePoints = 0
    
    
    # more AI team performance
    aiBaseline = 160.0   # average total performance of other cars
    aiSpread = 15.0      # how much they vary (bigger = more randomness)
    
    devPointCost = 500000   # cost per dev point used
    
    # text that shows when participant is fired/bankrupt
    endReasonText = "Experiment ended early due to firing or bankruptcy."
    
    # season 2 tracking variables
    raceIndexS2 = 0
    s2LastRacePosition = None
    s2LastRacePoints = 0
    s2SeasonPoints = 0
    
    
    # --- Initialize components for Routine "introduction2" ---
    # Run 'Begin Experiment' code from code_3
    season = 1 # current season
    season1Message = ( # intro to season
        "SEASON 1\n\n"
        f"Team: {team['name']}\n"
        f"Starting budget: ${team['budget']:,}\n\n"
        "You will now invest in your driver, car, personnel, and facilities.\n"
        "Press spacebar to continue."
    )
    
    key_resp_14 = keyboard.Keyboard(deviceName='key_resp_14')
    text_15 = visual.TextStim(win=win, name='text_15',
        text=season1Message,
        font='Arial',
        pos=(0, 0.1), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    
    # --- Initialize components for Routine "team_instructions" ---
    # Run 'Begin Experiment' code from code_2
    condition = expInfo['Condition'] # assign
    
    if condition == '1': # condition 1 text
        pressureText = (
        "High Pressure\n\n"
        "Your bosses have VERY high expectations and demands.\n\n"
        "They expect you to have good results across BOTH seasons.\n"
        "Their confidence in your ability drops very quickly if you have poor performances.\n"
        "You are at high risk of losing your job if you have poor results.\n\n"
        "Press spacebar to continue"
        )
    else: 
        pressureText = ( # condition 2 text
        "Low Pressure\n\n"
        "Your bosses do not have VERY high expectations and demands.\n\n"
        "They do still care about your results across BOTH seasons...\n"
        "But they are accepting of inconsistent performances.\n"
        "Their confidence in your ability slowly declines when you have poor results.\n"
        "Press spacebar to continue"
        )
    text_14 = visual.TextStim(win=win, name='text_14',
        text='',
        font='Arial',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    key_resp_13 = keyboard.Keyboard(deviceName='key_resp_13')
    
    # --- Initialize components for Routine "pressureCondition" ---
    
    # --- Initialize components for Routine "text1" ---
    text_50 = visual.TextStim(win=win, name='text_50',
        text='Now, pick a production and research facility for your team! This facility does the research and testing of car part concepts. You have 5 production and research facilities available, please pick one of the following. When you are ready to select one, press the letter available. Each facility has a price, in dollars, plus ratings.\n\nPress spacebar to continue.',
        font='Arial',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_resp_37 = keyboard.Keyboard(deviceName='key_resp_37')
    
    # --- Initialize components for Routine "driverChoice" ---
    text_3 = visual.TextStim(win=win, name='text_3',
        text="Your starting budget is 140 million dollars.\n\nChoose ONE of the following drivers. Each driver has a price, in dollars, plus ratings. \n\nRatings go from 1 - 100 across 5 attributes.\nPace = driver quickness\nExperience = intelligence\nOvertaking = skill at passing other cars\nDefending = skill at preventing other cars from passing them\nAggression = tendency to make bold and risky moves\n\nPress the letter affiliated with the driver you want to select:\n\nA - 'Driver A': 21,000,000\nPace: 88, Experience: 84, Overtaking: 85, Defending: 82, Aggression: 91\n\nB - 'Driver B': 10,000,000\nPace: 80, Experience: 75, Overtaking: 77, Defending: 74, Aggression: 68\n\nC - 'Driver C': 7,500,000\nPace: 77, Experience: 81, Overtaking: 74, Defending: 73, Aggression: 88\n\nD - 'Driver D': 12,000,000\nPace: 82, Experience: 79, Overtaking: 80, Defending: 78, Aggression: 59\n\nE - 'Driver E': 8,000,000\nPace: 79, Experience: 69, Overtaking: 76, Defending: 72, Aggression: 94\n\nF - 'Driver F': 5,500,000\nPace: 73, Experience: 68, Overtaking: 71, Defending: 69, Aggression: 63\n\nG - 'Driver G': 18,000,000\nPace: 85, Experience: 81, Overtaking: 83, Defending: 80, Aggression: 77\n\nH - 'Driver H': 25,000,000\nPace: 90, Experience: 87, Overtaking: 88, Defending: 86, Aggression: 85\n\nI - 'Driver I': 35,000,000\nPace: 93, Experience: 91, Overtaking: 90, Defending: 89, Aggression: 66\n\nJ - 'Driver J': 8,500,000\nPace: 78, Experience: 78, Overtaking: 75, Defending: 71, Aggression: 92",
        font='Arial',
        pos=(0, 0), height=0.02, wrapWidth=1.4, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    key_resp_2 = keyboard.Keyboard(deviceName='key_resp_2')
    text_16 = visual.TextStim(win=win, name='text_16',
        text='',
        font='Arial',
        pos=(0,-.7), height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    
    # --- Initialize components for Routine "text2" ---
    text_51 = visual.TextStim(win=win, name='text_51',
        text='Now, pick an engine for your car! Uou have 4 engines available, please pick one of the following. When you are ready to select one, press the letter available.  Each engine has a price, in dollars, plus ratings. ',
        font='Arial',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    _key_resp_38 = keyboard.Keyboard(deviceName='_key_resp_38')
    
    # --- Initialize components for Routine "engineChoice" ---
    # Run 'Begin Experiment' code from code_5
    
    
    text_4 = visual.TextStim(win=win, name='text_4',
        text="Ratings go from 1 - 100 across 3 attributes.\nTop Speed = engine's maximum speed\nAcceleration = rate of how fast the engine accelerates\nCooling = rate of how the engine stays cool (FYI: higher number = better performance)\n\nA - ENGINE 1\nTop Speed: 93, Acceleration: 91, Engine Cooling: 88\n\nB - ENGINE 2\nTop Speed: 90, Acceleration: 89, Engine Cooling: 83\n\nC - ENGINE 3\nTop Speed: 87, Acceleration: 86, Engine Cooling: 85\n\nD - ENGINE 4\nTop Speed: 83, Acceleration: 82, Engine Cooling: 80",
        font='Arial',
        pos=(0, 0), height=0.03, wrapWidth=1.4, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    key_resp_3 = keyboard.Keyboard(deviceName='key_resp_3')
    text_17 = visual.TextStim(win=win, name='text_17',
        text='',
        font='Arial',
        pos=(0, -0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    
    # --- Initialize components for Routine "text3" ---
    key_resp_39 = keyboard.Keyboard(deviceName='key_resp_39')
    text_52 = visual.TextStim(win=win, name='text_52',
        text='Now, pick a front wing for your car! You have 5 front wings available, please pick one of the following. When you are ready to select one, press the letter available. Each front wing has a price, in dollars, plus ratings.',
        font='Arial',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    
    # --- Initialize components for Routine "frontWingChoice" ---
    text_5 = visual.TextStim(win=win, name='text_5',
        text='Ratings go from 1 - 100 across 4 attributes.\nAcceleration = rate of how fast the car accelerates\nCorner Speed = rate of how fast the car moves through turns\nStraightline Speed = rate of how fast the car moves at a straight line\nAerodynamics = rate of how aerodynamic the car is\n\nA - Option 1: 900,000\nAcceleration: 76, Corner Speed: 77, Straightline Speed: 79, Aerodynamics: 78\n\nB - Option 2: 1,400,000\nAcceleration: 78, Corner Speed: 82, Straightline Speed: 76, Aerodynamics: 81\n\nC - Option 3: 1,600,000\nAcceleration: 80, Corner Speed: 78, Straightline Speed: 84, Aerodynamics: 80\n\nD - Option 4: 2,200,000\nAcceleration: 85, Corner Speed: 86, Straightline Speed: 81, Aerodynamics: 85\n\nE - Option 5: 3,000,000\nAcceleration: 85, Corner Speed: 88, Straightline Speed: 87, Aerodynamics: 89',
        font='Arial',
        pos=(0, 0), height=0.03, wrapWidth=1.4, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    key_resp_4 = keyboard.Keyboard(deviceName='key_resp_4')
    text_18 = visual.TextStim(win=win, name='text_18',
        text='',
        font='Arial',
        pos=(0, -0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    
    # --- Initialize components for Routine "text4" ---
    key_resp_40 = keyboard.Keyboard(deviceName='key_resp_40')
    text_53 = visual.TextStim(win=win, name='text_53',
        text='Now, pick a rear wing for your car! You have 5 rear wings available, please pick one of the following. When you are ready to select one, press the letter available. Each rear wing has a price, in dollars, plus ratings.',
        font='Arial',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    
    # --- Initialize components for Routine "rearWingChoice" ---
    text_6 = visual.TextStim(win=win, name='text_6',
        text='Ratings go from 1 - 100 across 4 attributes.\nAcceleration = rate of how fast the engine accelerates\nCorner Speed = rate of how fast the car moves through turns\nStraightline Speed = rate of how fast the car moves at a straight line\nAerodynamics = rate of how aerodynamic the car is\n\nA - Option 1: 800,000\nAcceleration: 75, Corner Speed: 77, Straightline Speed: 78, Aerodynamics: 76\n\nB - Option 2: 1,200,000\nAcceleration: 78, Corner Speed: 84, Straightline Speed: 75, Aerodynamics: 82\n\nC - Option 3: 1,500,000\nAcceleration: 79, Corner Speed: 78, Straightline Speed: 83, Aerodynamics: 80\n\nD - Option 4: 2,000,000\nAcceleration: 82, Corner Speed: 87, Straightline Speed: 80, Aerodynamics: 85\n\nE - Option 5: 2,700,000\nAcceleration: 86, Corner Speed: 90, Straightline Speed: 86, Aerodynamics: 89',
        font='Arial',
        pos=(0, 0), height=0.03, wrapWidth=1.4, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    key_resp_5 = keyboard.Keyboard(deviceName='key_resp_5')
    text_19 = visual.TextStim(win=win, name='text_19',
        text='',
        font='Arial',
        pos=(0, -0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    
    # --- Initialize components for Routine "text5" ---
    key_resp_41 = keyboard.Keyboard(deviceName='key_resp_41')
    text_54 = visual.TextStim(win=win, name='text_54',
        text='Now, pick a chassis for your car! You have 5 chassis available, please pick one of the following. When you are ready to select one, press the letter available. Each chassis has a price, in dollars, plus ratings.',
        font='Arial',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    
    # --- Initialize components for Routine "chassisChoice" ---
    text_7 = visual.TextStim(win=win, name='text_7',
        text='Ratings go from 1 - 100 across 3 attributes.\nTop Speed = maximum speed\nAcceleration = rate of how fast the engine accelerates\nEngine Cooling = rate of how well your engine does not overheat (higher value = better)\n\nA - Option 1: 1,300,000\nTop Speed: 77, Acceleration: 75, Engine Cooling: 78\n\nB - Option 2: 1,800,000\nTop Speed: 81, Acceleration: 79, Engine Cooling: 81\n\nC - Option 3: 1,500,000\nTop Speed: 84, Acceleration: 82, Engine Cooling: 84\n\nD - Option 4: 2,000,000\nTop Speed: 87, Acceleration: 85, Engine Cooling: 87\n\nE - Option 5: 2,700,000\nTop Speed: 90, Acceleration: 88, Engine Cooling: 90',
        font='Arial',
        pos=(0, 0), height=0.03, wrapWidth=1.4, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    key_resp_6 = keyboard.Keyboard(deviceName='key_resp_6')
    text_20 = visual.TextStim(win=win, name='text_20',
        text='',
        font='Arial',
        pos=(0, -0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    
    # --- Initialize components for Routine "text6" ---
    key_resp_42 = keyboard.Keyboard(deviceName='key_resp_42')
    text_55 = visual.TextStim(win=win, name='text_55',
        text='Now, pick an underfloor for your car! You have 5 underfloors available, please pick one of the following. When you are ready to select one, press the letter available. Each underfloor has a price, in dollars, plus ratings.',
        font='Arial',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    
    # --- Initialize components for Routine "underfloorChoice" ---
    text_8 = visual.TextStim(win=win, name='text_8',
        text='Ratings go from 1 - 100 across 2 attributes.\nCorner Speed = rate of how fast the car moves through turns\nAerodynamics = rate of how aerodynamic the car is\n\nA - Option 1: 1,500,000\nCorner Speed: 78, Aerodynamics: 77\n\nB - Option 2: 2,000,000\nCorner Speed: 82, Aerodynamics: 81\n\nC - Option 3: 2,700,000\nCorner Speed: 85, Aerodynamics: 84\n\nD - Option 4: 3,400,000\nCorner Speed: 88, Aerodynamics: 87\n\nE - Option 5: 4,200,000\nCorner Speed: 91, Aerodynamics: 90',
        font='Arial',
        pos=(0, 0), height=0.03, wrapWidth=1.4, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    key_resp_7 = keyboard.Keyboard(deviceName='key_resp_7')
    text_21 = visual.TextStim(win=win, name='text_21',
        text='',
        font='Arial',
        pos=(0, -0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    
    # --- Initialize components for Routine "text7" ---
    key_resp_43 = keyboard.Keyboard(deviceName='key_resp_43')
    text_56 = visual.TextStim(win=win, name='text_56',
        text='Now, pick a pit crew for your team! The pit crew replaces tires on your car during a race, and the faster they replace tires during a race, the quicker your driver finishes the race! You have 5 crews available, please pick one of the following. When you are ready to select one, press the letter available. Each pitcrew has a price, in dollars, plus ratings.',
        font='Arial',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    
    # --- Initialize components for Routine "pitCrewChoice" ---
    text_9 = visual.TextStim(win=win, name='text_9',
        text='Ratings go from 1 - 100 across 2 attributes.\nSpeed = how fast they switch tires\nConsistency = rate of which they do not make errors\n\nA - Crew 1: 1,000,000\nSpeed: 75, Consistency: 76\n\nB - Crew 2: 1,800,000\nSpeed: 79, Consistency: 80\n\nC - Crew 3: 2,500,000\nSpeed: 82, Consistency: 83\n\nD - Crew 4: 3,200,000\nSpeed: 86, Consistency: 87 \n\nE - Crew 5: 4,000,000\nSpeed: 89, Consistency: 90',
        font='Arial',
        pos=(0, 0), height=0.03, wrapWidth=1.4, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    key_resp_8 = keyboard.Keyboard(deviceName='key_resp_8')
    text_22 = visual.TextStim(win=win, name='text_22',
        text='',
        font='Arial',
        pos=(0, -0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    
    # --- Initialize components for Routine "text8" ---
    key_resp_44 = keyboard.Keyboard(deviceName='key_resp_44')
    text_57 = visual.TextStim(win=win, name='text_57',
        text='Now, pick an engineer for your team! They are in charge of helping your team make the car parts. You have 5 engineers available, please pick one of the following. When you are ready to select one, press the letter available. Each engineer has a price, in dollars, plus ratings.',
        font='Arial',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    
    # --- Initialize components for Routine "engineerChoice" ---
    text_10 = visual.TextStim(win=win, name='text_10',
        text='Ratings go from 1 - 100 across 2 attributes.\nReliability Expertise = knowledge in creating reliable parts\nPart Efficacy = knowledge of making parts work as intended\n\nA - Ben Holloway: 4,500,000\nReliability Expertise: 90, Part Efficacy: 88\n\nB - Lucca Mendez: 3,200,000\nReliability Expertise: 83, Part Efficacy: 81\n\nC - Rajan Patel: 2,400,000\nReliability Expertise: 78, Part Efficacy: 77\n\nD - Oskar Nilsson: 1,700,000\nReliability Expertise: 72, Part Efficacy: 74\n\nE - Julien Carriere: 1,200,000\nReliability Expertise: 68, Part Efficacy: 70',
        font='Arial',
        pos=(0, 0), height=0.03, wrapWidth=1.4, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    key_resp_9 = keyboard.Keyboard(deviceName='key_resp_9')
    text_23 = visual.TextStim(win=win, name='text_23',
        text='',
        font='Arial',
        pos=(0, -0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    
    # --- Initialize components for Routine "text9" ---
    key_resp_45 = keyboard.Keyboard(deviceName='key_resp_45')
    text_58 = visual.TextStim(win=win, name='text_58',
        text='Now, pick a designer for your team! They are in charge of physically creating the parts the engineers want to be made. You have 5 designers available, please pick one of the following. When you are ready to select one, press the letter available. Each designer has a price, in dollars, plus ratings.',
        font='Arial',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    
    # --- Initialize components for Routine "designerChoice" ---
    text_11 = visual.TextStim(win=win, name='text_11',
        text='Ratings go from 1 - 100 across 2 attributes.\nAerodynamic Expertise = understanding of aerodynamic principles\nSpeed Expertise = ability to produce parts quickly\n\nA - Clara Weissmann: 6,000,000 \nAerodynamic Expertise: 92, Speed Expertise: 89 \n\nB - Tomas Requena: 4,800,000\nAerodynamic Expertise: 85, Speed Expertise: 83 \n\nC - Elliot Shaw: 3,500,000\nAerodynamic Expertise: 79, Speed Expertise: 78 \n\nD - Hiroshi Tanabe: 2,400,000\nAerodynamic Expertise: 73, Speed Expertise: 75\n\nE - Marta Ricci: 1,800,000\nAerodynamic Expertise: 70, Speed Expertise: 72',
        font='Arial',
        pos=(0, 0), height=0.03, wrapWidth=1.4, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    key_resp_10 = keyboard.Keyboard(deviceName='key_resp_10')
    text_24 = visual.TextStim(win=win, name='text_24',
        text='',
        font='Arial',
        pos=(0, -0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    
    # --- Initialize components for Routine "text10" ---
    key_resp_46 = keyboard.Keyboard(deviceName='key_resp_46')
    text_59 = visual.TextStim(win=win, name='text_59',
        text="Now, pick a design facility for your team! This facility creates your car's parts. You have 5 design facilities available, please pick one of the following. When you are ready to select one, press the letter available. Each design facility has a price, in dollars, plus ratings.",
        font='Arial',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    
    # --- Initialize components for Routine "designFacililityChoice" ---
    text_12 = visual.TextStim(win=win, name='text_12',
        text='Ratings go from 1 - 100 across 2 attributes.\nPart Efficacy = how well the part works as intended during research\nEfficiency = rate of productivity in constructing the parts\n\nA - Option A: 8,000,000\nPart Efficacy: 70, Efficiency: 68 \n\nB - Option B: 14,000,000\nPart Efficacy: 82, Efficiency: 81 \n\nC - Option C: 20,000,000\nPart Efficacy: 86, Efficiency: 85 \n\nD - Option D: 28,000,000\nPart Efficacy: 90, Efficiency: 88 \n\nE - Option E: 35,000,000\nPart Efficacy: 93, Efficiency: 91',
        font='Arial',
        pos=(0, 0), height=0.03, wrapWidth=1.4, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    key_resp_11 = keyboard.Keyboard(deviceName='key_resp_11')
    text_25 = visual.TextStim(win=win, name='text_25',
        text='',
        font='Arial',
        pos=(0, -0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    
    # --- Initialize components for Routine "text11" ---
    key_resp_47 = keyboard.Keyboard(deviceName='key_resp_47')
    text_60 = visual.TextStim(win=win, name='text_60',
        text="Now, pick a research and development facility for your team! This facility creates your car's parts. You have 5 facilities available, please pick one of the following. When you are ready to select one, press the letter available. Each design facility has a price, in dollars, plus ratings.\n\n",
        font='Arial',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    
    # --- Initialize components for Routine "r_dFacilityChoice" ---
    text_13 = visual.TextStim(win=win, name='text_13',
        text='Ratings go from 1 - 100 for one attribute.\nPart Potential = ability to effectively find high levels of car and part potential\n\nA - Option 1: 10,000,000 \nPart Potential: 72\n\nB - Option 2: 18,000,000\nPart Potential: 83\n\nC - Option 3: 24,000,000\nPart Potential: 87\n\nD - Option 4: 32,000,000\nPart Potential: 91\n\nE - Option 5: 40,000,000\nPart Potential: 95',
        font='Arial',
        pos=(0, 0), height=0.03, wrapWidth=1.4, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    key_resp_12 = keyboard.Keyboard(deviceName='key_resp_12')
    text_26 = visual.TextStim(win=win, name='text_26',
        text='',
        font='Arial',
        pos=(0, -0.4), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    
    # --- Initialize components for Routine "S1Preview" ---
    text_61 = visual.TextStim(win=win, name='text_61',
        text='Now that you have formed your team, lets get racing!\n\nPress spacebar to continue.',
        font='Arial',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_resp_38 = keyboard.Keyboard(deviceName='key_resp_38')
    
    # --- Initialize components for Routine "RaceS1Pt1" ---
    text_27 = visual.TextStim(win=win, name='text_27',
        text='',
        font='Arial',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    key_resp_15 = keyboard.Keyboard(deviceName='key_resp_15')
    
    # --- Initialize components for Routine "RaceResultsS1" ---
    key_resp_21 = keyboard.Keyboard(deviceName='key_resp_21')
    text_32 = visual.TextStim(win=win, name='text_32',
        text='',
        font='Arial',
        pos=(0, 0.1), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    text_36 = visual.TextStim(win=win, name='text_36',
        text='',
        font='Arial',
        pos=(0, -0.25), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    
    # --- Initialize components for Routine "devPause1" ---
    text_30 = visual.TextStim(win=win, name='text_30',
        text='SEASON 1 - DEVELOPMENT STOP 1\n\nYou have 8 development points to assign.\n\nEach key press (A–F) assigns 1 point.\nYou can use the same letter multiple times\nand spread points across as many areas as you want.\n\nMappings:\n  A = Front wing\n  B = Rear wing\n  C = Chassis\n  D = Underfloor\n  E = Engine\n  F = Research for NEXT season\n\nPress up to 8 keys (A–F) in total.\nWhen you are satisfied, press enter to continue.\n',
        font='Arial',
        pos=(0, 0), height=0.03, wrapWidth=1.4, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    key_resp_18 = keyboard.Keyboard(deviceName='key_resp_18')
    
    # --- Initialize components for Routine "RaceS1Pt2" ---
    text_28 = visual.TextStim(win=win, name='text_28',
        text='',
        font='Arial',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    key_resp_16 = keyboard.Keyboard(deviceName='key_resp_16')
    
    # --- Initialize components for Routine "RaceResultsS1" ---
    key_resp_21 = keyboard.Keyboard(deviceName='key_resp_21')
    text_32 = visual.TextStim(win=win, name='text_32',
        text='',
        font='Arial',
        pos=(0, 0.1), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    text_36 = visual.TextStim(win=win, name='text_36',
        text='',
        font='Arial',
        pos=(0, -0.25), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    
    # --- Initialize components for Routine "devPause2" ---
    teXt_31 = visual.TextStim(win=win, name='teXt_31',
        text='SEASON 1 - DEVELOPMENT STOP 2\n\nYou again have 8 development points to assign.\n\nEach key press (A–F) assigns 1 point.\nYou can use the same letter multiple times\nand spread points across as many areas as you want.\n\nMappings:\n  A = Front wing\n  B = Rear wing\n  C = Chassis\n  D = Underfloor\n  E = Engine\n  F = Research for NEXT season\n\nPress up to 8 keys (A–F) in total.\nWhen you are satisfied, press enter to continue.\n',
        font='Arial',
        pos=(0, 0), height=0.03, wrapWidth=1.4, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    key_resp_19 = keyboard.Keyboard(deviceName='key_resp_19')
    
    # --- Initialize components for Routine "RaceS1Pt3" ---
    text_29 = visual.TextStim(win=win, name='text_29',
        text='',
        font='Arial',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    key_resp_17 = keyboard.Keyboard(deviceName='key_resp_17')
    
    # --- Initialize components for Routine "RaceResultsS1" ---
    key_resp_21 = keyboard.Keyboard(deviceName='key_resp_21')
    text_32 = visual.TextStim(win=win, name='text_32',
        text='',
        font='Arial',
        pos=(0, 0.1), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    text_36 = visual.TextStim(win=win, name='text_36',
        text='',
        font='Arial',
        pos=(0, -0.25), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    
    # --- Initialize components for Routine "devPause3" ---
    text_31 = visual.TextStim(win=win, name='text_31',
        text="SEASON 1 - DEVELOPMENT STOP 3 (FINAL)\n\nThis is your FINAL development window before Season 2.\n\nYou must focus on either your current car OR next year's car. \nMeaning, you can pick and combination of 8 points going for options A-E, or you can have all 8 points go to option F.\n\nMappings:\n  A = Front wing (this season)\n  B = Rear wing (this season)\n  C = Chassis (this season)\n  D = Underfloor (this season)\n  E = Engine (this season)\n  F = Research NEXT season's car\n\nPress A–F to choose your focus.\nIf you change your mind, press a different letter the LAST letter you press will be used.\n\nWhen you are ready, press enter to confirm.\n",
        font='Arial',
        pos=(0, 0), height=0.03, wrapWidth=1.4, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    key_resp_20 = keyboard.Keyboard(deviceName='key_resp_20')
    
    # --- Initialize components for Routine "RaceS1Pt4" ---
    text_33 = visual.TextStim(win=win, name='text_33',
        text='',
        font='Arial',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    key_resp_22 = keyboard.Keyboard(deviceName='key_resp_22')
    
    # --- Initialize components for Routine "RaceResultsS1" ---
    key_resp_21 = keyboard.Keyboard(deviceName='key_resp_21')
    text_32 = visual.TextStim(win=win, name='text_32',
        text='',
        font='Arial',
        pos=(0, 0.1), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    text_36 = visual.TextStim(win=win, name='text_36',
        text='',
        font='Arial',
        pos=(0, -0.25), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    
    # --- Initialize components for Routine "season1Summary" ---
    key_resp_24 = keyboard.Keyboard(deviceName='key_resp_24')
    text_35 = visual.TextStim(win=win, name='text_35',
        text='',
        font='Arial',
        pos=(0, 0.1), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    
    # --- Initialize components for Routine "season2Introduction" ---
    text_37 = visual.TextStim(win=win, name='text_37',
        text='',
        font='Arial',
        pos=(0, 0), height=0.03, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    key_resp_25 = keyboard.Keyboard(deviceName='key_resp_25')
    
    # --- Initialize components for Routine "season2DevPts" ---
    key_resp_36 = keyboard.Keyboard(deviceName='key_resp_36')
    text_49 = visual.TextStim(win=win, name='text_49',
        text='',
        font='Arial',
        pos=(0, 0), height=0.04, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    
    # --- Initialize components for Routine "RaceS2Pt1" ---
    key_resp_26 = keyboard.Keyboard(deviceName='key_resp_26')
    text_38 = visual.TextStim(win=win, name='text_38',
        text='',
        font='Arial',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    
    # --- Initialize components for Routine "RaceResultsS2" ---
    text_42 = visual.TextStim(win=win, name='text_42',
        text='',
        font='Arial',
        pos=(0, 0.1), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    text_43 = visual.TextStim(win=win, name='text_43',
        text='',
        font='Arial',
        pos=(0, -0.25), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    key_resp_30 = keyboard.Keyboard(deviceName='key_resp_30')
    
    # --- Initialize components for Routine "devPause4" ---
    key_resp_31 = keyboard.Keyboard(deviceName='key_resp_31')
    text_44 = visual.TextStim(win=win, name='text_44',
        text='SEASON 2 - DEVELOPMENT STOP 1\n\nYou have 8 development points to assign.\n\nEach key press (A-E) assigns 1 point.\nYou can use the same letter multiple times\nand spread points across as many areas as you want.\n\nMappings:\n  A = Front wing\n  B = Rear wing\n  C = Chassis\n  D = Underfloor\n  E = Engine\n\nPress up to 8 keys (A–E) in total.\nWhen you are satisfied, press enter to continue.\n',
        font='Arial',
        pos=(0, 0), height=0.03, wrapWidth=1.4, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    
    # --- Initialize components for Routine "RaceS2Pt2" ---
    key_resp_27 = keyboard.Keyboard(deviceName='key_resp_27')
    text_39 = visual.TextStim(win=win, name='text_39',
        text='',
        font='Arial',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    
    # --- Initialize components for Routine "RaceResultsS2" ---
    text_42 = visual.TextStim(win=win, name='text_42',
        text='',
        font='Arial',
        pos=(0, 0.1), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    text_43 = visual.TextStim(win=win, name='text_43',
        text='',
        font='Arial',
        pos=(0, -0.25), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    key_resp_30 = keyboard.Keyboard(deviceName='key_resp_30')
    
    # --- Initialize components for Routine "devPause5" ---
    text_45 = visual.TextStim(win=win, name='text_45',
        text='SEASON 2 - DEVELOPMENT STOP 2\n\nYou have 8 development points to assign.\n\nEach key press (A-E) assigns 1 point.\nYou can use the same letter multiple times\nand spread points across as many areas as you want.\n\nMappings:\n  A = Front wing\n  B = Rear wing\n  C = Chassis\n  D = Underfloor\n  E = Engine\n\nPress up to 8 keys (A–E) in total.\nWhen you are satisfied, press enter to continue.\n',
        font='Arial',
        pos=(0, 0), height=0.03, wrapWidth=1.4, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    key_resp_32 = keyboard.Keyboard(deviceName='key_resp_32')
    
    # --- Initialize components for Routine "RaceS2Pt3" ---
    key_resp_28 = keyboard.Keyboard(deviceName='key_resp_28')
    text_40 = visual.TextStim(win=win, name='text_40',
        text='',
        font='Arial',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    
    # --- Initialize components for Routine "RaceResultsS2" ---
    text_42 = visual.TextStim(win=win, name='text_42',
        text='',
        font='Arial',
        pos=(0, 0.1), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    text_43 = visual.TextStim(win=win, name='text_43',
        text='',
        font='Arial',
        pos=(0, -0.25), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    key_resp_30 = keyboard.Keyboard(deviceName='key_resp_30')
    
    # --- Initialize components for Routine "devPause6" ---
    key_resp_33 = keyboard.Keyboard(deviceName='key_resp_33')
    text_46 = visual.TextStim(win=win, name='text_46',
        text='SEASON 2 - DEVELOPMENT STOP 3 (FINA:)\n\nYou have 8 development points to assign.\n\nEach key press (A-E) assigns 1 point.\nYou can use the same letter multiple times\nand spread points across as many areas as you want.\n\nMappings:\n  A = Front wing\n  B = Rear wing\n  C = Chassis\n  D = Underfloor\n  E = Engine\n\nPress up to 8 keys (A–E) in total.\nWhen you are satisfied, press enter to continue.\n',
        font='Arial',
        pos=(0, 0), height=0.03, wrapWidth=1.4, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    
    # --- Initialize components for Routine "RaceS2Pt4" ---
    key_resp_29 = keyboard.Keyboard(deviceName='key_resp_29')
    text_41 = visual.TextStim(win=win, name='text_41',
        text='',
        font='Arial',
        pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    
    # --- Initialize components for Routine "RaceResultsS2" ---
    text_42 = visual.TextStim(win=win, name='text_42',
        text='',
        font='Arial',
        pos=(0, 0.1), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    text_43 = visual.TextStim(win=win, name='text_43',
        text='',
        font='Arial',
        pos=(0, -0.25), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    key_resp_30 = keyboard.Keyboard(deviceName='key_resp_30')
    
    # --- Initialize components for Routine "season2Summary" ---
    key_resp_35 = keyboard.Keyboard(deviceName='key_resp_35')
    text_48 = visual.TextStim(win=win, name='text_48',
        text='',
        font='Arial',
        pos=(0, 0.1), height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    
    # --- Initialize components for Routine "conclusion" ---
    text = visual.TextStim(win=win, name='text',
        text="That's all!\nThank you for participating!",
        font='Arial',
        pos=(0, 0.1), height=0.05, wrapWidth=1.4, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    
    # create some handy timers
    
    # global clock to track the time since experiment started
    if globalClock is None:
        # create a clock if not given one
        globalClock = core.Clock()
    if isinstance(globalClock, str):
        # if given a string, make a clock accoridng to it
        if globalClock == 'float':
            # get timestamps as a simple value
            globalClock = core.Clock(format='float')
        elif globalClock == 'iso':
            # get timestamps in ISO format
            globalClock = core.Clock(format='%Y-%m-%d_%H:%M:%S.%f%z')
        else:
            # get timestamps in a custom format
            globalClock = core.Clock(format=globalClock)
    if ioServer is not None:
        ioServer.syncClock(globalClock)
    logging.setDefaultClock(globalClock)
    # routine timer to track time remaining of each (possibly non-slip) routine
    routineTimer = core.Clock()
    win.flip()  # flip window to reset last flip timer
    # store the exact time the global clock started
    expInfo['expStart'] = data.getDateStr(
        format='%Y-%m-%d %Hh%M.%S.%f %z', fractionalSecondDigits=6
    )
    
    # --- Prepare to start Routine "introduction" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('introduction.started', globalClock.getTime(format='float'))
    # create starting attributes for key_resp
    key_resp.keys = []
    key_resp.rt = []
    _key_resp_allKeys = []
    # keep track of which components have finished
    introductionComponents = [text_2, key_resp]
    for thisComponent in introductionComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "introduction" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_2* updates
        
        # if text_2 is starting this frame...
        if text_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_2.frameNStart = frameN  # exact frame index
            text_2.tStart = t  # local t and not account for scr refresh
            text_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_2.started')
            # update status
            text_2.status = STARTED
            text_2.setAutoDraw(True)
        
        # if text_2 is active this frame...
        if text_2.status == STARTED:
            # update params
            pass
        
        # *key_resp* updates
        waitOnFlip = False
        
        # if key_resp is starting this frame...
        if key_resp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp.frameNStart = frameN  # exact frame index
            key_resp.tStart = t  # local t and not account for scr refresh
            key_resp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp.started')
            # update status
            key_resp.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp.status == STARTED and not waitOnFlip:
            theseKeys = key_resp.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_allKeys.extend(theseKeys)
            if len(_key_resp_allKeys):
                key_resp.keys = _key_resp_allKeys[-1].name  # just the last key pressed
                key_resp.rt = _key_resp_allKeys[-1].rt
                key_resp.duration = _key_resp_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in introductionComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "introduction" ---
    for thisComponent in introductionComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('introduction.stopped', globalClock.getTime(format='float'))
    # check responses
    if key_resp.keys in ['', [], None]:  # No response was made
        key_resp.keys = None
    thisExp.addData('key_resp.keys',key_resp.keys)
    if key_resp.keys != None:  # we had a response
        thisExp.addData('key_resp.rt', key_resp.rt)
        thisExp.addData('key_resp.duration', key_resp.duration)
    thisExp.nextEntry()
    # the Routine "introduction" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "initialize_setup" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('initialize_setup.started', globalClock.getTime(format='float'))
    # keep track of which components have finished
    initialize_setupComponents = []
    for thisComponent in initialize_setupComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "initialize_setup" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in initialize_setupComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "initialize_setup" ---
    for thisComponent in initialize_setupComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('initialize_setup.stopped', globalClock.getTime(format='float'))
    thisExp.nextEntry()
    # the Routine "initialize_setup" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "introduction2" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('introduction2.started', globalClock.getTime(format='float'))
    # create starting attributes for key_resp_14
    key_resp_14.keys = []
    key_resp_14.rt = []
    _key_resp_14_allKeys = []
    # keep track of which components have finished
    introduction2Components = [key_resp_14, text_15]
    for thisComponent in introduction2Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "introduction2" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *key_resp_14* updates
        waitOnFlip = False
        
        # if key_resp_14 is starting this frame...
        if key_resp_14.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_14.frameNStart = frameN  # exact frame index
            key_resp_14.tStart = t  # local t and not account for scr refresh
            key_resp_14.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_14, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp_14.started')
            # update status
            key_resp_14.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_14.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_14.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_14.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_14.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_14_allKeys.extend(theseKeys)
            if len(_key_resp_14_allKeys):
                key_resp_14.keys = _key_resp_14_allKeys[-1].name  # just the last key pressed
                key_resp_14.rt = _key_resp_14_allKeys[-1].rt
                key_resp_14.duration = _key_resp_14_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # *text_15* updates
        
        # if text_15 is starting this frame...
        if text_15.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_15.frameNStart = frameN  # exact frame index
            text_15.tStart = t  # local t and not account for scr refresh
            text_15.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_15, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_15.started')
            # update status
            text_15.status = STARTED
            text_15.setAutoDraw(True)
        
        # if text_15 is active this frame...
        if text_15.status == STARTED:
            # update params
            pass
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in introduction2Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "introduction2" ---
    for thisComponent in introduction2Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('introduction2.stopped', globalClock.getTime(format='float'))
    # check responses
    if key_resp_14.keys in ['', [], None]:  # No response was made
        key_resp_14.keys = None
    thisExp.addData('key_resp_14.keys',key_resp_14.keys)
    if key_resp_14.keys != None:  # we had a response
        thisExp.addData('key_resp_14.rt', key_resp_14.rt)
        thisExp.addData('key_resp_14.duration', key_resp_14.duration)
    thisExp.nextEntry()
    # the Routine "introduction2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "team_instructions" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('team_instructions.started', globalClock.getTime(format='float'))
    text_14.setText(pressureText)
    # create starting attributes for key_resp_13
    key_resp_13.keys = []
    key_resp_13.rt = []
    _key_resp_13_allKeys = []
    # keep track of which components have finished
    team_instructionsComponents = [text_14, key_resp_13]
    for thisComponent in team_instructionsComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "team_instructions" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_14* updates
        
        # if text_14 is starting this frame...
        if text_14.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_14.frameNStart = frameN  # exact frame index
            text_14.tStart = t  # local t and not account for scr refresh
            text_14.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_14, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_14.started')
            # update status
            text_14.status = STARTED
            text_14.setAutoDraw(True)
        
        # if text_14 is active this frame...
        if text_14.status == STARTED:
            # update params
            pass
        
        # *key_resp_13* updates
        waitOnFlip = False
        
        # if key_resp_13 is starting this frame...
        if key_resp_13.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_13.frameNStart = frameN  # exact frame index
            key_resp_13.tStart = t  # local t and not account for scr refresh
            key_resp_13.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_13, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp_13.started')
            # update status
            key_resp_13.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_13.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_13.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_13.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_13.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_13_allKeys.extend(theseKeys)
            if len(_key_resp_13_allKeys):
                key_resp_13.keys = _key_resp_13_allKeys[-1].name  # just the last key pressed
                key_resp_13.rt = _key_resp_13_allKeys[-1].rt
                key_resp_13.duration = _key_resp_13_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in team_instructionsComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "team_instructions" ---
    for thisComponent in team_instructionsComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('team_instructions.stopped', globalClock.getTime(format='float'))
    # check responses
    if key_resp_13.keys in ['', [], None]:  # No response was made
        key_resp_13.keys = None
    thisExp.addData('key_resp_13.keys',key_resp_13.keys)
    if key_resp_13.keys != None:  # we had a response
        thisExp.addData('key_resp_13.rt', key_resp_13.rt)
        thisExp.addData('key_resp_13.duration', key_resp_13.duration)
    thisExp.nextEntry()
    # the Routine "team_instructions" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    trials_3 = data.TrialHandler(nReps=1.0, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='trials_3')
    thisExp.addLoop(trials_3)  # add the loop to the experiment
    thisTrial_3 = trials_3.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_3.rgb)
    if thisTrial_3 != None:
        for paramName in thisTrial_3:
            globals()[paramName] = thisTrial_3[paramName]
    
    for thisTrial_3 in trials_3:
        currentLoop = trials_3
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_3.rgb)
        if thisTrial_3 != None:
            for paramName in thisTrial_3:
                globals()[paramName] = thisTrial_3[paramName]
        
        # --- Prepare to start Routine "pressureCondition" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('pressureCondition.started', globalClock.getTime(format='float'))
        # keep track of which components have finished
        pressureConditionComponents = []
        for thisComponent in pressureConditionComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "pressureCondition" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in pressureConditionComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "pressureCondition" ---
        for thisComponent in pressureConditionComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('pressureCondition.stopped', globalClock.getTime(format='float'))
        # the Routine "pressureCondition" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # set up handler to look after randomisation of conditions etc
        trials = data.TrialHandler(nReps=1.0, method='random', 
            extraInfo=expInfo, originPath=-1,
            trialList=[None],
            seed=None, name='trials')
        thisExp.addLoop(trials)  # add the loop to the experiment
        thisTrial = trials.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
        if thisTrial != None:
            for paramName in thisTrial:
                globals()[paramName] = thisTrial[paramName]
        
        for thisTrial in trials:
            currentLoop = trials
            thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer], 
                    playbackComponents=[]
            )
            # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
            if thisTrial != None:
                for paramName in thisTrial:
                    globals()[paramName] = thisTrial[paramName]
            
            # --- Prepare to start Routine "text1" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('text1.started', globalClock.getTime(format='float'))
            # create starting attributes for key_resp_37
            key_resp_37.keys = []
            key_resp_37.rt = []
            _key_resp_37_allKeys = []
            # keep track of which components have finished
            text1Components = [text_50, key_resp_37]
            for thisComponent in text1Components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "text1" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *text_50* updates
                
                # if text_50 is starting this frame...
                if text_50.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_50.frameNStart = frameN  # exact frame index
                    text_50.tStart = t  # local t and not account for scr refresh
                    text_50.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_50, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_50.started')
                    # update status
                    text_50.status = STARTED
                    text_50.setAutoDraw(True)
                
                # if text_50 is active this frame...
                if text_50.status == STARTED:
                    # update params
                    pass
                
                # *key_resp_37* updates
                waitOnFlip = False
                
                # if key_resp_37 is starting this frame...
                if key_resp_37.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_37.frameNStart = frameN  # exact frame index
                    key_resp_37.tStart = t  # local t and not account for scr refresh
                    key_resp_37.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_37, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_37.started')
                    # update status
                    key_resp_37.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_37.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_37.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_37.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_37.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                    _key_resp_37_allKeys.extend(theseKeys)
                    if len(_key_resp_37_allKeys):
                        key_resp_37.keys = _key_resp_37_allKeys[-1].name  # just the last key pressed
                        key_resp_37.rt = _key_resp_37_allKeys[-1].rt
                        key_resp_37.duration = _key_resp_37_allKeys[-1].duration
                        # a response ends the routine
                        continueRoutine = False
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in text1Components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "text1" ---
            for thisComponent in text1Components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('text1.stopped', globalClock.getTime(format='float'))
            # check responses
            if key_resp_37.keys in ['', [], None]:  # No response was made
                key_resp_37.keys = None
            trials.addData('key_resp_37.keys',key_resp_37.keys)
            if key_resp_37.keys != None:  # we had a response
                trials.addData('key_resp_37.rt', key_resp_37.rt)
                trials.addData('key_resp_37.duration', key_resp_37.duration)
            # the Routine "text1" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            
            # --- Prepare to start Routine "driverChoice" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('driverChoice.started', globalClock.getTime(format='float'))
            # Run 'Begin Routine' code from code_4
            budgetString = f"Current budget: ${team['budget']:,}" # budget text
            
            text_16.setText(budgetString) # display text
            
            if fired or bankrupt: # if statement for firing
                text_16.text = endReasonText
                continueRoutine = False
            
            # create starting attributes for key_resp_2
            key_resp_2.keys = []
            key_resp_2.rt = []
            _key_resp_2_allKeys = []
            text_16.setText(budgetString)
            # keep track of which components have finished
            driverChoiceComponents = [text_3, key_resp_2, text_16]
            for thisComponent in driverChoiceComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "driverChoice" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *text_3* updates
                
                # if text_3 is starting this frame...
                if text_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_3.frameNStart = frameN  # exact frame index
                    text_3.tStart = t  # local t and not account for scr refresh
                    text_3.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_3, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_3.started')
                    # update status
                    text_3.status = STARTED
                    text_3.setAutoDraw(True)
                
                # if text_3 is active this frame...
                if text_3.status == STARTED:
                    # update params
                    pass
                
                # *key_resp_2* updates
                waitOnFlip = False
                
                # if key_resp_2 is starting this frame...
                if key_resp_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_2.frameNStart = frameN  # exact frame index
                    key_resp_2.tStart = t  # local t and not account for scr refresh
                    key_resp_2.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_2, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_2.started')
                    # update status
                    key_resp_2.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_2.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_2.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_2.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_2.getKeys(keyList=['a','b','c','d','e','f','g','h','i','j'], ignoreKeys=["escape"], waitRelease=False)
                    _key_resp_2_allKeys.extend(theseKeys)
                    if len(_key_resp_2_allKeys):
                        key_resp_2.keys = _key_resp_2_allKeys[-1].name  # just the last key pressed
                        key_resp_2.rt = _key_resp_2_allKeys[-1].rt
                        key_resp_2.duration = _key_resp_2_allKeys[-1].duration
                        # a response ends the routine
                        continueRoutine = False
                
                # *text_16* updates
                
                # if text_16 is starting this frame...
                if text_16.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_16.frameNStart = frameN  # exact frame index
                    text_16.tStart = t  # local t and not account for scr refresh
                    text_16.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_16, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_16.started')
                    # update status
                    text_16.status = STARTED
                    text_16.setAutoDraw(True)
                
                # if text_16 is active this frame...
                if text_16.status == STARTED:
                    # update params
                    pass
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in driverChoiceComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "driverChoice" ---
            for thisComponent in driverChoiceComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('driverChoice.stopped', globalClock.getTime(format='float'))
            # Run 'End Routine' code from code_4
            choice_key = key_resp_2.keys   # keys pressed
            
            letter = None # hold letter
            selected = None # hold choice
            price = None # hold price
            valid = False # assumes no valid choices
            # info into excel file!!
            if not choice_key: # now putting my participant data into excel file
                thisExp.addData('driver_choice_error', 'No key') # log error
            else:
                letter = choice_key[-1].upper() # last key becomes uppercase
            
                if letter in driverOptions: # if valid
                    selected = driverOptions[letter] # find letter
                    price = selected['price'] 
            
                    if team['budget'] < price: # if budget too small
                        thisExp.addData('driver_choice_error', 'Not enough budget')
                    else: # all else
                        # valid choice
                        team['driver'] = selected['name']
                        team['driverRatings'] = selected['ratings']
                        team['budget'] -= price
                        valid = True
                else: # invalid
                    thisExp.addData('driver_choice_error', 'Invalid letter')
            
            if not valid: # after checks, if still not valid...
                thisExp.addData('driver_choice_valid', False) # log invalid choice
            else:
                thisExp.addData('driver_choice_valid', True) # log valid choice
            # excel logs
            thisExp.addData('driver_choice_letter', letter)
            thisExp.addData('driver_name', selected['name'] if selected is not None else None)
            thisExp.addData('driver_cost', price)
            
            # NOTE, all selection-based codes use a similar format, so you can use these comments there
            # check responses
            if key_resp_2.keys in ['', [], None]:  # No response was made
                key_resp_2.keys = None
            trials.addData('key_resp_2.keys',key_resp_2.keys)
            if key_resp_2.keys != None:  # we had a response
                trials.addData('key_resp_2.rt', key_resp_2.rt)
                trials.addData('key_resp_2.duration', key_resp_2.duration)
            # the Routine "driverChoice" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            
            # --- Prepare to start Routine "text2" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('text2.started', globalClock.getTime(format='float'))
            # create starting attributes for _key_resp_38
            _key_resp_38.keys = []
            _key_resp_38.rt = []
            __key_resp_38_allKeys = []
            # keep track of which components have finished
            text2Components = [text_51, _key_resp_38]
            for thisComponent in text2Components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "text2" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *text_51* updates
                
                # if text_51 is starting this frame...
                if text_51.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_51.frameNStart = frameN  # exact frame index
                    text_51.tStart = t  # local t and not account for scr refresh
                    text_51.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_51, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_51.started')
                    # update status
                    text_51.status = STARTED
                    text_51.setAutoDraw(True)
                
                # if text_51 is active this frame...
                if text_51.status == STARTED:
                    # update params
                    pass
                
                # *_key_resp_38* updates
                waitOnFlip = False
                
                # if _key_resp_38 is starting this frame...
                if _key_resp_38.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    _key_resp_38.frameNStart = frameN  # exact frame index
                    _key_resp_38.tStart = t  # local t and not account for scr refresh
                    _key_resp_38.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(_key_resp_38, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, '_key_resp_38.started')
                    # update status
                    _key_resp_38.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(_key_resp_38.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(_key_resp_38.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if _key_resp_38.status == STARTED and not waitOnFlip:
                    theseKeys = _key_resp_38.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                    __key_resp_38_allKeys.extend(theseKeys)
                    if len(__key_resp_38_allKeys):
                        _key_resp_38.keys = __key_resp_38_allKeys[-1].name  # just the last key pressed
                        _key_resp_38.rt = __key_resp_38_allKeys[-1].rt
                        _key_resp_38.duration = __key_resp_38_allKeys[-1].duration
                        # a response ends the routine
                        continueRoutine = False
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in text2Components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "text2" ---
            for thisComponent in text2Components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('text2.stopped', globalClock.getTime(format='float'))
            # check responses
            if _key_resp_38.keys in ['', [], None]:  # No response was made
                _key_resp_38.keys = None
            trials.addData('_key_resp_38.keys',_key_resp_38.keys)
            if _key_resp_38.keys != None:  # we had a response
                trials.addData('_key_resp_38.rt', _key_resp_38.rt)
                trials.addData('_key_resp_38.duration', _key_resp_38.duration)
            # the Routine "text2" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            
            # --- Prepare to start Routine "engineChoice" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('engineChoice.started', globalClock.getTime(format='float'))
            # Run 'Begin Routine' code from code_5
            budgetString = f"Current budget: ${team['budget']:,}"
            
            text_17.setText(budgetString)
            
            if fired or bankrupt:
                text_17.text = endReasonText
                continueRoutine = False
            
            # create starting attributes for key_resp_3
            key_resp_3.keys = []
            key_resp_3.rt = []
            _key_resp_3_allKeys = []
            text_17.setText(budgetString)
            # keep track of which components have finished
            engineChoiceComponents = [text_4, key_resp_3, text_17]
            for thisComponent in engineChoiceComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "engineChoice" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *text_4* updates
                
                # if text_4 is starting this frame...
                if text_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_4.frameNStart = frameN  # exact frame index
                    text_4.tStart = t  # local t and not account for scr refresh
                    text_4.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_4, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_4.started')
                    # update status
                    text_4.status = STARTED
                    text_4.setAutoDraw(True)
                
                # if text_4 is active this frame...
                if text_4.status == STARTED:
                    # update params
                    pass
                
                # *key_resp_3* updates
                waitOnFlip = False
                
                # if key_resp_3 is starting this frame...
                if key_resp_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_3.frameNStart = frameN  # exact frame index
                    key_resp_3.tStart = t  # local t and not account for scr refresh
                    key_resp_3.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_3, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_3.started')
                    # update status
                    key_resp_3.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_3.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_3.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_3.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_3.getKeys(keyList=['a','b','c','d'], ignoreKeys=["escape"], waitRelease=False)
                    _key_resp_3_allKeys.extend(theseKeys)
                    if len(_key_resp_3_allKeys):
                        key_resp_3.keys = _key_resp_3_allKeys[-1].name  # just the last key pressed
                        key_resp_3.rt = _key_resp_3_allKeys[-1].rt
                        key_resp_3.duration = _key_resp_3_allKeys[-1].duration
                        # a response ends the routine
                        continueRoutine = False
                
                # *text_17* updates
                
                # if text_17 is starting this frame...
                if text_17.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_17.frameNStart = frameN  # exact frame index
                    text_17.tStart = t  # local t and not account for scr refresh
                    text_17.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_17, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_17.started')
                    # update status
                    text_17.status = STARTED
                    text_17.setAutoDraw(True)
                
                # if text_17 is active this frame...
                if text_17.status == STARTED:
                    # update params
                    pass
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in engineChoiceComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "engineChoice" ---
            for thisComponent in engineChoiceComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('engineChoice.stopped', globalClock.getTime(format='float'))
            # Run 'End Routine' code from code_5
            choice_key = key_resp_3.keys  
            
            letter = None
            chosenEngine = None
            price = None
            valid = False
            
            if not choice_key:
                thisExp.addData('engine_choice_error', 'No key pressed')
            else:
                letter = choice_key[-1].upper()
            
                letterToEngine = {
                    'A': 'Auronix Powerworks',
                    'B': 'Veltro Dynamics',
                    'C': 'Shenlong Motorsport Engines',
                    'D': 'Harrowfield Engineering'
                }
            
                if letter in letterToEngine:
                    chosenEngine = letterToEngine[letter]
                    price = engineOptions[chosenEngine]
            
                    if team['budget'] < price:
                        thisExp.addData('engine_choice_error', 'Not enough budget')
                    else:
                        team['engineSupplier'] = chosenEngine
                        team['budget'] -= price
                        valid = True
                else:
                    thisExp.addData('engine_choice_error', 'Invalid letter')
            
            if not valid:
                thisExp.addData('engine_choice_valid', False)
            else:
                thisExp.addData('engine_choice_valid', True)
            
            
            thisExp.addData('engine_choice_letter', letter)
            thisExp.addData('engine_name', chosenEngine)
            thisExp.addData('engine_cost', price)
            thisExp.addData('budget_after_engine', team['budget'])
            
            # check responses
            if key_resp_3.keys in ['', [], None]:  # No response was made
                key_resp_3.keys = None
            trials.addData('key_resp_3.keys',key_resp_3.keys)
            if key_resp_3.keys != None:  # we had a response
                trials.addData('key_resp_3.rt', key_resp_3.rt)
                trials.addData('key_resp_3.duration', key_resp_3.duration)
            # the Routine "engineChoice" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            
            # --- Prepare to start Routine "text3" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('text3.started', globalClock.getTime(format='float'))
            # create starting attributes for key_resp_39
            key_resp_39.keys = []
            key_resp_39.rt = []
            _key_resp_39_allKeys = []
            # keep track of which components have finished
            text3Components = [key_resp_39, text_52]
            for thisComponent in text3Components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "text3" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *key_resp_39* updates
                waitOnFlip = False
                
                # if key_resp_39 is starting this frame...
                if key_resp_39.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_39.frameNStart = frameN  # exact frame index
                    key_resp_39.tStart = t  # local t and not account for scr refresh
                    key_resp_39.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_39, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_39.started')
                    # update status
                    key_resp_39.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_39.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_39.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_39.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_39.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                    _key_resp_39_allKeys.extend(theseKeys)
                    if len(_key_resp_39_allKeys):
                        key_resp_39.keys = _key_resp_39_allKeys[-1].name  # just the last key pressed
                        key_resp_39.rt = _key_resp_39_allKeys[-1].rt
                        key_resp_39.duration = _key_resp_39_allKeys[-1].duration
                        # a response ends the routine
                        continueRoutine = False
                
                # *text_52* updates
                
                # if text_52 is starting this frame...
                if text_52.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_52.frameNStart = frameN  # exact frame index
                    text_52.tStart = t  # local t and not account for scr refresh
                    text_52.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_52, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_52.started')
                    # update status
                    text_52.status = STARTED
                    text_52.setAutoDraw(True)
                
                # if text_52 is active this frame...
                if text_52.status == STARTED:
                    # update params
                    pass
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in text3Components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "text3" ---
            for thisComponent in text3Components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('text3.stopped', globalClock.getTime(format='float'))
            # check responses
            if key_resp_39.keys in ['', [], None]:  # No response was made
                key_resp_39.keys = None
            trials.addData('key_resp_39.keys',key_resp_39.keys)
            if key_resp_39.keys != None:  # we had a response
                trials.addData('key_resp_39.rt', key_resp_39.rt)
                trials.addData('key_resp_39.duration', key_resp_39.duration)
            # the Routine "text3" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            
            # --- Prepare to start Routine "frontWingChoice" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('frontWingChoice.started', globalClock.getTime(format='float'))
            # Run 'Begin Routine' code from code_6
            budgetString = f"Current budget: ${team['budget']:,}"
            
            text_18.setText(budgetString)
            
            if fired or bankrupt:
                text_18.text = endReasonText
                continueRoutine = False
            
            # create starting attributes for key_resp_4
            key_resp_4.keys = []
            key_resp_4.rt = []
            _key_resp_4_allKeys = []
            text_18.setText(budgetString)
            # keep track of which components have finished
            frontWingChoiceComponents = [text_5, key_resp_4, text_18]
            for thisComponent in frontWingChoiceComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "frontWingChoice" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *text_5* updates
                
                # if text_5 is starting this frame...
                if text_5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_5.frameNStart = frameN  # exact frame index
                    text_5.tStart = t  # local t and not account for scr refresh
                    text_5.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_5, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_5.started')
                    # update status
                    text_5.status = STARTED
                    text_5.setAutoDraw(True)
                
                # if text_5 is active this frame...
                if text_5.status == STARTED:
                    # update params
                    pass
                
                # *key_resp_4* updates
                waitOnFlip = False
                
                # if key_resp_4 is starting this frame...
                if key_resp_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_4.frameNStart = frameN  # exact frame index
                    key_resp_4.tStart = t  # local t and not account for scr refresh
                    key_resp_4.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_4, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_4.started')
                    # update status
                    key_resp_4.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_4.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_4.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_4.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_4.getKeys(keyList=['a','b','c','d','e'], ignoreKeys=["escape"], waitRelease=False)
                    _key_resp_4_allKeys.extend(theseKeys)
                    if len(_key_resp_4_allKeys):
                        key_resp_4.keys = _key_resp_4_allKeys[-1].name  # just the last key pressed
                        key_resp_4.rt = _key_resp_4_allKeys[-1].rt
                        key_resp_4.duration = _key_resp_4_allKeys[-1].duration
                        # a response ends the routine
                        continueRoutine = False
                
                # *text_18* updates
                
                # if text_18 is starting this frame...
                if text_18.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_18.frameNStart = frameN  # exact frame index
                    text_18.tStart = t  # local t and not account for scr refresh
                    text_18.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_18, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_18.started')
                    # update status
                    text_18.status = STARTED
                    text_18.setAutoDraw(True)
                
                # if text_18 is active this frame...
                if text_18.status == STARTED:
                    # update params
                    pass
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in frontWingChoiceComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "frontWingChoice" ---
            for thisComponent in frontWingChoiceComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('frontWingChoice.stopped', globalClock.getTime(format='float'))
            # Run 'End Routine' code from code_6
            choice_key = key_resp_4.keys  
            
            valid = False
            letter = None
            chosenFrontWingOption = None
            price = None
            
            if not choice_key:
                thisExp.addData('frontWing_choice_error', 'No key pressed')
            else:
                letter = choice_key[-1].upper()
            
                if letter in letter_to_option:
                    chosenFrontWingOption = letter_to_option[letter] 
                    price = frontWingOptions[chosenFrontWingOption]
            
                    if team['budget'] < price:
                        thisExp.addData('frontWing_choice_error', 'Not enough budget')
                    else:
                        team['carParts']['frontWing'] = chosenFrontWingOption
                        team['carParts']['frontWing'] = chosenFrontWingOption
                        team['budget'] -= price
                        valid = True
                else:
                    thisExp.addData('frontWing_choice_error', 'Invalid letter')
            
            thisExp.addData('frontWing_choice_valid', valid)
            thisExp.addData('frontWing_choice_letter', letter)
            thisExp.addData('frontWing_option', chosenFrontWingOption)
            thisExp.addData('frontWing_cost', price)
            thisExp.addData('budget_after_frontWing', team['budget'])
            
            # check responses
            if key_resp_4.keys in ['', [], None]:  # No response was made
                key_resp_4.keys = None
            trials.addData('key_resp_4.keys',key_resp_4.keys)
            if key_resp_4.keys != None:  # we had a response
                trials.addData('key_resp_4.rt', key_resp_4.rt)
                trials.addData('key_resp_4.duration', key_resp_4.duration)
            # the Routine "frontWingChoice" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            
            # --- Prepare to start Routine "text4" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('text4.started', globalClock.getTime(format='float'))
            # create starting attributes for key_resp_40
            key_resp_40.keys = []
            key_resp_40.rt = []
            _key_resp_40_allKeys = []
            # keep track of which components have finished
            text4Components = [key_resp_40, text_53]
            for thisComponent in text4Components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "text4" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *key_resp_40* updates
                waitOnFlip = False
                
                # if key_resp_40 is starting this frame...
                if key_resp_40.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_40.frameNStart = frameN  # exact frame index
                    key_resp_40.tStart = t  # local t and not account for scr refresh
                    key_resp_40.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_40, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_40.started')
                    # update status
                    key_resp_40.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_40.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_40.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_40.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_40.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                    _key_resp_40_allKeys.extend(theseKeys)
                    if len(_key_resp_40_allKeys):
                        key_resp_40.keys = _key_resp_40_allKeys[-1].name  # just the last key pressed
                        key_resp_40.rt = _key_resp_40_allKeys[-1].rt
                        key_resp_40.duration = _key_resp_40_allKeys[-1].duration
                        # a response ends the routine
                        continueRoutine = False
                
                # *text_53* updates
                
                # if text_53 is starting this frame...
                if text_53.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_53.frameNStart = frameN  # exact frame index
                    text_53.tStart = t  # local t and not account for scr refresh
                    text_53.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_53, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_53.started')
                    # update status
                    text_53.status = STARTED
                    text_53.setAutoDraw(True)
                
                # if text_53 is active this frame...
                if text_53.status == STARTED:
                    # update params
                    pass
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in text4Components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "text4" ---
            for thisComponent in text4Components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('text4.stopped', globalClock.getTime(format='float'))
            # check responses
            if key_resp_40.keys in ['', [], None]:  # No response was made
                key_resp_40.keys = None
            trials.addData('key_resp_40.keys',key_resp_40.keys)
            if key_resp_40.keys != None:  # we had a response
                trials.addData('key_resp_40.rt', key_resp_40.rt)
                trials.addData('key_resp_40.duration', key_resp_40.duration)
            # the Routine "text4" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            
            # --- Prepare to start Routine "rearWingChoice" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('rearWingChoice.started', globalClock.getTime(format='float'))
            # Run 'Begin Routine' code from code_7
            budgetString = f"Current budget: ${team['budget']:,}"
            
            text_19.setText(budgetString)
            
            if fired or bankrupt:
                text_19.text = endReasonText
                continueRoutine = False
            
            # create starting attributes for key_resp_5
            key_resp_5.keys = []
            key_resp_5.rt = []
            _key_resp_5_allKeys = []
            text_19.setText(budgetString)
            # keep track of which components have finished
            rearWingChoiceComponents = [text_6, key_resp_5, text_19]
            for thisComponent in rearWingChoiceComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "rearWingChoice" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *text_6* updates
                
                # if text_6 is starting this frame...
                if text_6.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_6.frameNStart = frameN  # exact frame index
                    text_6.tStart = t  # local t and not account for scr refresh
                    text_6.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_6, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_6.started')
                    # update status
                    text_6.status = STARTED
                    text_6.setAutoDraw(True)
                
                # if text_6 is active this frame...
                if text_6.status == STARTED:
                    # update params
                    pass
                
                # *key_resp_5* updates
                waitOnFlip = False
                
                # if key_resp_5 is starting this frame...
                if key_resp_5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_5.frameNStart = frameN  # exact frame index
                    key_resp_5.tStart = t  # local t and not account for scr refresh
                    key_resp_5.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_5, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_5.started')
                    # update status
                    key_resp_5.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_5.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_5.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_5.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_5.getKeys(keyList=['a','b','c','d','e'], ignoreKeys=["escape"], waitRelease=False)
                    _key_resp_5_allKeys.extend(theseKeys)
                    if len(_key_resp_5_allKeys):
                        key_resp_5.keys = _key_resp_5_allKeys[-1].name  # just the last key pressed
                        key_resp_5.rt = _key_resp_5_allKeys[-1].rt
                        key_resp_5.duration = _key_resp_5_allKeys[-1].duration
                        # a response ends the routine
                        continueRoutine = False
                
                # *text_19* updates
                
                # if text_19 is starting this frame...
                if text_19.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_19.frameNStart = frameN  # exact frame index
                    text_19.tStart = t  # local t and not account for scr refresh
                    text_19.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_19, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_19.started')
                    # update status
                    text_19.status = STARTED
                    text_19.setAutoDraw(True)
                
                # if text_19 is active this frame...
                if text_19.status == STARTED:
                    # update params
                    pass
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in rearWingChoiceComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "rearWingChoice" ---
            for thisComponent in rearWingChoiceComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('rearWingChoice.stopped', globalClock.getTime(format='float'))
            # Run 'End Routine' code from code_7
            choice_key = key_resp_5.keys 
            
            valid = False
            letter = None
            chosenRearWingOption = None
            price = None
            
            if not choice_key:
                thisExp.addData('rearWing_choice_error', 'No key pressed')
            else:
                letter = choice_key[-1].upper()
            
                if letter in letter_to_option:
                    chosenRearWingOption = letter_to_option[letter] 
                    price = rearWingOptions[chosenRearWingOption]
            
                    if team['budget'] < price:
                        thisExp.addData('rearWing_choice_error', 'Not enough budget')
                    else:
                        team['rearWing'] = chosenRearWingOption
                        team['carParts']['rearWing'] = chosenRearWingOption
                        team['budget'] -= price
                        valid = True
                else:
                    thisExp.addData('rearWing_choice_error', 'Invalid letter')
            
            thisExp.addData('rearWing_choice_valid', valid)
            thisExp.addData('rearWing_choice_letter', letter)
            thisExp.addData('rearWing_option', chosenRearWingOption)
            thisExp.addData('rearWing_cost', price)
            thisExp.addData('budget_after_rearWing', team['budget'])
            
            # check responses
            if key_resp_5.keys in ['', [], None]:  # No response was made
                key_resp_5.keys = None
            trials.addData('key_resp_5.keys',key_resp_5.keys)
            if key_resp_5.keys != None:  # we had a response
                trials.addData('key_resp_5.rt', key_resp_5.rt)
                trials.addData('key_resp_5.duration', key_resp_5.duration)
            # the Routine "rearWingChoice" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            
            # --- Prepare to start Routine "text5" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('text5.started', globalClock.getTime(format='float'))
            # create starting attributes for key_resp_41
            key_resp_41.keys = []
            key_resp_41.rt = []
            _key_resp_41_allKeys = []
            # keep track of which components have finished
            text5Components = [key_resp_41, text_54]
            for thisComponent in text5Components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "text5" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *key_resp_41* updates
                waitOnFlip = False
                
                # if key_resp_41 is starting this frame...
                if key_resp_41.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_41.frameNStart = frameN  # exact frame index
                    key_resp_41.tStart = t  # local t and not account for scr refresh
                    key_resp_41.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_41, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_41.started')
                    # update status
                    key_resp_41.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_41.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_41.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_41.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_41.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                    _key_resp_41_allKeys.extend(theseKeys)
                    if len(_key_resp_41_allKeys):
                        key_resp_41.keys = _key_resp_41_allKeys[-1].name  # just the last key pressed
                        key_resp_41.rt = _key_resp_41_allKeys[-1].rt
                        key_resp_41.duration = _key_resp_41_allKeys[-1].duration
                        # a response ends the routine
                        continueRoutine = False
                
                # *text_54* updates
                
                # if text_54 is starting this frame...
                if text_54.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_54.frameNStart = frameN  # exact frame index
                    text_54.tStart = t  # local t and not account for scr refresh
                    text_54.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_54, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_54.started')
                    # update status
                    text_54.status = STARTED
                    text_54.setAutoDraw(True)
                
                # if text_54 is active this frame...
                if text_54.status == STARTED:
                    # update params
                    pass
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in text5Components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "text5" ---
            for thisComponent in text5Components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('text5.stopped', globalClock.getTime(format='float'))
            # check responses
            if key_resp_41.keys in ['', [], None]:  # No response was made
                key_resp_41.keys = None
            trials.addData('key_resp_41.keys',key_resp_41.keys)
            if key_resp_41.keys != None:  # we had a response
                trials.addData('key_resp_41.rt', key_resp_41.rt)
                trials.addData('key_resp_41.duration', key_resp_41.duration)
            # the Routine "text5" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            
            # --- Prepare to start Routine "chassisChoice" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('chassisChoice.started', globalClock.getTime(format='float'))
            # Run 'Begin Routine' code from code_8
            budgetString = f"Current budget: ${team['budget']:,}"
            
            text_20.setText(budgetString)
            
            if fired or bankrupt:
                text_20.text = endReasonText
                continueRoutine = False
            
            # create starting attributes for key_resp_6
            key_resp_6.keys = []
            key_resp_6.rt = []
            _key_resp_6_allKeys = []
            text_20.setText(budgetString)
            # keep track of which components have finished
            chassisChoiceComponents = [text_7, key_resp_6, text_20]
            for thisComponent in chassisChoiceComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "chassisChoice" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *text_7* updates
                
                # if text_7 is starting this frame...
                if text_7.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_7.frameNStart = frameN  # exact frame index
                    text_7.tStart = t  # local t and not account for scr refresh
                    text_7.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_7, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_7.started')
                    # update status
                    text_7.status = STARTED
                    text_7.setAutoDraw(True)
                
                # if text_7 is active this frame...
                if text_7.status == STARTED:
                    # update params
                    pass
                
                # *key_resp_6* updates
                waitOnFlip = False
                
                # if key_resp_6 is starting this frame...
                if key_resp_6.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_6.frameNStart = frameN  # exact frame index
                    key_resp_6.tStart = t  # local t and not account for scr refresh
                    key_resp_6.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_6, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_6.started')
                    # update status
                    key_resp_6.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_6.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_6.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_6.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_6.getKeys(keyList=['a','b','c','d','e'], ignoreKeys=["escape"], waitRelease=False)
                    _key_resp_6_allKeys.extend(theseKeys)
                    if len(_key_resp_6_allKeys):
                        key_resp_6.keys = _key_resp_6_allKeys[-1].name  # just the last key pressed
                        key_resp_6.rt = _key_resp_6_allKeys[-1].rt
                        key_resp_6.duration = _key_resp_6_allKeys[-1].duration
                        # a response ends the routine
                        continueRoutine = False
                
                # *text_20* updates
                
                # if text_20 is starting this frame...
                if text_20.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_20.frameNStart = frameN  # exact frame index
                    text_20.tStart = t  # local t and not account for scr refresh
                    text_20.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_20, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_20.started')
                    # update status
                    text_20.status = STARTED
                    text_20.setAutoDraw(True)
                
                # if text_20 is active this frame...
                if text_20.status == STARTED:
                    # update params
                    pass
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in chassisChoiceComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "chassisChoice" ---
            for thisComponent in chassisChoiceComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('chassisChoice.stopped', globalClock.getTime(format='float'))
            # Run 'End Routine' code from code_8
            choice_key = key_resp_6.keys  
            
            valid = False
            letter = None
            chosenChassisOption = None
            price = None
            
            if not choice_key:
                thisExp.addData('chassis_choice_error', 'No key pressed')
            else:
                letter = choice_key[-1].upper()
            
                if letter in letter_to_option:
                    chosenChassisOption = letter_to_option[letter]
                    price = chassisOptions[chosenChassisOption]
            
                    if team['budget'] < price:
                        thisExp.addData('chassis_choice_error', 'Not enough budget')
                    else:
                        team['chassis'] = chosenChassisOption
                        team['carParts']['chassis'] = chosenChassisOption
                        team['budget'] -= price
                        valid = True
                else:
                    thisExp.addData('chassis_choice_error', 'Invalid letter')
            
            thisExp.addData('chassis_choice_valid', valid)
            thisExp.addData('chassis_choice_letter', letter)
            thisExp.addData('chassis_option', chosenChassisOption)
            thisExp.addData('chassis_cost', price)
            thisExp.addData('budget_after_chassis', team['budget'])
            
            # check responses
            if key_resp_6.keys in ['', [], None]:  # No response was made
                key_resp_6.keys = None
            trials.addData('key_resp_6.keys',key_resp_6.keys)
            if key_resp_6.keys != None:  # we had a response
                trials.addData('key_resp_6.rt', key_resp_6.rt)
                trials.addData('key_resp_6.duration', key_resp_6.duration)
            # the Routine "chassisChoice" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            
            # --- Prepare to start Routine "text6" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('text6.started', globalClock.getTime(format='float'))
            # create starting attributes for key_resp_42
            key_resp_42.keys = []
            key_resp_42.rt = []
            _key_resp_42_allKeys = []
            # keep track of which components have finished
            text6Components = [key_resp_42, text_55]
            for thisComponent in text6Components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "text6" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *key_resp_42* updates
                waitOnFlip = False
                
                # if key_resp_42 is starting this frame...
                if key_resp_42.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_42.frameNStart = frameN  # exact frame index
                    key_resp_42.tStart = t  # local t and not account for scr refresh
                    key_resp_42.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_42, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_42.started')
                    # update status
                    key_resp_42.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_42.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_42.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_42.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_42.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                    _key_resp_42_allKeys.extend(theseKeys)
                    if len(_key_resp_42_allKeys):
                        key_resp_42.keys = _key_resp_42_allKeys[-1].name  # just the last key pressed
                        key_resp_42.rt = _key_resp_42_allKeys[-1].rt
                        key_resp_42.duration = _key_resp_42_allKeys[-1].duration
                        # a response ends the routine
                        continueRoutine = False
                
                # *text_55* updates
                
                # if text_55 is starting this frame...
                if text_55.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_55.frameNStart = frameN  # exact frame index
                    text_55.tStart = t  # local t and not account for scr refresh
                    text_55.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_55, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_55.started')
                    # update status
                    text_55.status = STARTED
                    text_55.setAutoDraw(True)
                
                # if text_55 is active this frame...
                if text_55.status == STARTED:
                    # update params
                    pass
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in text6Components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "text6" ---
            for thisComponent in text6Components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('text6.stopped', globalClock.getTime(format='float'))
            # check responses
            if key_resp_42.keys in ['', [], None]:  # No response was made
                key_resp_42.keys = None
            trials.addData('key_resp_42.keys',key_resp_42.keys)
            if key_resp_42.keys != None:  # we had a response
                trials.addData('key_resp_42.rt', key_resp_42.rt)
                trials.addData('key_resp_42.duration', key_resp_42.duration)
            # the Routine "text6" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            
            # --- Prepare to start Routine "underfloorChoice" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('underfloorChoice.started', globalClock.getTime(format='float'))
            # Run 'Begin Routine' code from code_9
            budgetString = f"Current budget: ${team['budget']:,}"
            
            text_21.setText(budgetString)
            
            if fired or bankrupt:
                text_21.text = endReasonText
                continueRoutine = False
            
            # create starting attributes for key_resp_7
            key_resp_7.keys = []
            key_resp_7.rt = []
            _key_resp_7_allKeys = []
            text_21.setText(budgetString
            )
            # keep track of which components have finished
            underfloorChoiceComponents = [text_8, key_resp_7, text_21]
            for thisComponent in underfloorChoiceComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "underfloorChoice" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *text_8* updates
                
                # if text_8 is starting this frame...
                if text_8.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_8.frameNStart = frameN  # exact frame index
                    text_8.tStart = t  # local t and not account for scr refresh
                    text_8.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_8, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_8.started')
                    # update status
                    text_8.status = STARTED
                    text_8.setAutoDraw(True)
                
                # if text_8 is active this frame...
                if text_8.status == STARTED:
                    # update params
                    pass
                
                # *key_resp_7* updates
                waitOnFlip = False
                
                # if key_resp_7 is starting this frame...
                if key_resp_7.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_7.frameNStart = frameN  # exact frame index
                    key_resp_7.tStart = t  # local t and not account for scr refresh
                    key_resp_7.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_7, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_7.started')
                    # update status
                    key_resp_7.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_7.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_7.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_7.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_7.getKeys(keyList=['a','b','c','d','e'], ignoreKeys=["escape"], waitRelease=False)
                    _key_resp_7_allKeys.extend(theseKeys)
                    if len(_key_resp_7_allKeys):
                        key_resp_7.keys = _key_resp_7_allKeys[-1].name  # just the last key pressed
                        key_resp_7.rt = _key_resp_7_allKeys[-1].rt
                        key_resp_7.duration = _key_resp_7_allKeys[-1].duration
                        # a response ends the routine
                        continueRoutine = False
                
                # *text_21* updates
                
                # if text_21 is starting this frame...
                if text_21.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_21.frameNStart = frameN  # exact frame index
                    text_21.tStart = t  # local t and not account for scr refresh
                    text_21.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_21, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_21.started')
                    # update status
                    text_21.status = STARTED
                    text_21.setAutoDraw(True)
                
                # if text_21 is active this frame...
                if text_21.status == STARTED:
                    # update params
                    pass
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in underfloorChoiceComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "underfloorChoice" ---
            for thisComponent in underfloorChoiceComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('underfloorChoice.stopped', globalClock.getTime(format='float'))
            # Run 'End Routine' code from code_9
            choice_key = key_resp_7.keys  
            
            valid = False
            letter = None
            chosenUnderfloorOption = None
            price = None
            
            if not choice_key:
                thisExp.addData('underfloor_choice_error', 'No key pressed')
            else:
                letter = choice_key[-1].upper()
            
                if letter in letter_to_option:
                    chosenUnderfloorOption = letter_to_option[letter]
                    price = underfloorOptions[chosenUnderfloorOption]
            
                    if team['budget'] < price:
                        thisExp.addData('underfloor_choice_error', 'Not enough budget')
                    else:
                        team['underfloor'] = chosenUnderfloorOption
                        team['carParts']['underfloor'] = chosenUnderfloorOption
                        team['budget'] -= price
                        valid = True
                else:
                    thisExp.addData('underfloor_choice_error', 'Invalid letter')
            
            thisExp.addData('underfloor_choice_valid', valid)
            thisExp.addData('underfloor_choice_letter', letter)
            thisExp.addData('underfloor_option', chosenUnderfloorOption)
            thisExp.addData('underfloor_cost', price)
            thisExp.addData('budget_after_underfloor', team['budget'])
            
            # check responses
            if key_resp_7.keys in ['', [], None]:  # No response was made
                key_resp_7.keys = None
            trials.addData('key_resp_7.keys',key_resp_7.keys)
            if key_resp_7.keys != None:  # we had a response
                trials.addData('key_resp_7.rt', key_resp_7.rt)
                trials.addData('key_resp_7.duration', key_resp_7.duration)
            # the Routine "underfloorChoice" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            
            # --- Prepare to start Routine "text7" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('text7.started', globalClock.getTime(format='float'))
            # create starting attributes for key_resp_43
            key_resp_43.keys = []
            key_resp_43.rt = []
            _key_resp_43_allKeys = []
            # keep track of which components have finished
            text7Components = [key_resp_43, text_56]
            for thisComponent in text7Components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "text7" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *key_resp_43* updates
                waitOnFlip = False
                
                # if key_resp_43 is starting this frame...
                if key_resp_43.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_43.frameNStart = frameN  # exact frame index
                    key_resp_43.tStart = t  # local t and not account for scr refresh
                    key_resp_43.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_43, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_43.started')
                    # update status
                    key_resp_43.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_43.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_43.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_43.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_43.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                    _key_resp_43_allKeys.extend(theseKeys)
                    if len(_key_resp_43_allKeys):
                        key_resp_43.keys = _key_resp_43_allKeys[-1].name  # just the last key pressed
                        key_resp_43.rt = _key_resp_43_allKeys[-1].rt
                        key_resp_43.duration = _key_resp_43_allKeys[-1].duration
                        # a response ends the routine
                        continueRoutine = False
                
                # *text_56* updates
                
                # if text_56 is starting this frame...
                if text_56.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_56.frameNStart = frameN  # exact frame index
                    text_56.tStart = t  # local t and not account for scr refresh
                    text_56.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_56, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_56.started')
                    # update status
                    text_56.status = STARTED
                    text_56.setAutoDraw(True)
                
                # if text_56 is active this frame...
                if text_56.status == STARTED:
                    # update params
                    pass
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in text7Components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "text7" ---
            for thisComponent in text7Components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('text7.stopped', globalClock.getTime(format='float'))
            # check responses
            if key_resp_43.keys in ['', [], None]:  # No response was made
                key_resp_43.keys = None
            trials.addData('key_resp_43.keys',key_resp_43.keys)
            if key_resp_43.keys != None:  # we had a response
                trials.addData('key_resp_43.rt', key_resp_43.rt)
                trials.addData('key_resp_43.duration', key_resp_43.duration)
            # the Routine "text7" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            
            # --- Prepare to start Routine "pitCrewChoice" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('pitCrewChoice.started', globalClock.getTime(format='float'))
            # Run 'Begin Routine' code from code_10
            budgetString = f"Current budget: ${team['budget']:,}"
            
            text_22.setText(budgetString)
            
            if fired or bankrupt:
                text_22.text = endReasonText
                continueRoutine = False
            
            # create starting attributes for key_resp_8
            key_resp_8.keys = []
            key_resp_8.rt = []
            _key_resp_8_allKeys = []
            text_22.setText(budgetString
            )
            # keep track of which components have finished
            pitCrewChoiceComponents = [text_9, key_resp_8, text_22]
            for thisComponent in pitCrewChoiceComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "pitCrewChoice" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *text_9* updates
                
                # if text_9 is starting this frame...
                if text_9.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_9.frameNStart = frameN  # exact frame index
                    text_9.tStart = t  # local t and not account for scr refresh
                    text_9.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_9, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_9.started')
                    # update status
                    text_9.status = STARTED
                    text_9.setAutoDraw(True)
                
                # if text_9 is active this frame...
                if text_9.status == STARTED:
                    # update params
                    pass
                
                # *key_resp_8* updates
                waitOnFlip = False
                
                # if key_resp_8 is starting this frame...
                if key_resp_8.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_8.frameNStart = frameN  # exact frame index
                    key_resp_8.tStart = t  # local t and not account for scr refresh
                    key_resp_8.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_8, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_8.started')
                    # update status
                    key_resp_8.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_8.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_8.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_8.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_8.getKeys(keyList=['a','b','c','d','e'], ignoreKeys=["escape"], waitRelease=False)
                    _key_resp_8_allKeys.extend(theseKeys)
                    if len(_key_resp_8_allKeys):
                        key_resp_8.keys = _key_resp_8_allKeys[-1].name  # just the last key pressed
                        key_resp_8.rt = _key_resp_8_allKeys[-1].rt
                        key_resp_8.duration = _key_resp_8_allKeys[-1].duration
                        # a response ends the routine
                        continueRoutine = False
                
                # *text_22* updates
                
                # if text_22 is starting this frame...
                if text_22.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_22.frameNStart = frameN  # exact frame index
                    text_22.tStart = t  # local t and not account for scr refresh
                    text_22.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_22, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_22.started')
                    # update status
                    text_22.status = STARTED
                    text_22.setAutoDraw(True)
                
                # if text_22 is active this frame...
                if text_22.status == STARTED:
                    # update params
                    pass
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in pitCrewChoiceComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "pitCrewChoice" ---
            for thisComponent in pitCrewChoiceComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('pitCrewChoice.stopped', globalClock.getTime(format='float'))
            # Run 'End Routine' code from code_10
            choice_key = key_resp_8.keys 
            
            valid = False
            letter = None
            chosenPitCrew = None
            price = None
            
            if not choice_key:
                thisExp.addData('pitCrew_choice_error', 'No key pressed')
            else:
                letter = choice_key[-1].upper()
            
                letterToPitCrew = {
                    'A': 'Crew A',
                    'B': 'Crew B',
                    'C': 'Crew C',
                    'D': 'Crew D',
                    'E': 'Crew E',
                }
            
                if letter in letterToPitCrew:
                    chosenPitCrew = letterToPitCrew[letter]
                    price = pitCrewOptions[chosenPitCrew]
            
                    if team['budget'] < price:
                        thisExp.addData('pitCrew_choice_error', 'Not enough budget')
                    else:
                        team['pitCrew'] = chosenPitCrew
                        team['personnel']['pitCrew'] = chosenPitCrew
                        team['budget'] -= price
                        valid = True
                else:
                    thisExp.addData('pitCrew_choice_error', 'Invalid letter')
            
            thisExp.addData('pitCrew_choice_valid', valid)
            thisExp.addData('pitCrew_choice_letter', letter)
            thisExp.addData('pitCrew_name', chosenPitCrew)
            thisExp.addData('pitCrew_cost', price)
            thisExp.addData('budget_after_pitCrew', team['budget'])
            
            # check responses
            if key_resp_8.keys in ['', [], None]:  # No response was made
                key_resp_8.keys = None
            trials.addData('key_resp_8.keys',key_resp_8.keys)
            if key_resp_8.keys != None:  # we had a response
                trials.addData('key_resp_8.rt', key_resp_8.rt)
                trials.addData('key_resp_8.duration', key_resp_8.duration)
            # the Routine "pitCrewChoice" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            
            # --- Prepare to start Routine "text8" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('text8.started', globalClock.getTime(format='float'))
            # create starting attributes for key_resp_44
            key_resp_44.keys = []
            key_resp_44.rt = []
            _key_resp_44_allKeys = []
            # keep track of which components have finished
            text8Components = [key_resp_44, text_57]
            for thisComponent in text8Components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "text8" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *key_resp_44* updates
                waitOnFlip = False
                
                # if key_resp_44 is starting this frame...
                if key_resp_44.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_44.frameNStart = frameN  # exact frame index
                    key_resp_44.tStart = t  # local t and not account for scr refresh
                    key_resp_44.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_44, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_44.started')
                    # update status
                    key_resp_44.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_44.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_44.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_44.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_44.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                    _key_resp_44_allKeys.extend(theseKeys)
                    if len(_key_resp_44_allKeys):
                        key_resp_44.keys = _key_resp_44_allKeys[-1].name  # just the last key pressed
                        key_resp_44.rt = _key_resp_44_allKeys[-1].rt
                        key_resp_44.duration = _key_resp_44_allKeys[-1].duration
                        # a response ends the routine
                        continueRoutine = False
                
                # *text_57* updates
                
                # if text_57 is starting this frame...
                if text_57.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_57.frameNStart = frameN  # exact frame index
                    text_57.tStart = t  # local t and not account for scr refresh
                    text_57.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_57, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_57.started')
                    # update status
                    text_57.status = STARTED
                    text_57.setAutoDraw(True)
                
                # if text_57 is active this frame...
                if text_57.status == STARTED:
                    # update params
                    pass
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in text8Components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "text8" ---
            for thisComponent in text8Components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('text8.stopped', globalClock.getTime(format='float'))
            # check responses
            if key_resp_44.keys in ['', [], None]:  # No response was made
                key_resp_44.keys = None
            trials.addData('key_resp_44.keys',key_resp_44.keys)
            if key_resp_44.keys != None:  # we had a response
                trials.addData('key_resp_44.rt', key_resp_44.rt)
                trials.addData('key_resp_44.duration', key_resp_44.duration)
            # the Routine "text8" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            
            # --- Prepare to start Routine "engineerChoice" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('engineerChoice.started', globalClock.getTime(format='float'))
            # Run 'Begin Routine' code from code_11
            budgetString = f"Current budget: ${team['budget']:,}"
            
            text_23.setText(budgetString)
            
            if fired or bankrupt:
                text_23.text = endReasonText
                continueRoutine = False
            
            # create starting attributes for key_resp_9
            key_resp_9.keys = []
            key_resp_9.rt = []
            _key_resp_9_allKeys = []
            text_23.setText(budgetString
            )
            # keep track of which components have finished
            engineerChoiceComponents = [text_10, key_resp_9, text_23]
            for thisComponent in engineerChoiceComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "engineerChoice" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *text_10* updates
                
                # if text_10 is starting this frame...
                if text_10.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_10.frameNStart = frameN  # exact frame index
                    text_10.tStart = t  # local t and not account for scr refresh
                    text_10.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_10, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_10.started')
                    # update status
                    text_10.status = STARTED
                    text_10.setAutoDraw(True)
                
                # if text_10 is active this frame...
                if text_10.status == STARTED:
                    # update params
                    pass
                
                # *key_resp_9* updates
                waitOnFlip = False
                
                # if key_resp_9 is starting this frame...
                if key_resp_9.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_9.frameNStart = frameN  # exact frame index
                    key_resp_9.tStart = t  # local t and not account for scr refresh
                    key_resp_9.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_9, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_9.started')
                    # update status
                    key_resp_9.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_9.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_9.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_9.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_9.getKeys(keyList=['a','b','c','d','e'], ignoreKeys=["escape"], waitRelease=False)
                    _key_resp_9_allKeys.extend(theseKeys)
                    if len(_key_resp_9_allKeys):
                        key_resp_9.keys = _key_resp_9_allKeys[-1].name  # just the last key pressed
                        key_resp_9.rt = _key_resp_9_allKeys[-1].rt
                        key_resp_9.duration = _key_resp_9_allKeys[-1].duration
                        # a response ends the routine
                        continueRoutine = False
                
                # *text_23* updates
                
                # if text_23 is starting this frame...
                if text_23.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_23.frameNStart = frameN  # exact frame index
                    text_23.tStart = t  # local t and not account for scr refresh
                    text_23.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_23, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_23.started')
                    # update status
                    text_23.status = STARTED
                    text_23.setAutoDraw(True)
                
                # if text_23 is active this frame...
                if text_23.status == STARTED:
                    # update params
                    pass
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in engineerChoiceComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "engineerChoice" ---
            for thisComponent in engineerChoiceComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('engineerChoice.stopped', globalClock.getTime(format='float'))
            # Run 'End Routine' code from code_11
            choice_key = key_resp_9.keys  
            
            valid = False
            letter = None
            chosenEngineerOption = None
            price = None
            
            if not choice_key:
                thisExp.addData('engineer_choice_error', 'No key pressed')
            else:
                letter = choice_key[-1].upper()
            
                if letter in letter_to_option:
                    chosenEngineerOption = letter_to_option[letter] 
                    price = engineerOptions[chosenEngineerOption]
            
                    if team['budget'] < price:
                        thisExp.addData('engineer_choice_error', 'Not enough budget')
                    else:
                        team['engineerOption'] = chosenEngineerOption
                        team['personnel']['engineer'] = chosenEngineerOption
                        team['budget'] -= price
                        valid = True
                else:
                    thisExp.addData('engineer_choice_error', 'Invalid letter')
            
            thisExp.addData('engineer_choice_valid', valid)
            thisExp.addData('engineer_choice_letter', letter)
            thisExp.addData('engineer_option', chosenEngineerOption)
            thisExp.addData('engineer_cost', price)
            thisExp.addData('budget_after_engineer', team['budget'])
            
            # check responses
            if key_resp_9.keys in ['', [], None]:  # No response was made
                key_resp_9.keys = None
            trials.addData('key_resp_9.keys',key_resp_9.keys)
            if key_resp_9.keys != None:  # we had a response
                trials.addData('key_resp_9.rt', key_resp_9.rt)
                trials.addData('key_resp_9.duration', key_resp_9.duration)
            # the Routine "engineerChoice" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            
            # --- Prepare to start Routine "text9" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('text9.started', globalClock.getTime(format='float'))
            # create starting attributes for key_resp_45
            key_resp_45.keys = []
            key_resp_45.rt = []
            _key_resp_45_allKeys = []
            # keep track of which components have finished
            text9Components = [key_resp_45, text_58]
            for thisComponent in text9Components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "text9" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *key_resp_45* updates
                waitOnFlip = False
                
                # if key_resp_45 is starting this frame...
                if key_resp_45.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_45.frameNStart = frameN  # exact frame index
                    key_resp_45.tStart = t  # local t and not account for scr refresh
                    key_resp_45.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_45, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_45.started')
                    # update status
                    key_resp_45.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_45.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_45.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_45.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_45.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                    _key_resp_45_allKeys.extend(theseKeys)
                    if len(_key_resp_45_allKeys):
                        key_resp_45.keys = _key_resp_45_allKeys[-1].name  # just the last key pressed
                        key_resp_45.rt = _key_resp_45_allKeys[-1].rt
                        key_resp_45.duration = _key_resp_45_allKeys[-1].duration
                        # a response ends the routine
                        continueRoutine = False
                
                # *text_58* updates
                
                # if text_58 is starting this frame...
                if text_58.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_58.frameNStart = frameN  # exact frame index
                    text_58.tStart = t  # local t and not account for scr refresh
                    text_58.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_58, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_58.started')
                    # update status
                    text_58.status = STARTED
                    text_58.setAutoDraw(True)
                
                # if text_58 is active this frame...
                if text_58.status == STARTED:
                    # update params
                    pass
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in text9Components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "text9" ---
            for thisComponent in text9Components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('text9.stopped', globalClock.getTime(format='float'))
            # check responses
            if key_resp_45.keys in ['', [], None]:  # No response was made
                key_resp_45.keys = None
            trials.addData('key_resp_45.keys',key_resp_45.keys)
            if key_resp_45.keys != None:  # we had a response
                trials.addData('key_resp_45.rt', key_resp_45.rt)
                trials.addData('key_resp_45.duration', key_resp_45.duration)
            # the Routine "text9" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            
            # --- Prepare to start Routine "designerChoice" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('designerChoice.started', globalClock.getTime(format='float'))
            # Run 'Begin Routine' code from code_12
            budgetString = f"Current budget: ${team['budget']:,}"
            
            text_24.setText(budgetString)
            
            if fired or bankrupt:
                text_24.text = endReasonText
                continueRoutine = False
            
            # create starting attributes for key_resp_10
            key_resp_10.keys = []
            key_resp_10.rt = []
            _key_resp_10_allKeys = []
            text_24.setText(budgetString
            )
            # keep track of which components have finished
            designerChoiceComponents = [text_11, key_resp_10, text_24]
            for thisComponent in designerChoiceComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "designerChoice" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *text_11* updates
                
                # if text_11 is starting this frame...
                if text_11.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_11.frameNStart = frameN  # exact frame index
                    text_11.tStart = t  # local t and not account for scr refresh
                    text_11.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_11, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_11.started')
                    # update status
                    text_11.status = STARTED
                    text_11.setAutoDraw(True)
                
                # if text_11 is active this frame...
                if text_11.status == STARTED:
                    # update params
                    pass
                
                # *key_resp_10* updates
                waitOnFlip = False
                
                # if key_resp_10 is starting this frame...
                if key_resp_10.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_10.frameNStart = frameN  # exact frame index
                    key_resp_10.tStart = t  # local t and not account for scr refresh
                    key_resp_10.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_10, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_10.started')
                    # update status
                    key_resp_10.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_10.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_10.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_10.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_10.getKeys(keyList=['a','b','c','d','e'], ignoreKeys=["escape"], waitRelease=False)
                    _key_resp_10_allKeys.extend(theseKeys)
                    if len(_key_resp_10_allKeys):
                        key_resp_10.keys = _key_resp_10_allKeys[-1].name  # just the last key pressed
                        key_resp_10.rt = _key_resp_10_allKeys[-1].rt
                        key_resp_10.duration = _key_resp_10_allKeys[-1].duration
                        # a response ends the routine
                        continueRoutine = False
                
                # *text_24* updates
                
                # if text_24 is starting this frame...
                if text_24.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_24.frameNStart = frameN  # exact frame index
                    text_24.tStart = t  # local t and not account for scr refresh
                    text_24.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_24, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_24.started')
                    # update status
                    text_24.status = STARTED
                    text_24.setAutoDraw(True)
                
                # if text_24 is active this frame...
                if text_24.status == STARTED:
                    # update params
                    pass
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in designerChoiceComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "designerChoice" ---
            for thisComponent in designerChoiceComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('designerChoice.stopped', globalClock.getTime(format='float'))
            # Run 'End Routine' code from code_12
            choice_key = key_resp_10.keys  
            
            valid = False
            letter = None
            chosenDesignerOption = None
            price = None
            
            if not choice_key:
                thisExp.addData('designer_choice_error', 'No key pressed')
            else:
                letter = choice_key[-1].upper()
            
                if letter in letter_to_option:
                    chosenDesignerOption = letter_to_option[letter]
                    price = designerOptions[chosenDesignerOption]
            
                    if team['budget'] < price:
                        thisExp.addData('designer_choice_error', 'Not enough budget')
                    else:
                        team['designerOption'] = chosenDesignerOption
                        team['personnel']['designer'] = chosenDesignerOption
                        team['budget'] -= price
                        valid = True
                else:
                    thisExp.addData('designer_choice_error', 'Invalid letter')
            
            thisExp.addData('designer_choice_valid', valid)
            thisExp.addData('designer_choice_letter', letter)
            thisExp.addData('designer_option', chosenDesignerOption)
            thisExp.addData('designer_cost', price)
            thisExp.addData('budget_after_designer', team['budget'])
            
            # check responses
            if key_resp_10.keys in ['', [], None]:  # No response was made
                key_resp_10.keys = None
            trials.addData('key_resp_10.keys',key_resp_10.keys)
            if key_resp_10.keys != None:  # we had a response
                trials.addData('key_resp_10.rt', key_resp_10.rt)
                trials.addData('key_resp_10.duration', key_resp_10.duration)
            # the Routine "designerChoice" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            
            # --- Prepare to start Routine "text10" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('text10.started', globalClock.getTime(format='float'))
            # create starting attributes for key_resp_46
            key_resp_46.keys = []
            key_resp_46.rt = []
            _key_resp_46_allKeys = []
            # keep track of which components have finished
            text10Components = [key_resp_46, text_59]
            for thisComponent in text10Components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "text10" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *key_resp_46* updates
                waitOnFlip = False
                
                # if key_resp_46 is starting this frame...
                if key_resp_46.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_46.frameNStart = frameN  # exact frame index
                    key_resp_46.tStart = t  # local t and not account for scr refresh
                    key_resp_46.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_46, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_46.started')
                    # update status
                    key_resp_46.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_46.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_46.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_46.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_46.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                    _key_resp_46_allKeys.extend(theseKeys)
                    if len(_key_resp_46_allKeys):
                        key_resp_46.keys = _key_resp_46_allKeys[-1].name  # just the last key pressed
                        key_resp_46.rt = _key_resp_46_allKeys[-1].rt
                        key_resp_46.duration = _key_resp_46_allKeys[-1].duration
                        # a response ends the routine
                        continueRoutine = False
                
                # *text_59* updates
                
                # if text_59 is starting this frame...
                if text_59.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_59.frameNStart = frameN  # exact frame index
                    text_59.tStart = t  # local t and not account for scr refresh
                    text_59.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_59, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_59.started')
                    # update status
                    text_59.status = STARTED
                    text_59.setAutoDraw(True)
                
                # if text_59 is active this frame...
                if text_59.status == STARTED:
                    # update params
                    pass
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in text10Components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "text10" ---
            for thisComponent in text10Components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('text10.stopped', globalClock.getTime(format='float'))
            # check responses
            if key_resp_46.keys in ['', [], None]:  # No response was made
                key_resp_46.keys = None
            trials.addData('key_resp_46.keys',key_resp_46.keys)
            if key_resp_46.keys != None:  # we had a response
                trials.addData('key_resp_46.rt', key_resp_46.rt)
                trials.addData('key_resp_46.duration', key_resp_46.duration)
            # the Routine "text10" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            
            # --- Prepare to start Routine "designFacililityChoice" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('designFacililityChoice.started', globalClock.getTime(format='float'))
            # Run 'Begin Routine' code from code_13
            budgetString = f"Current budget: ${team['budget']:,}"
            
            text_25.setText(budgetString)
            
            if fired or bankrupt:
                text_25.text = endReasonText
                continueRoutine = False
            
            # create starting attributes for key_resp_11
            key_resp_11.keys = []
            key_resp_11.rt = []
            _key_resp_11_allKeys = []
            text_25.setText(budgetString
            )
            # keep track of which components have finished
            designFacililityChoiceComponents = [text_12, key_resp_11, text_25]
            for thisComponent in designFacililityChoiceComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "designFacililityChoice" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *text_12* updates
                
                # if text_12 is starting this frame...
                if text_12.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_12.frameNStart = frameN  # exact frame index
                    text_12.tStart = t  # local t and not account for scr refresh
                    text_12.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_12, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_12.started')
                    # update status
                    text_12.status = STARTED
                    text_12.setAutoDraw(True)
                
                # if text_12 is active this frame...
                if text_12.status == STARTED:
                    # update params
                    pass
                
                # *key_resp_11* updates
                waitOnFlip = False
                
                # if key_resp_11 is starting this frame...
                if key_resp_11.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_11.frameNStart = frameN  # exact frame index
                    key_resp_11.tStart = t  # local t and not account for scr refresh
                    key_resp_11.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_11, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_11.started')
                    # update status
                    key_resp_11.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_11.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_11.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_11.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_11.getKeys(keyList=['a','b','c','d','e'], ignoreKeys=["escape"], waitRelease=False)
                    _key_resp_11_allKeys.extend(theseKeys)
                    if len(_key_resp_11_allKeys):
                        key_resp_11.keys = _key_resp_11_allKeys[-1].name  # just the last key pressed
                        key_resp_11.rt = _key_resp_11_allKeys[-1].rt
                        key_resp_11.duration = _key_resp_11_allKeys[-1].duration
                        # a response ends the routine
                        continueRoutine = False
                
                # *text_25* updates
                
                # if text_25 is starting this frame...
                if text_25.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_25.frameNStart = frameN  # exact frame index
                    text_25.tStart = t  # local t and not account for scr refresh
                    text_25.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_25, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_25.started')
                    # update status
                    text_25.status = STARTED
                    text_25.setAutoDraw(True)
                
                # if text_25 is active this frame...
                if text_25.status == STARTED:
                    # update params
                    pass
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in designFacililityChoiceComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "designFacililityChoice" ---
            for thisComponent in designFacililityChoiceComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('designFacililityChoice.stopped', globalClock.getTime(format='float'))
            # Run 'End Routine' code from code_13
            choice_key = key_resp_11.keys 
            
            valid = False
            letter = None
            chosenDesignFacilityOption = None
            price = None
            
            if not choice_key:
                thisExp.addData('designFacility_choice_error', 'No key pressed')
            else:
                letter = choice_key[-1].upper()
            
                if letter in letter_to_option:
                    chosenDesignFacilityOption = letter_to_option[letter]
                    price = designFacilityOptions[chosenDesignFacilityOption]
            
                    if team['budget'] < price:
                        thisExp.addData('designFacility_choice_error', 'Not enough budget')
                    else:
                        team['designFacilityOption'] = chosenDesignFacilityOption
                        team['facilities']['design'] = chosenDesignFacilityOption
                        team['budget'] -= price
                        valid = True
                else:
                    thisExp.addData('designFacility_choice_error', 'Invalid letter')
            
            thisExp.addData('designFacility_choice_valid', valid)
            thisExp.addData('designFacility_choice_letter', letter)
            thisExp.addData('designFacility_option', chosenDesignFacilityOption)
            thisExp.addData('designFacility_cost', price)
            thisExp.addData('budget_after_designFacility', team['budget'])
            
            # check responses
            if key_resp_11.keys in ['', [], None]:  # No response was made
                key_resp_11.keys = None
            trials.addData('key_resp_11.keys',key_resp_11.keys)
            if key_resp_11.keys != None:  # we had a response
                trials.addData('key_resp_11.rt', key_resp_11.rt)
                trials.addData('key_resp_11.duration', key_resp_11.duration)
            # the Routine "designFacililityChoice" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            
            # --- Prepare to start Routine "text11" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('text11.started', globalClock.getTime(format='float'))
            # create starting attributes for key_resp_47
            key_resp_47.keys = []
            key_resp_47.rt = []
            _key_resp_47_allKeys = []
            # keep track of which components have finished
            text11Components = [key_resp_47, text_60]
            for thisComponent in text11Components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "text11" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *key_resp_47* updates
                waitOnFlip = False
                
                # if key_resp_47 is starting this frame...
                if key_resp_47.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_47.frameNStart = frameN  # exact frame index
                    key_resp_47.tStart = t  # local t and not account for scr refresh
                    key_resp_47.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_47, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_47.started')
                    # update status
                    key_resp_47.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_47.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_47.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_47.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_47.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                    _key_resp_47_allKeys.extend(theseKeys)
                    if len(_key_resp_47_allKeys):
                        key_resp_47.keys = _key_resp_47_allKeys[-1].name  # just the last key pressed
                        key_resp_47.rt = _key_resp_47_allKeys[-1].rt
                        key_resp_47.duration = _key_resp_47_allKeys[-1].duration
                        # a response ends the routine
                        continueRoutine = False
                
                # *text_60* updates
                
                # if text_60 is starting this frame...
                if text_60.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_60.frameNStart = frameN  # exact frame index
                    text_60.tStart = t  # local t and not account for scr refresh
                    text_60.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_60, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_60.started')
                    # update status
                    text_60.status = STARTED
                    text_60.setAutoDraw(True)
                
                # if text_60 is active this frame...
                if text_60.status == STARTED:
                    # update params
                    pass
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in text11Components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "text11" ---
            for thisComponent in text11Components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('text11.stopped', globalClock.getTime(format='float'))
            # check responses
            if key_resp_47.keys in ['', [], None]:  # No response was made
                key_resp_47.keys = None
            trials.addData('key_resp_47.keys',key_resp_47.keys)
            if key_resp_47.keys != None:  # we had a response
                trials.addData('key_resp_47.rt', key_resp_47.rt)
                trials.addData('key_resp_47.duration', key_resp_47.duration)
            # the Routine "text11" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            
            # --- Prepare to start Routine "r_dFacilityChoice" ---
            continueRoutine = True
            # update component parameters for each repeat
            thisExp.addData('r_dFacilityChoice.started', globalClock.getTime(format='float'))
            # Run 'Begin Routine' code from code_14
            budgetString = f"Current budget: ${team['budget']:,}"
            
            text_26.setText(budgetString)
            
            if fired or bankrupt:
                text_26.text = endReasonText
                continueRoutine = False
            
            # create starting attributes for key_resp_12
            key_resp_12.keys = []
            key_resp_12.rt = []
            _key_resp_12_allKeys = []
            text_26.setText(budgetString
            )
            # keep track of which components have finished
            r_dFacilityChoiceComponents = [text_13, key_resp_12, text_26]
            for thisComponent in r_dFacilityChoiceComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "r_dFacilityChoice" ---
            routineForceEnded = not continueRoutine
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *text_13* updates
                
                # if text_13 is starting this frame...
                if text_13.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_13.frameNStart = frameN  # exact frame index
                    text_13.tStart = t  # local t and not account for scr refresh
                    text_13.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_13, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_13.started')
                    # update status
                    text_13.status = STARTED
                    text_13.setAutoDraw(True)
                
                # if text_13 is active this frame...
                if text_13.status == STARTED:
                    # update params
                    pass
                
                # *key_resp_12* updates
                waitOnFlip = False
                
                # if key_resp_12 is starting this frame...
                if key_resp_12.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_12.frameNStart = frameN  # exact frame index
                    key_resp_12.tStart = t  # local t and not account for scr refresh
                    key_resp_12.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_12, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_12.started')
                    # update status
                    key_resp_12.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_12.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_12.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_12.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_12.getKeys(keyList=['a','b','c','d','e'], ignoreKeys=["escape"], waitRelease=False)
                    _key_resp_12_allKeys.extend(theseKeys)
                    if len(_key_resp_12_allKeys):
                        key_resp_12.keys = _key_resp_12_allKeys[-1].name  # just the last key pressed
                        key_resp_12.rt = _key_resp_12_allKeys[-1].rt
                        key_resp_12.duration = _key_resp_12_allKeys[-1].duration
                        # a response ends the routine
                        continueRoutine = False
                
                # *text_26* updates
                
                # if text_26 is starting this frame...
                if text_26.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_26.frameNStart = frameN  # exact frame index
                    text_26.tStart = t  # local t and not account for scr refresh
                    text_26.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_26, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_26.started')
                    # update status
                    text_26.status = STARTED
                    text_26.setAutoDraw(True)
                
                # if text_26 is active this frame...
                if text_26.status == STARTED:
                    # update params
                    pass
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, win=win)
                    return
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in r_dFacilityChoiceComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "r_dFacilityChoice" ---
            for thisComponent in r_dFacilityChoiceComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            thisExp.addData('r_dFacilityChoice.stopped', globalClock.getTime(format='float'))
            # Run 'End Routine' code from code_14
            choice_key = key_resp_12.keys 
            
            valid = False
            letter = None
            chosenRDFacilityOption = None
            price = None
            
            if not choice_key:
                thisExp.addData('r_dFacility_choice_error', 'No key pressed')
            else:
                letter = choice_key[-1].upper()
            
                if letter in letter_to_option:
                    chosenRDFacilityOption = letter_to_option[letter]
                    price = productionAndResearchFacilityOptions[chosenRDFacilityOption]
            
                    if team['budget'] < price:
                        thisExp.addData('r_dFacility_choice_error', 'Not enough budget')
                    else:
                        team['r_dFacilityOption'] = chosenRDFacilityOption
                        team['facilities']['R&D'] = chosenRDFacilityOption
                        team['budget'] -= price
                        valid = True
                else:
                    thisExp.addData('r_dFacility_choice_error', 'Invalid letter')
            
            thisExp.addData('r_dFacility_choice_valid', valid)
            thisExp.addData('r_dFacility_choice_letter', letter)
            thisExp.addData('r_dFacility_option', chosenRDFacilityOption)
            thisExp.addData('r_dFacility_cost', price)
            thisExp.addData('budget_after_r_dFacility', team['budget'])
            
            # check responses
            if key_resp_12.keys in ['', [], None]:  # No response was made
                key_resp_12.keys = None
            trials.addData('key_resp_12.keys',key_resp_12.keys)
            if key_resp_12.keys != None:  # we had a response
                trials.addData('key_resp_12.rt', key_resp_12.rt)
                trials.addData('key_resp_12.duration', key_resp_12.duration)
            # the Routine "r_dFacilityChoice" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            thisExp.nextEntry()
            
            if thisSession is not None:
                # if running in a Session with a Liaison client, send data up to now
                thisSession.sendExperimentData()
        # completed 1.0 repeats of 'trials'
        
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 1.0 repeats of 'trials_3'
    
    
    # --- Prepare to start Routine "S1Preview" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('S1Preview.started', globalClock.getTime(format='float'))
    # create starting attributes for key_resp_38
    key_resp_38.keys = []
    key_resp_38.rt = []
    _key_resp_38_allKeys = []
    # keep track of which components have finished
    S1PreviewComponents = [text_61, key_resp_38]
    for thisComponent in S1PreviewComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "S1Preview" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_61* updates
        
        # if text_61 is starting this frame...
        if text_61.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_61.frameNStart = frameN  # exact frame index
            text_61.tStart = t  # local t and not account for scr refresh
            text_61.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_61, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_61.started')
            # update status
            text_61.status = STARTED
            text_61.setAutoDraw(True)
        
        # if text_61 is active this frame...
        if text_61.status == STARTED:
            # update params
            pass
        
        # *key_resp_38* updates
        waitOnFlip = False
        
        # if key_resp_38 is starting this frame...
        if key_resp_38.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_38.frameNStart = frameN  # exact frame index
            key_resp_38.tStart = t  # local t and not account for scr refresh
            key_resp_38.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_38, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp_38.started')
            # update status
            key_resp_38.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_38.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_38.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_38.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_38.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_38_allKeys.extend(theseKeys)
            if len(_key_resp_38_allKeys):
                key_resp_38.keys = _key_resp_38_allKeys[-1].name  # just the last key pressed
                key_resp_38.rt = _key_resp_38_allKeys[-1].rt
                key_resp_38.duration = _key_resp_38_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in S1PreviewComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "S1Preview" ---
    for thisComponent in S1PreviewComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('S1Preview.stopped', globalClock.getTime(format='float'))
    # check responses
    if key_resp_38.keys in ['', [], None]:  # No response was made
        key_resp_38.keys = None
    thisExp.addData('key_resp_38.keys',key_resp_38.keys)
    if key_resp_38.keys != None:  # we had a response
        thisExp.addData('key_resp_38.rt', key_resp_38.rt)
        thisExp.addData('key_resp_38.duration', key_resp_38.duration)
    thisExp.nextEntry()
    # the Routine "S1Preview" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    trials_2 = data.TrialHandler(nReps=2.0, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='trials_2')
    thisExp.addLoop(trials_2)  # add the loop to the experiment
    thisTrial_2 = trials_2.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_2.rgb)
    if thisTrial_2 != None:
        for paramName in thisTrial_2:
            globals()[paramName] = thisTrial_2[paramName]
    
    for thisTrial_2 in trials_2:
        currentLoop = trials_2
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_2.rgb)
        if thisTrial_2 != None:
            for paramName in thisTrial_2:
                globals()[paramName] = thisTrial_2[paramName]
        
        # --- Prepare to start Routine "RaceS1Pt1" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('RaceS1Pt1.started', globalClock.getTime(format='float'))
        # Run 'Begin Routine' code from code_16
        raceIndexS1 += 1 # increasing race counter
        
        raceMessage = ( # message for participant
            f"Season 1 – Race {raceIndexS1}\n\n"
            f"Team: {team['name']}\n"
            f"Budget: ${team['budget']:,}\n\n"
            "Development levels (this season):\n"
            f"  Front wing: {currentCarDev['frontWing']}\n"
            f"  Rear wing: {currentCarDev['rearWing']}\n"
            f"  Chassis: {currentCarDev['chassis']}\n"
            f"  Underfloor: {currentCarDev['underfloor']}\n"
            f"  Engine: {currentCarDev['engine']}\n\n"
            f"Next-season research level: {nextYearCarDev}\n\n"
            "Press the spacebar to simulate this race."
        )
        
        text_27.setText(raceMessage) # show full information
        
        # NOTE all of my races1 (races season 1) parts 1-3 and races2 (races season 2) parts 4 - 6 are similar for this
        
        text_27.setText(raceMessage)
        # create starting attributes for key_resp_15
        key_resp_15.keys = []
        key_resp_15.rt = []
        _key_resp_15_allKeys = []
        # keep track of which components have finished
        RaceS1Pt1Components = [text_27, key_resp_15]
        for thisComponent in RaceS1Pt1Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "RaceS1Pt1" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            # Run 'Each Frame' code from code_16
            if 'space' in key_resp_15.keys: # if participant presses spacebar...
                continueRoutine = False # next!
            
            # NOTE all of my races1 (races season 1) parts 1-3 and races2 (races season 2) parts 4 - 6 are similar for this
            
            # *text_27* updates
            
            # if text_27 is starting this frame...
            if text_27.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_27.frameNStart = frameN  # exact frame index
                text_27.tStart = t  # local t and not account for scr refresh
                text_27.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_27, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_27.started')
                # update status
                text_27.status = STARTED
                text_27.setAutoDraw(True)
            
            # if text_27 is active this frame...
            if text_27.status == STARTED:
                # update params
                pass
            
            # *key_resp_15* updates
            waitOnFlip = False
            
            # if key_resp_15 is starting this frame...
            if key_resp_15.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_15.frameNStart = frameN  # exact frame index
                key_resp_15.tStart = t  # local t and not account for scr refresh
                key_resp_15.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_15, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_15.started')
                # update status
                key_resp_15.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_15.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_15.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_15.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_15.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _key_resp_15_allKeys.extend(theseKeys)
                if len(_key_resp_15_allKeys):
                    key_resp_15.keys = _key_resp_15_allKeys[-1].name  # just the last key pressed
                    key_resp_15.rt = _key_resp_15_allKeys[-1].rt
                    key_resp_15.duration = _key_resp_15_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in RaceS1Pt1Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "RaceS1Pt1" ---
        for thisComponent in RaceS1Pt1Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('RaceS1Pt1.stopped', globalClock.getTime(format='float'))
        # Run 'End Routine' code from code_16
        import random
        
        devTotal = (
            currentCarDev['frontWing'] +
            currentCarDev['rearWing'] +
            currentCarDev['chassis'] +
            currentCarDev['underfloor'] +
            currentCarDev['engine']
        )
        
        devBonus = devTotal * 2.0  
        
        teamScore = driverPerf + carPerf + devBonus 
        
        driverExp = team['driverRatings']['Experience']  # 0–100
        
        carStats = [
            currentCarDev['frontWing'],
            currentCarDev['rearWing'],
            currentCarDev['chassis'],
            currentCarDev['underfloor'],
            currentCarDev['engine']
        ]
        carAvg = sum(carStats) / len(carStats)
        
        finishScore = (driverExp + carAvg) / 2.0
        
        roll = random.uniform(0, 100)
        
        crashed = False
        s1AccidentMessage = "No accident"
        s1RepairCost = 0
        
        if roll > finishScore:
            crashed = True
            position = 20           
            racePoints = 0
            s1LastRacePosition = "DNF"
            s1LastRacePoints = 0
        
            if driverExp < carAvg:
                s1RepairCost = 1000000     
                s1AccidentMessage = f"The driver crashed. Cost: ${s1RepairCost:,}"
            else:
                s1RepairCost = 300000
                s1AccidentMessage = f"The car broke. Cost: ${s1RepairCost:,}"
            team['budget'] -= s1RepairCost
        
        if crashed:
            position = 20
        
        if team['budget'] < 0:
            bankrupt = True
            fired = True
            endReasonText = "GAME OVER\nYou went over budget.\nPress spacebar to close."
        
        
        thisExp.addData('s1AccidentMessage', s1AccidentMessage)
        thisExp.addData('s1RepairCost', s1RepairCost)
        
        if not crashed:
            aiScores = []
            for i in range(19):
                aiScore = random.uniform(0, 100)
                aiScores.append(aiScore)
            
            allScores = aiScores + [teamScore]
            sortedScores = sorted(allScores, reverse=True)
        
            position = sortedScores.index(teamScore) + 1  
            pointsTable = {
                1: 25, 2: 18, 3: 15, 4: 12, 5: 10,
                6: 8, 7: 6, 8: 4, 9: 2, 10: 1
            }
        
            racePoints = pointsTable.get(position, 0)
        
            s1SeasonPoints += racePoints
        
            s1LastRacePosition = position
            s1LastRacePoints = racePoints
        
        if boardPressure == "1":   # high pressure
            winBoost = 8
            midPenalty = -5
            crashPenalty = -25
        else:  # low pressure
            winBoost = 4
            midPenalty = -2
            crashPenalty = -12
        
        change = 0
        
        if crashed:
            change = crashPenalty
        elif position <= 5:
            change = winBoost
        else:
            change = midPenalty
        
        
        boardConfidence = boardConfidence + change
        
        if boardConfidence > 100:
            boardConfidence = 100
        if boardConfidence < 0:
            boardConfidence = 0
        
        if boardConfidence <= firingThreshold:
            fired = True
        
        thisExp.addData('boardConfidence', boardConfidence)
        thisExp.addData('boardPressureCondition', boardPressure)
        thisExp.addData('s1RaceIndex', raceIndexS1)
        thisExp.addData('s1Position', s1LastRacePosition)
        thisExp.addData('s1RacePoints', s1LastRacePoints)
        thisExp.addData('s1SeasonPoints_total', s1SeasonPoints)
        thisExp.addData('s1BudgetAfterRace', team['budget'])
        
        # check responses
        if key_resp_15.keys in ['', [], None]:  # No response was made
            key_resp_15.keys = None
        trials_2.addData('key_resp_15.keys',key_resp_15.keys)
        if key_resp_15.keys != None:  # we had a response
            trials_2.addData('key_resp_15.rt', key_resp_15.rt)
            trials_2.addData('key_resp_15.duration', key_resp_15.duration)
        # the Routine "RaceS1Pt1" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "RaceResultsS1" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('RaceResultsS1.started', globalClock.getTime(format='float'))
        # Run 'Begin Routine' code from code_22
        if fired or bankrupt: # if fired or bankrupt
            raceResultsMessage = ( # messsage
                "GAME OVER\n"
                "You have been fired.\n\n"
                "Press spacebar to end the study."
            )
            s1AccidentMessage = "" # make it blank here
        else: # otherwise
            raceResultsMessage = ( # message
                f"Season 1 – Race {raceIndexS1}\n\n"
                f"Finishing position: P{s1LastRacePosition}\n"
                f"Points this race: {s1LastRacePoints}\n"
                f"Total season points: {s1SeasonPoints}\n\n"
                f"Board confidence: {int(boardConfidence)}%\n"
                f"Budget: ${team['budget']:,}\n\n"
                "Press spacebar to continue."
            )
        
        text_32.setText(raceResultsMessage) # show text
        text_36.setText(s1AccidentMessage) # show text
        
        # NOTE similar idea for for RaceResultsS1 (race results season 2)
        
        # create starting attributes for key_resp_21
        key_resp_21.keys = []
        key_resp_21.rt = []
        _key_resp_21_allKeys = []
        text_32.setText(raceResultsMessage)
        text_36.setText(s1AccidentMessage)
        # keep track of which components have finished
        RaceResultsS1Components = [key_resp_21, text_32, text_36]
        for thisComponent in RaceResultsS1Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "RaceResultsS1" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *key_resp_21* updates
            waitOnFlip = False
            
            # if key_resp_21 is starting this frame...
            if key_resp_21.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_21.frameNStart = frameN  # exact frame index
                key_resp_21.tStart = t  # local t and not account for scr refresh
                key_resp_21.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_21, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_21.started')
                # update status
                key_resp_21.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_21.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_21.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_21.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_21.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _key_resp_21_allKeys.extend(theseKeys)
                if len(_key_resp_21_allKeys):
                    key_resp_21.keys = _key_resp_21_allKeys[-1].name  # just the last key pressed
                    key_resp_21.rt = _key_resp_21_allKeys[-1].rt
                    key_resp_21.duration = _key_resp_21_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # *text_32* updates
            
            # if text_32 is starting this frame...
            if text_32.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_32.frameNStart = frameN  # exact frame index
                text_32.tStart = t  # local t and not account for scr refresh
                text_32.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_32, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_32.started')
                # update status
                text_32.status = STARTED
                text_32.setAutoDraw(True)
            
            # if text_32 is active this frame...
            if text_32.status == STARTED:
                # update params
                pass
            
            # *text_36* updates
            
            # if text_36 is starting this frame...
            if text_36.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_36.frameNStart = frameN  # exact frame index
                text_36.tStart = t  # local t and not account for scr refresh
                text_36.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_36, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_36.started')
                # update status
                text_36.status = STARTED
                text_36.setAutoDraw(True)
            
            # if text_36 is active this frame...
            if text_36.status == STARTED:
                # update params
                pass
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in RaceResultsS1Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "RaceResultsS1" ---
        for thisComponent in RaceResultsS1Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('RaceResultsS1.stopped', globalClock.getTime(format='float'))
        # Run 'End Routine' code from code_22
        if fired or bankrupt: # if fired or bankrupt
            thisExp.status = FINISHED # done!
        
        # check responses
        if key_resp_21.keys in ['', [], None]:  # No response was made
            key_resp_21.keys = None
        trials_2.addData('key_resp_21.keys',key_resp_21.keys)
        if key_resp_21.keys != None:  # we had a response
            trials_2.addData('key_resp_21.rt', key_resp_21.rt)
            trials_2.addData('key_resp_21.duration', key_resp_21.duration)
        # the Routine "RaceResultsS1" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 2.0 repeats of 'trials_2'
    
    
    # --- Prepare to start Routine "devPause1" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('devPause1.started', globalClock.getTime(format='float'))
    # Run 'Begin Routine' code from code_19
    if fired or bankrupt: # if fired or bankrupt
        text_30.text = endReasonText # replace text with this message
        continueRoutine = False # end!
    else:
        costInfo = ( # development background
            f"\n\nEach development point costs ${devPointCost:,}.\n"
            "The total cost of the points you use at this stop "
            "will be subtracted from your budget.\n"
            f"Current budget before this stop: ${team['budget']:,}"
        )
        text_30.setText(text_30.text + costInfo) # append cost info to test that was shown for this dev stop
    
    # NOTE all devPauses (1-6) follow a similar format here
    
    
    # create starting attributes for key_resp_18
    key_resp_18.keys = []
    key_resp_18.rt = []
    _key_resp_18_allKeys = []
    # keep track of which components have finished
    devPause1Components = [text_30, key_resp_18]
    for thisComponent in devPause1Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "devPause1" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        # Run 'Each Frame' code from code_19
        if key_resp_18.keys and 'return' in key_resp_18.keys: # if enter is pressed...
            continueRoutine = False # next routine!
        
        
        # NOTE all devPauses (1-6) follow a similar format here
        
        
        # *text_30* updates
        
        # if text_30 is starting this frame...
        if text_30.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_30.frameNStart = frameN  # exact frame index
            text_30.tStart = t  # local t and not account for scr refresh
            text_30.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_30, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_30.started')
            # update status
            text_30.status = STARTED
            text_30.setAutoDraw(True)
        
        # if text_30 is active this frame...
        if text_30.status == STARTED:
            # update params
            pass
        
        # *key_resp_18* updates
        waitOnFlip = False
        
        # if key_resp_18 is starting this frame...
        if key_resp_18.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_18.frameNStart = frameN  # exact frame index
            key_resp_18.tStart = t  # local t and not account for scr refresh
            key_resp_18.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_18, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp_18.started')
            # update status
            key_resp_18.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_18.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_18.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_18.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_18.getKeys(keyList=['a','b','c','d','e','f','return'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_18_allKeys.extend(theseKeys)
            if len(_key_resp_18_allKeys):
                key_resp_18.keys = [key.name for key in _key_resp_18_allKeys]  # storing all keys
                key_resp_18.rt = [key.rt for key in _key_resp_18_allKeys]
                key_resp_18.duration = [key.duration for key in _key_resp_18_allKeys]
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in devPause1Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "devPause1" ---
    for thisComponent in devPause1Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('devPause1.stopped', globalClock.getTime(format='float'))
    # Run 'End Routine' code from code_19
    keys = key_resp_18.keys or [] # record keys pressed
    
    letters = [] # storage list
    for k in keys: # loop for each key
        if k != 'return': # ignore this in dev-letter sequence
            letters.append(k.upper())
        if len(letters) == 8: # limit to letters in stop
            break
    # number of letters pressed for each option
    fw = letters.count('A')
    rw = letters.count('B')
    ch = letters.count('C')
    uf = letters.count('D')
    en = letters.count('E')
    nx = letters.count('F')
    # add dev pts to current car
    currentCarDev['frontWing'] += fw
    currentCarDev['rearWing'] += rw
    currentCarDev['chassis'] += ch
    currentCarDev['underfloor'] += uf
    currentCarDev['engine'] += en
    nextYearCarDev += nx
    # total number of points used
    Dev1_pointsUsed = len(letters)
    totalCost1 = Dev1_pointsUsed * devPointCost # cost 
    team['budget'] -= totalCost1 # subtract from budget
    if team['budget'] < 0: # firing check
        bankrupt = True
        fired = True
        endReasonText = "GAME OVER\nYou went over budget.\nPress spacebar to end."
    # log into excel
    thisExp.addData('DevStop1_letters_raw', letters)
    thisExp.addData('DevStop1_pointsUsed', Dev1_pointsUsed)
    thisExp.addData('DevStop1_fw_added', Dev1_fw)
    thisExp.addData('DevStop1_rw_added', Dev1_rw)
    thisExp.addData('DevStop1_ch_added', Dev1_ch)
    thisExp.addData('DevStop1_uf_added', Dev1_uf)
    thisExp.addData('DevStop1_en_added', Dev1_en)
    thisExp.addData('DevStop1_ny_added', Dev1_ny)
    thisExp.addData('DevStop1_currentDev_frontWing_total', currentCarDev['frontWing'])
    thisExp.addData('DevStop1_currentDev_rearWing_total', currentCarDev['rearWing'])
    thisExp.addData('DevStop1_currentDev_chassis_total', currentCarDev['chassis'])
    thisExp.addData('DevStop1_currentDev_underfloor_total', currentCarDev['underfloor'])
    thisExp.addData('DevStop1_currentDev_engine_total', currentCarDev['engine'])
    thisExp.addData('DevStop1_nextYearDev_total', nextYearCarDev)
    thisExp.addData('DevStop1_totalDevCost', totalCost1)
    thisExp.addData('DevStop1_budget_after_cost', team['budget'])
    
    # NOTE all devPauses (1-6) follow a similar format here
    
    # check responses
    if key_resp_18.keys in ['', [], None]:  # No response was made
        key_resp_18.keys = None
    thisExp.addData('key_resp_18.keys',key_resp_18.keys)
    if key_resp_18.keys != None:  # we had a response
        thisExp.addData('key_resp_18.rt', key_resp_18.rt)
        thisExp.addData('key_resp_18.duration', key_resp_18.duration)
    thisExp.nextEntry()
    # the Routine "devPause1" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    trials_4 = data.TrialHandler(nReps=2.0, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='trials_4')
    thisExp.addLoop(trials_4)  # add the loop to the experiment
    thisTrial_4 = trials_4.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_4.rgb)
    if thisTrial_4 != None:
        for paramName in thisTrial_4:
            globals()[paramName] = thisTrial_4[paramName]
    
    for thisTrial_4 in trials_4:
        currentLoop = trials_4
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_4.rgb)
        if thisTrial_4 != None:
            for paramName in thisTrial_4:
                globals()[paramName] = thisTrial_4[paramName]
        
        # --- Prepare to start Routine "RaceS1Pt2" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('RaceS1Pt2.started', globalClock.getTime(format='float'))
        # Run 'Begin Routine' code from code_17
        raceIndexS1 += 1
        
        raceMessage = (
            f"Season 1 – Race {raceIndexS1}\n\n"
            f"Team: {team['name']}\n"
            f"Budget: ${team['budget']:,}\n\n"
            "Development levels (this season):\n"
            f"  Front wing: {currentCarDev['frontWing']}\n"
            f"  Rear wing: {currentCarDev['rearWing']}\n"
            f"  Chassis: {currentCarDev['chassis']}\n"
            f"  Underfloor: {currentCarDev['underfloor']}\n"
            f"  Engine: {currentCarDev['engine']}\n\n"
            f"Next-season research level: {nextYearCarDev}\n\n"
            "Press the spacebar to simulate this race."
        )
        
        text_28.setText(raceMessage)
        
        text_28.setText(raceMessage)
        # create starting attributes for key_resp_16
        key_resp_16.keys = []
        key_resp_16.rt = []
        _key_resp_16_allKeys = []
        # keep track of which components have finished
        RaceS1Pt2Components = [text_28, key_resp_16]
        for thisComponent in RaceS1Pt2Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "RaceS1Pt2" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            # Run 'Each Frame' code from code_17
            if 'space' in key_resp_16.keys:
                continueRoutine = False
            
            
            # *text_28* updates
            
            # if text_28 is starting this frame...
            if text_28.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_28.frameNStart = frameN  # exact frame index
                text_28.tStart = t  # local t and not account for scr refresh
                text_28.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_28, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_28.started')
                # update status
                text_28.status = STARTED
                text_28.setAutoDraw(True)
            
            # if text_28 is active this frame...
            if text_28.status == STARTED:
                # update params
                pass
            
            # *key_resp_16* updates
            waitOnFlip = False
            
            # if key_resp_16 is starting this frame...
            if key_resp_16.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_16.frameNStart = frameN  # exact frame index
                key_resp_16.tStart = t  # local t and not account for scr refresh
                key_resp_16.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_16, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_16.started')
                # update status
                key_resp_16.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_16.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_16.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_16.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_16.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _key_resp_16_allKeys.extend(theseKeys)
                if len(_key_resp_16_allKeys):
                    key_resp_16.keys = _key_resp_16_allKeys[-1].name  # just the last key pressed
                    key_resp_16.rt = _key_resp_16_allKeys[-1].rt
                    key_resp_16.duration = _key_resp_16_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in RaceS1Pt2Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "RaceS1Pt2" ---
        for thisComponent in RaceS1Pt2Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('RaceS1Pt2.stopped', globalClock.getTime(format='float'))
        # Run 'End Routine' code from code_17
        import random
        
        devTotal = (
            currentCarDev['frontWing'] +
            currentCarDev['rearWing'] +
            currentCarDev['chassis'] +
            currentCarDev['underfloor'] +
            currentCarDev['engine']
        )
        
        devBonus = devTotal * 2.0  
        
        teamScore = driverPerf + carPerf + devBonus 
        
        driverExp = team['driverRatings']['Experience']  # 0–100
        
        carStats = [
            currentCarDev['frontWing'],
            currentCarDev['rearWing'],
            currentCarDev['chassis'],
            currentCarDev['underfloor'],
            currentCarDev['engine']
        ]
        carAvg = sum(carStats) / len(carStats)
        
        finishScore = (driverExp + carAvg) / 2.0
        
        roll = random.uniform(0, 100)
        
        crashed = False
        s1AccidentMessage = "No accident"
        s1RepairCost = 0
        
        if roll > finishScore:
            crashed = True
            position = 20           
            racePoints = 0
            s1LastRacePosition = "DNF"
            s1LastRacePoints = 0
        
            if driverExp < carAvg:
                s1RepairCost = 1000000     
                s1AccidentMessage = f"The driver crashed. Cost: ${s1RepairCost:,}"
            else:
                s1RepairCost = 300000
                s1AccidentMessage = f"The car broke. Cost: ${s1RepairCost:,}"
            team['budget'] -= s1RepairCost
        
        if crashed:
            position = 20
        
        if team['budget'] < 0:
            bankrupt = True
            fired = True
            endReasonText = "GAME OVER\nYou went over budget.\nPress spacebar to close."
        
        
        thisExp.addData('s1AccidentMessage', s1AccidentMessage)
        thisExp.addData('s1RepairCost', s1RepairCost)
        
        if not crashed:
            aiScores = []
            for i in range(19):
                aiScore = random.uniform(0, 100)
                aiScores.append(aiScore)
            
            allScores = aiScores + [teamScore]
            sortedScores = sorted(allScores, reverse=True)
        
            position = sortedScores.index(teamScore) + 1  
            pointsTable = {
                1: 25, 2: 18, 3: 15, 4: 12, 5: 10,
                6: 8, 7: 6, 8: 4, 9: 2, 10: 1
            }
        
            racePoints = pointsTable.get(position, 0)
        
            s1SeasonPoints += racePoints
        
            s1LastRacePosition = position
            s1LastRacePoints = racePoints
        
        if boardPressure == "1":   # high pressure
            winBoost = 8
            midPenalty = -5
            crashPenalty = -25
        else:  # low pressure
            winBoost = 4
            midPenalty = -2
            crashPenalty = -12
        
        change = 0
        
        if crashed:
            change = crashPenalty
        elif position <= 5:
            change = winBoost
        else:
            change = midPenalty
        
        
        boardConfidence = boardConfidence + change
        
        if boardConfidence > 100:
            boardConfidence = 100
        if boardConfidence < 0:
            boardConfidence = 0
        
        if boardConfidence <= firingThreshold:
            fired = True
        
        thisExp.addData('boardConfidence', boardConfidence)
        thisExp.addData('boardPressureCondition', boardPressure)
        thisExp.addData('s1RaceIndex', raceIndexS1)
        thisExp.addData('s1Position', s1LastRacePosition)
        thisExp.addData('s1RacePoints', s1LastRacePoints)
        thisExp.addData('s1SeasonPoints_total', s1SeasonPoints)
        thisExp.addData('s1BudgetAfterRace', team['budget'])
        
        # check responses
        if key_resp_16.keys in ['', [], None]:  # No response was made
            key_resp_16.keys = None
        trials_4.addData('key_resp_16.keys',key_resp_16.keys)
        if key_resp_16.keys != None:  # we had a response
            trials_4.addData('key_resp_16.rt', key_resp_16.rt)
            trials_4.addData('key_resp_16.duration', key_resp_16.duration)
        # the Routine "RaceS1Pt2" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "RaceResultsS1" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('RaceResultsS1.started', globalClock.getTime(format='float'))
        # Run 'Begin Routine' code from code_22
        if fired or bankrupt: # if fired or bankrupt
            raceResultsMessage = ( # messsage
                "GAME OVER\n"
                "You have been fired.\n\n"
                "Press spacebar to end the study."
            )
            s1AccidentMessage = "" # make it blank here
        else: # otherwise
            raceResultsMessage = ( # message
                f"Season 1 – Race {raceIndexS1}\n\n"
                f"Finishing position: P{s1LastRacePosition}\n"
                f"Points this race: {s1LastRacePoints}\n"
                f"Total season points: {s1SeasonPoints}\n\n"
                f"Board confidence: {int(boardConfidence)}%\n"
                f"Budget: ${team['budget']:,}\n\n"
                "Press spacebar to continue."
            )
        
        text_32.setText(raceResultsMessage) # show text
        text_36.setText(s1AccidentMessage) # show text
        
        # NOTE similar idea for for RaceResultsS1 (race results season 2)
        
        # create starting attributes for key_resp_21
        key_resp_21.keys = []
        key_resp_21.rt = []
        _key_resp_21_allKeys = []
        text_32.setText(raceResultsMessage)
        text_36.setText(s1AccidentMessage)
        # keep track of which components have finished
        RaceResultsS1Components = [key_resp_21, text_32, text_36]
        for thisComponent in RaceResultsS1Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "RaceResultsS1" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *key_resp_21* updates
            waitOnFlip = False
            
            # if key_resp_21 is starting this frame...
            if key_resp_21.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_21.frameNStart = frameN  # exact frame index
                key_resp_21.tStart = t  # local t and not account for scr refresh
                key_resp_21.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_21, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_21.started')
                # update status
                key_resp_21.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_21.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_21.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_21.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_21.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _key_resp_21_allKeys.extend(theseKeys)
                if len(_key_resp_21_allKeys):
                    key_resp_21.keys = _key_resp_21_allKeys[-1].name  # just the last key pressed
                    key_resp_21.rt = _key_resp_21_allKeys[-1].rt
                    key_resp_21.duration = _key_resp_21_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # *text_32* updates
            
            # if text_32 is starting this frame...
            if text_32.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_32.frameNStart = frameN  # exact frame index
                text_32.tStart = t  # local t and not account for scr refresh
                text_32.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_32, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_32.started')
                # update status
                text_32.status = STARTED
                text_32.setAutoDraw(True)
            
            # if text_32 is active this frame...
            if text_32.status == STARTED:
                # update params
                pass
            
            # *text_36* updates
            
            # if text_36 is starting this frame...
            if text_36.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_36.frameNStart = frameN  # exact frame index
                text_36.tStart = t  # local t and not account for scr refresh
                text_36.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_36, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_36.started')
                # update status
                text_36.status = STARTED
                text_36.setAutoDraw(True)
            
            # if text_36 is active this frame...
            if text_36.status == STARTED:
                # update params
                pass
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in RaceResultsS1Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "RaceResultsS1" ---
        for thisComponent in RaceResultsS1Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('RaceResultsS1.stopped', globalClock.getTime(format='float'))
        # Run 'End Routine' code from code_22
        if fired or bankrupt: # if fired or bankrupt
            thisExp.status = FINISHED # done!
        
        # check responses
        if key_resp_21.keys in ['', [], None]:  # No response was made
            key_resp_21.keys = None
        trials_4.addData('key_resp_21.keys',key_resp_21.keys)
        if key_resp_21.keys != None:  # we had a response
            trials_4.addData('key_resp_21.rt', key_resp_21.rt)
            trials_4.addData('key_resp_21.duration', key_resp_21.duration)
        # the Routine "RaceResultsS1" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 2.0 repeats of 'trials_4'
    
    
    # --- Prepare to start Routine "devPause2" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('devPause2.started', globalClock.getTime(format='float'))
    # Run 'Begin Routine' code from code_20
    if fired or bankrupt:
        teXt_31.text = endReasonText
        continueRoutine = False
    else:
        costInfo = (
            f"\n\nEach development point costs ${devPointCost:,}.\n"
            "The total cost of the points you use at this stop "
            "will be subtracted from your budget.\n"
            f"Current budget before this stop: ${team['budget']:,}"
        )
        teXt_31.setText(teXt_31.text + costInfo)
    
    # create starting attributes for key_resp_19
    key_resp_19.keys = []
    key_resp_19.rt = []
    _key_resp_19_allKeys = []
    # keep track of which components have finished
    devPause2Components = [teXt_31, key_resp_19]
    for thisComponent in devPause2Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "devPause2" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        # Run 'Each Frame' code from code_20
        if key_resp_19.keys and 'return' in key_resp_19.keys:
            continueRoutine = False
        
        
        # *teXt_31* updates
        
        # if teXt_31 is starting this frame...
        if teXt_31.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            teXt_31.frameNStart = frameN  # exact frame index
            teXt_31.tStart = t  # local t and not account for scr refresh
            teXt_31.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(teXt_31, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'teXt_31.started')
            # update status
            teXt_31.status = STARTED
            teXt_31.setAutoDraw(True)
        
        # if teXt_31 is active this frame...
        if teXt_31.status == STARTED:
            # update params
            pass
        
        # *key_resp_19* updates
        waitOnFlip = False
        
        # if key_resp_19 is starting this frame...
        if key_resp_19.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_19.frameNStart = frameN  # exact frame index
            key_resp_19.tStart = t  # local t and not account for scr refresh
            key_resp_19.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_19, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp_19.started')
            # update status
            key_resp_19.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_19.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_19.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_19.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_19.getKeys(keyList=['a','b','c','d','e','f','return'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_19_allKeys.extend(theseKeys)
            if len(_key_resp_19_allKeys):
                key_resp_19.keys = [key.name for key in _key_resp_19_allKeys]  # storing all keys
                key_resp_19.rt = [key.rt for key in _key_resp_19_allKeys]
                key_resp_19.duration = [key.duration for key in _key_resp_19_allKeys]
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in devPause2Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "devPause2" ---
    for thisComponent in devPause2Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('devPause2.stopped', globalClock.getTime(format='float'))
    # Run 'End Routine' code from code_20
    keys = key_resp_19.keys or []
    
    letters = []
    for k in keys:
        if k != 'return':
            letters.append(k.upper())
        if len(letters) == 8:
            break
    
    fw = letters.count('A')
    rw = letters.count('B')
    ch = letters.count('C')
    uf = letters.count('D')
    en = letters.count('E')
    nx = letters.count('F')
    
    currentCarDev['frontWing'] += fw
    currentCarDev['rearWing'] += rw
    currentCarDev['chassis'] += ch
    currentCarDev['underfloor'] += uf
    currentCarDev['engine'] += en
    nextYearCarDev += nx
    
    Dev2_pointsUsed = len(letters)
    totalCost2 = Dev2_pointsUsed * devPointCost
    team['budget'] -= totalCost2
    
    if team['budget'] < 0:
        bankrupt = True
        fired = True
        endReasonText = "GAME OVER\nYou went over budget.\nPress spacebar to end."
    
    thisExp.addData('DevStop2_letters_raw', letters)
    thisExp.addData('DevStop2_pointsUsed', Dev2_pointsUsed)
    thisExp.addData('DevStop2_fw_added', Dev2_fw)
    thisExp.addData('DevStop2_rw_added', Dev2_rw)
    thisExp.addData('DevStop2_ch_added', Dev2_ch)
    thisExp.addData('DevStop2_uf_added', Dev2_uf)
    thisExp.addData('DevStop2_en_added', Dev2_en)
    thisExp.addData('DevStop2_ny_added', Dev2_ny)
    thisExp.addData('DevStop2_currentDev_frontWing_total', currentCarDev['frontWing'])
    thisExp.addData('DevStop2_currentDev_rearWing_total', currentCarDev['rearWing'])
    thisExp.addData('DevStop2_currentDev_chassis_total', currentCarDev['chassis'])
    thisExp.addData('DevStop2_currentDev_underfloor_total', currentCarDev['underfloor'])
    thisExp.addData('DevStop2_currentDev_engine_total', currentCarDev['engine'])
    thisExp.addData('DevStop2_nextYearDev_total', nextYearCarDev)
    thisExp.addData('DevStop2_totalDevCost', totalCost2)
    thisExp.addData('DevStop2_budget_after_cost', team['budget'])
    # check responses
    if key_resp_19.keys in ['', [], None]:  # No response was made
        key_resp_19.keys = None
    thisExp.addData('key_resp_19.keys',key_resp_19.keys)
    if key_resp_19.keys != None:  # we had a response
        thisExp.addData('key_resp_19.rt', key_resp_19.rt)
        thisExp.addData('key_resp_19.duration', key_resp_19.duration)
    thisExp.nextEntry()
    # the Routine "devPause2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    trials_5 = data.TrialHandler(nReps=2.0, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='trials_5')
    thisExp.addLoop(trials_5)  # add the loop to the experiment
    thisTrial_5 = trials_5.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_5.rgb)
    if thisTrial_5 != None:
        for paramName in thisTrial_5:
            globals()[paramName] = thisTrial_5[paramName]
    
    for thisTrial_5 in trials_5:
        currentLoop = trials_5
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_5.rgb)
        if thisTrial_5 != None:
            for paramName in thisTrial_5:
                globals()[paramName] = thisTrial_5[paramName]
        
        # --- Prepare to start Routine "RaceS1Pt3" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('RaceS1Pt3.started', globalClock.getTime(format='float'))
        # Run 'Begin Routine' code from code_18
        raceIndexS1 += 1
        
        raceMessage = (
            f"Season 1 – Race {raceIndexS1}\n\n"
            f"Team: {team['name']}\n"
            f"Budget: ${team['budget']:,}\n\n"
            "Development levels (this season):\n"
            f"  Front wing: {currentCarDev['frontWing']}\n"
            f"  Rear wing: {currentCarDev['rearWing']}\n"
            f"  Chassis: {currentCarDev['chassis']}\n"
            f"  Underfloor: {currentCarDev['underfloor']}\n"
            f"  Engine: {currentCarDev['engine']}\n\n"
            f"Next-season research level: {nextYearCarDev}\n\n"
            "Press the spacebar to simulate this race."
        )
        
        text_29.setText(raceMessage)
        
        text_29.setText(raceMessage)
        # create starting attributes for key_resp_17
        key_resp_17.keys = []
        key_resp_17.rt = []
        _key_resp_17_allKeys = []
        # keep track of which components have finished
        RaceS1Pt3Components = [text_29, key_resp_17]
        for thisComponent in RaceS1Pt3Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "RaceS1Pt3" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            # Run 'Each Frame' code from code_18
            if 'space' in key_resp_17.keys:
                continueRoutine = False
            
            
            # *text_29* updates
            
            # if text_29 is starting this frame...
            if text_29.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_29.frameNStart = frameN  # exact frame index
                text_29.tStart = t  # local t and not account for scr refresh
                text_29.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_29, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_29.started')
                # update status
                text_29.status = STARTED
                text_29.setAutoDraw(True)
            
            # if text_29 is active this frame...
            if text_29.status == STARTED:
                # update params
                pass
            
            # *key_resp_17* updates
            waitOnFlip = False
            
            # if key_resp_17 is starting this frame...
            if key_resp_17.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_17.frameNStart = frameN  # exact frame index
                key_resp_17.tStart = t  # local t and not account for scr refresh
                key_resp_17.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_17, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_17.started')
                # update status
                key_resp_17.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_17.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_17.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_17.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_17.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _key_resp_17_allKeys.extend(theseKeys)
                if len(_key_resp_17_allKeys):
                    key_resp_17.keys = _key_resp_17_allKeys[-1].name  # just the last key pressed
                    key_resp_17.rt = _key_resp_17_allKeys[-1].rt
                    key_resp_17.duration = _key_resp_17_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in RaceS1Pt3Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "RaceS1Pt3" ---
        for thisComponent in RaceS1Pt3Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('RaceS1Pt3.stopped', globalClock.getTime(format='float'))
        # Run 'End Routine' code from code_18
        import random
        
        devTotal = (
            currentCarDev['frontWing'] +
            currentCarDev['rearWing'] +
            currentCarDev['chassis'] +
            currentCarDev['underfloor'] +
            currentCarDev['engine']
        )
        
        devBonus = devTotal * 2.0  
        
        teamScore = driverPerf + carPerf + devBonus 
        
        driverExp = team['driverRatings']['Experience']  # 0–100
        
        carStats = [
            currentCarDev['frontWing'],
            currentCarDev['rearWing'],
            currentCarDev['chassis'],
            currentCarDev['underfloor'],
            currentCarDev['engine']
        ]
        carAvg = sum(carStats) / len(carStats)
        
        finishScore = (driverExp + carAvg) / 2.0
        
        roll = random.uniform(0, 100)
        
        crashed = False
        s1AccidentMessage = "No accident"
        s1RepairCost = 0
        
        if roll > finishScore:
            crashed = True
            position = 20           
            racePoints = 0
            s1LastRacePosition = "DNF"
            s1LastRacePoints = 0
        
            if driverExp < carAvg:
                s1RepairCost = 1000000     
                s1AccidentMessage = f"The driver crashed. Cost: ${s1RepairCost:,}"
            else:
                s1RepairCost = 300000
                s1AccidentMessage = f"The car broke. Cost: ${s1RepairCost:,}"
            team['budget'] -= s1RepairCost
        
        if crashed:
            position = 20
        
        if team['budget'] < 0:
            bankrupt = True
            fired = True
            endReasonText = "GAME OVER\nYou went over budget.\nPress spacebar to close."
        
        
        thisExp.addData('s1AccidentMessage', s1AccidentMessage)
        thisExp.addData('s1RepairCost', s1RepairCost)
        
        if not crashed:
            aiScores = []
            for i in range(19):
                aiScore = random.uniform(0, 100)
                aiScores.append(aiScore)
            
            allScores = aiScores + [teamScore]
            sortedScores = sorted(allScores, reverse=True)
        
            position = sortedScores.index(teamScore) + 1  
            pointsTable = {
                1: 25, 2: 18, 3: 15, 4: 12, 5: 10,
                6: 8, 7: 6, 8: 4, 9: 2, 10: 1
            }
        
            racePoints = pointsTable.get(position, 0)
        
            s1SeasonPoints += racePoints
        
            s1LastRacePosition = position
            s1LastRacePoints = racePoints
        
        if boardPressure == "1":   # high pressure
            winBoost = 8
            midPenalty = -5
            crashPenalty = -25
        else:  # low pressure
            winBoost = 4
            midPenalty = -2
            crashPenalty = -12
        
        change = 0
        
        if crashed:
            change = crashPenalty
        elif position <= 5:
            change = winBoost
        else:
            change = midPenalty
        
        
        boardConfidence = boardConfidence + change
        
        if boardConfidence > 100:
            boardConfidence = 100
        if boardConfidence < 0:
            boardConfidence = 0
        
        if boardConfidence <= firingThreshold:
            fired = True
        
        thisExp.addData('boardConfidence', boardConfidence)
        thisExp.addData('boardPressureCondition', boardPressure)
        thisExp.addData('s1RaceIndex', raceIndexS1)
        thisExp.addData('s1Position', s1LastRacePosition)
        thisExp.addData('s1RacePoints', s1LastRacePoints)
        thisExp.addData('s1SeasonPoints_total', s1SeasonPoints)
        thisExp.addData('s1BudgetAfterRace', team['budget'])
        
        # check responses
        if key_resp_17.keys in ['', [], None]:  # No response was made
            key_resp_17.keys = None
        trials_5.addData('key_resp_17.keys',key_resp_17.keys)
        if key_resp_17.keys != None:  # we had a response
            trials_5.addData('key_resp_17.rt', key_resp_17.rt)
            trials_5.addData('key_resp_17.duration', key_resp_17.duration)
        # the Routine "RaceS1Pt3" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "RaceResultsS1" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('RaceResultsS1.started', globalClock.getTime(format='float'))
        # Run 'Begin Routine' code from code_22
        if fired or bankrupt: # if fired or bankrupt
            raceResultsMessage = ( # messsage
                "GAME OVER\n"
                "You have been fired.\n\n"
                "Press spacebar to end the study."
            )
            s1AccidentMessage = "" # make it blank here
        else: # otherwise
            raceResultsMessage = ( # message
                f"Season 1 – Race {raceIndexS1}\n\n"
                f"Finishing position: P{s1LastRacePosition}\n"
                f"Points this race: {s1LastRacePoints}\n"
                f"Total season points: {s1SeasonPoints}\n\n"
                f"Board confidence: {int(boardConfidence)}%\n"
                f"Budget: ${team['budget']:,}\n\n"
                "Press spacebar to continue."
            )
        
        text_32.setText(raceResultsMessage) # show text
        text_36.setText(s1AccidentMessage) # show text
        
        # NOTE similar idea for for RaceResultsS1 (race results season 2)
        
        # create starting attributes for key_resp_21
        key_resp_21.keys = []
        key_resp_21.rt = []
        _key_resp_21_allKeys = []
        text_32.setText(raceResultsMessage)
        text_36.setText(s1AccidentMessage)
        # keep track of which components have finished
        RaceResultsS1Components = [key_resp_21, text_32, text_36]
        for thisComponent in RaceResultsS1Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "RaceResultsS1" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *key_resp_21* updates
            waitOnFlip = False
            
            # if key_resp_21 is starting this frame...
            if key_resp_21.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_21.frameNStart = frameN  # exact frame index
                key_resp_21.tStart = t  # local t and not account for scr refresh
                key_resp_21.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_21, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_21.started')
                # update status
                key_resp_21.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_21.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_21.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_21.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_21.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _key_resp_21_allKeys.extend(theseKeys)
                if len(_key_resp_21_allKeys):
                    key_resp_21.keys = _key_resp_21_allKeys[-1].name  # just the last key pressed
                    key_resp_21.rt = _key_resp_21_allKeys[-1].rt
                    key_resp_21.duration = _key_resp_21_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # *text_32* updates
            
            # if text_32 is starting this frame...
            if text_32.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_32.frameNStart = frameN  # exact frame index
                text_32.tStart = t  # local t and not account for scr refresh
                text_32.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_32, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_32.started')
                # update status
                text_32.status = STARTED
                text_32.setAutoDraw(True)
            
            # if text_32 is active this frame...
            if text_32.status == STARTED:
                # update params
                pass
            
            # *text_36* updates
            
            # if text_36 is starting this frame...
            if text_36.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_36.frameNStart = frameN  # exact frame index
                text_36.tStart = t  # local t and not account for scr refresh
                text_36.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_36, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_36.started')
                # update status
                text_36.status = STARTED
                text_36.setAutoDraw(True)
            
            # if text_36 is active this frame...
            if text_36.status == STARTED:
                # update params
                pass
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in RaceResultsS1Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "RaceResultsS1" ---
        for thisComponent in RaceResultsS1Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('RaceResultsS1.stopped', globalClock.getTime(format='float'))
        # Run 'End Routine' code from code_22
        if fired or bankrupt: # if fired or bankrupt
            thisExp.status = FINISHED # done!
        
        # check responses
        if key_resp_21.keys in ['', [], None]:  # No response was made
            key_resp_21.keys = None
        trials_5.addData('key_resp_21.keys',key_resp_21.keys)
        if key_resp_21.keys != None:  # we had a response
            trials_5.addData('key_resp_21.rt', key_resp_21.rt)
            trials_5.addData('key_resp_21.duration', key_resp_21.duration)
        # the Routine "RaceResultsS1" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 2.0 repeats of 'trials_5'
    
    
    # --- Prepare to start Routine "devPause3" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('devPause3.started', globalClock.getTime(format='float'))
    # Run 'Begin Routine' code from code_21
    if fired or bankrupt:
        text_31.text = endReasonText
        continueRoutine = False
    else:
        costInfo = (
            f"\n\nEach development point costs ${devPointCost:,}.\n"
            "The total cost of the points you use at this stop "
            "will be subtracted from your budget.\n"
            f"Current budget before this stop: ${team['budget']:,}"
        )
        text_31.setText(text_31.text + costInfo)
    # create starting attributes for key_resp_20
    key_resp_20.keys = []
    key_resp_20.rt = []
    _key_resp_20_allKeys = []
    # keep track of which components have finished
    devPause3Components = [text_31, key_resp_20]
    for thisComponent in devPause3Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "devPause3" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        # Run 'Each Frame' code from code_21
        if key_resp_20.keys and 'return' in key_resp_20.keys:
            continueRoutine = False
        
        
        # *text_31* updates
        
        # if text_31 is starting this frame...
        if text_31.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_31.frameNStart = frameN  # exact frame index
            text_31.tStart = t  # local t and not account for scr refresh
            text_31.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_31, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_31.started')
            # update status
            text_31.status = STARTED
            text_31.setAutoDraw(True)
        
        # if text_31 is active this frame...
        if text_31.status == STARTED:
            # update params
            pass
        
        # *key_resp_20* updates
        waitOnFlip = False
        
        # if key_resp_20 is starting this frame...
        if key_resp_20.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_20.frameNStart = frameN  # exact frame index
            key_resp_20.tStart = t  # local t and not account for scr refresh
            key_resp_20.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_20, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp_20.started')
            # update status
            key_resp_20.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_20.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_20.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_20.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_20.getKeys(keyList=['a','b','c','d','e','f','return'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_20_allKeys.extend(theseKeys)
            if len(_key_resp_20_allKeys):
                key_resp_20.keys = [key.name for key in _key_resp_20_allKeys]  # storing all keys
                key_resp_20.rt = [key.rt for key in _key_resp_20_allKeys]
                key_resp_20.duration = [key.duration for key in _key_resp_20_allKeys]
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in devPause3Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "devPause3" ---
    for thisComponent in devPause3Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('devPause3.stopped', globalClock.getTime(format='float'))
    # Run 'End Routine' code from code_21
    keys = key_resp_20.keys or []
    
    letters = []
    for k in keys:
        if k != 'return':
            letters.append(k.upper())
        if len(letters) == 8:
            break
    
    carMode = any(L in ['A','B','C','D','E'] for L in letters)
    fMode = ('F' in letters) and not carMode
    
    fw = rw = ch = uf = en = nx = 0
    
    if carMode:
        fw = letters.count('A')
        rw = letters.count('B')
        ch = letters.count('C')
        uf = letters.count('D')
        en = letters.count('E')
        pointsUsed = fw + rw + ch + uf + en
    
    elif fMode:
        nx = 8
        pointsUsed = 8
    
    else:
        pointsUsed = 0
    
    currentCarDev['frontWing'] += fw
    currentCarDev['rearWing'] += rw
    currentCarDev['chassis'] += ch
    currentCarDev['underfloor'] += uf
    currentCarDev['engine'] += en
    nextYearCarDev += nx
    
    Dev3_pointsUsed = pointsUsed
    
    totalCost3 = pointsUsed * devPointCost
    team['budget'] -= totalCost3
    
    if team['budget'] < 0:
        bankrupt = True
        fired = True
        endReasonText = "GAME OVER\nYou went over budget.\nPress spacebar to end."
    
    thisExp.addData('DevStop3_letters_raw', letters)
    thisExp.addData('DevStop3_pointsUsed', Dev3_pointsUsed)
    thisExp.addData('DevStop3_fw_added', Dev3_fw)
    thisExp.addData('DevStop3_rw_added', Dev3_rw)
    thisExp.addData('DevStop3_ch_added', Dev3_ch)
    thisExp.addData('DevStop3_uf_added', Dev3_uf)
    thisExp.addData('DevStop3_en_added', Dev3_en)
    thisExp.addData('DevStop3_ny_added', Dev3_ny)
    thisExp.addData('DevStop3_currentDev_frontWing_total', currentCarDev['frontWing'])
    thisExp.addData('DevStop3_currentDev_rearWing_total', currentCarDev['rearWing'])
    thisExp.addData('DevStop3_currentDev_chassis_total', currentCarDev['chassis'])
    thisExp.addData('DevStop3_currentDev_underfloor_total', currentCarDev['underfloor'])
    thisExp.addData('DevStop3_currentDev_engine_total', currentCarDev['engine'])
    thisExp.addData('DevStop3_nextYearDev_total', nextYearCarDev)
    thisExp.addData('DevStop3_totalDevCost', totalCost3)
    thisExp.addData('DevStop3_budget_after_cost', team['budget'])
    # check responses
    if key_resp_20.keys in ['', [], None]:  # No response was made
        key_resp_20.keys = None
    thisExp.addData('key_resp_20.keys',key_resp_20.keys)
    if key_resp_20.keys != None:  # we had a response
        thisExp.addData('key_resp_20.rt', key_resp_20.rt)
        thisExp.addData('key_resp_20.duration', key_resp_20.duration)
    thisExp.nextEntry()
    # the Routine "devPause3" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    trials_6 = data.TrialHandler(nReps=4.0, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='trials_6')
    thisExp.addLoop(trials_6)  # add the loop to the experiment
    thisTrial_6 = trials_6.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_6.rgb)
    if thisTrial_6 != None:
        for paramName in thisTrial_6:
            globals()[paramName] = thisTrial_6[paramName]
    
    for thisTrial_6 in trials_6:
        currentLoop = trials_6
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_6.rgb)
        if thisTrial_6 != None:
            for paramName in thisTrial_6:
                globals()[paramName] = thisTrial_6[paramName]
        
        # --- Prepare to start Routine "RaceS1Pt4" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('RaceS1Pt4.started', globalClock.getTime(format='float'))
        # Run 'Begin Routine' code from code_23
        raceIndexS1 += 1
        
        raceMessage = (
            f"Season 1 – Race {raceIndexS1}\n\n"
            f"Team: {team['name']}\n"
            f"Budget: ${team['budget']:,}\n\n"
            "Development levels (this season):\n"
            f"  Front wing: {currentCarDev['frontWing']}\n"
            f"  Rear wing: {currentCarDev['rearWing']}\n"
            f"  Chassis: {currentCarDev['chassis']}\n"
            f"  Underfloor: {currentCarDev['underfloor']}\n"
            f"  Engine: {currentCarDev['engine']}\n\n"
            f"Next-season research level: {nextYearCarDev}\n\n"
            "Press the spacebar to simulate this race."
        )
        
        text_33.setText(raceMessage)
        
        text_33.setText(raceMessage)
        # create starting attributes for key_resp_22
        key_resp_22.keys = []
        key_resp_22.rt = []
        _key_resp_22_allKeys = []
        # keep track of which components have finished
        RaceS1Pt4Components = [text_33, key_resp_22]
        for thisComponent in RaceS1Pt4Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "RaceS1Pt4" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            # Run 'Each Frame' code from code_23
            if 'space' in key_resp_22.keys:
                continueRoutine = False
            
            
            # *text_33* updates
            
            # if text_33 is starting this frame...
            if text_33.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_33.frameNStart = frameN  # exact frame index
                text_33.tStart = t  # local t and not account for scr refresh
                text_33.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_33, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_33.started')
                # update status
                text_33.status = STARTED
                text_33.setAutoDraw(True)
            
            # if text_33 is active this frame...
            if text_33.status == STARTED:
                # update params
                pass
            
            # *key_resp_22* updates
            waitOnFlip = False
            
            # if key_resp_22 is starting this frame...
            if key_resp_22.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_22.frameNStart = frameN  # exact frame index
                key_resp_22.tStart = t  # local t and not account for scr refresh
                key_resp_22.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_22, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_22.started')
                # update status
                key_resp_22.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_22.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_22.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_22.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_22.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _key_resp_22_allKeys.extend(theseKeys)
                if len(_key_resp_22_allKeys):
                    key_resp_22.keys = _key_resp_22_allKeys[-1].name  # just the last key pressed
                    key_resp_22.rt = _key_resp_22_allKeys[-1].rt
                    key_resp_22.duration = _key_resp_22_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in RaceS1Pt4Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "RaceS1Pt4" ---
        for thisComponent in RaceS1Pt4Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('RaceS1Pt4.stopped', globalClock.getTime(format='float'))
        # Run 'End Routine' code from code_23
        import random
        
        devTotal = (
            currentCarDev['frontWing'] +
            currentCarDev['rearWing'] +
            currentCarDev['chassis'] +
            currentCarDev['underfloor'] +
            currentCarDev['engine']
        )
        
        devBonus = devTotal * 2.0  
        
        teamScore = driverPerf + carPerf + devBonus 
        
        driverExp = team['driverRatings']['Experience']  # 0–100
        
        carStats = [
            currentCarDev['frontWing'],
            currentCarDev['rearWing'],
            currentCarDev['chassis'],
            currentCarDev['underfloor'],
            currentCarDev['engine']
        ]
        carAvg = sum(carStats) / len(carStats)
        
        finishScore = (driverExp + carAvg) / 2.0
        
        roll = random.uniform(0, 100)
        
        crashed = False
        s1AccidentMessage = "No accident"
        s1RepairCost = 0
        
        if roll > finishScore:
            crashed = True
            position = 20           
            racePoints = 0
            s1LastRacePosition = "DNF"
            s1LastRacePoints = 0
        
            if driverExp < carAvg:
                s1RepairCost = 1000000     
                s1AccidentMessage = f"The driver crashed. Cost: ${s1RepairCost:,}"
            else:
                s1RepairCost = 300000
                s1AccidentMessage = f"The car broke. Cost: ${s1RepairCost:,}"
            team['budget'] -= s1RepairCost
        
        if crashed:
            position = 20
        
        if team['budget'] < 0:
            bankrupt = True
            fired = True
            endReasonText = "GAME OVER\nYou went over budget.\nPress spacebar to close."
        
        
        thisExp.addData('s1AccidentMessage', s1AccidentMessage)
        thisExp.addData('s1RepairCost', s1RepairCost)
        
        if not crashed:
            aiScores = []
            for i in range(19):
                aiScore = random.uniform(0, 100)
                aiScores.append(aiScore)
            
            allScores = aiScores + [teamScore]
            sortedScores = sorted(allScores, reverse=True)
        
            position = sortedScores.index(teamScore) + 1  
            pointsTable = {
                1: 25, 2: 18, 3: 15, 4: 12, 5: 10,
                6: 8, 7: 6, 8: 4, 9: 2, 10: 1
            }
        
            racePoints = pointsTable.get(position, 0)
        
            s1SeasonPoints += racePoints
        
            s1LastRacePosition = position
            s1LastRacePoints = racePoints
        
        if boardPressure == "1":   # high pressure
            winBoost = 8
            midPenalty = -5
            crashPenalty = -25
        else:  # low pressure
            winBoost = 4
            midPenalty = -2
            crashPenalty = -12
        
        change = 0
        
        if crashed:
            change = crashPenalty
        elif position <= 5:
            change = winBoost
        else:
            change = midPenalty
        
        
        boardConfidence = boardConfidence + change
        
        if boardConfidence > 100:
            boardConfidence = 100
        if boardConfidence < 0:
            boardConfidence = 0
        
        if boardConfidence <= firingThreshold:
            fired = True
        
        thisExp.addData('boardConfidence', boardConfidence)
        thisExp.addData('boardPressureCondition', boardPressure)
        thisExp.addData('s1RaceIndex', raceIndexS1)
        thisExp.addData('s1Position', s1LastRacePosition)
        thisExp.addData('s1RacePoints', s1LastRacePoints)
        thisExp.addData('s1SeasonPoints_total', s1SeasonPoints)
        thisExp.addData('s1BudgetAfterRace', team['budget'])
        
        # check responses
        if key_resp_22.keys in ['', [], None]:  # No response was made
            key_resp_22.keys = None
        trials_6.addData('key_resp_22.keys',key_resp_22.keys)
        if key_resp_22.keys != None:  # we had a response
            trials_6.addData('key_resp_22.rt', key_resp_22.rt)
            trials_6.addData('key_resp_22.duration', key_resp_22.duration)
        # the Routine "RaceS1Pt4" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "RaceResultsS1" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('RaceResultsS1.started', globalClock.getTime(format='float'))
        # Run 'Begin Routine' code from code_22
        if fired or bankrupt: # if fired or bankrupt
            raceResultsMessage = ( # messsage
                "GAME OVER\n"
                "You have been fired.\n\n"
                "Press spacebar to end the study."
            )
            s1AccidentMessage = "" # make it blank here
        else: # otherwise
            raceResultsMessage = ( # message
                f"Season 1 – Race {raceIndexS1}\n\n"
                f"Finishing position: P{s1LastRacePosition}\n"
                f"Points this race: {s1LastRacePoints}\n"
                f"Total season points: {s1SeasonPoints}\n\n"
                f"Board confidence: {int(boardConfidence)}%\n"
                f"Budget: ${team['budget']:,}\n\n"
                "Press spacebar to continue."
            )
        
        text_32.setText(raceResultsMessage) # show text
        text_36.setText(s1AccidentMessage) # show text
        
        # NOTE similar idea for for RaceResultsS1 (race results season 2)
        
        # create starting attributes for key_resp_21
        key_resp_21.keys = []
        key_resp_21.rt = []
        _key_resp_21_allKeys = []
        text_32.setText(raceResultsMessage)
        text_36.setText(s1AccidentMessage)
        # keep track of which components have finished
        RaceResultsS1Components = [key_resp_21, text_32, text_36]
        for thisComponent in RaceResultsS1Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "RaceResultsS1" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *key_resp_21* updates
            waitOnFlip = False
            
            # if key_resp_21 is starting this frame...
            if key_resp_21.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_21.frameNStart = frameN  # exact frame index
                key_resp_21.tStart = t  # local t and not account for scr refresh
                key_resp_21.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_21, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_21.started')
                # update status
                key_resp_21.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_21.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_21.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_21.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_21.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _key_resp_21_allKeys.extend(theseKeys)
                if len(_key_resp_21_allKeys):
                    key_resp_21.keys = _key_resp_21_allKeys[-1].name  # just the last key pressed
                    key_resp_21.rt = _key_resp_21_allKeys[-1].rt
                    key_resp_21.duration = _key_resp_21_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # *text_32* updates
            
            # if text_32 is starting this frame...
            if text_32.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_32.frameNStart = frameN  # exact frame index
                text_32.tStart = t  # local t and not account for scr refresh
                text_32.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_32, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_32.started')
                # update status
                text_32.status = STARTED
                text_32.setAutoDraw(True)
            
            # if text_32 is active this frame...
            if text_32.status == STARTED:
                # update params
                pass
            
            # *text_36* updates
            
            # if text_36 is starting this frame...
            if text_36.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_36.frameNStart = frameN  # exact frame index
                text_36.tStart = t  # local t and not account for scr refresh
                text_36.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_36, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_36.started')
                # update status
                text_36.status = STARTED
                text_36.setAutoDraw(True)
            
            # if text_36 is active this frame...
            if text_36.status == STARTED:
                # update params
                pass
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in RaceResultsS1Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "RaceResultsS1" ---
        for thisComponent in RaceResultsS1Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('RaceResultsS1.stopped', globalClock.getTime(format='float'))
        # Run 'End Routine' code from code_22
        if fired or bankrupt: # if fired or bankrupt
            thisExp.status = FINISHED # done!
        
        # check responses
        if key_resp_21.keys in ['', [], None]:  # No response was made
            key_resp_21.keys = None
        trials_6.addData('key_resp_21.keys',key_resp_21.keys)
        if key_resp_21.keys != None:  # we had a response
            trials_6.addData('key_resp_21.rt', key_resp_21.rt)
            trials_6.addData('key_resp_21.duration', key_resp_21.duration)
        # the Routine "RaceResultsS1" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 4.0 repeats of 'trials_6'
    
    
    # --- Prepare to start Routine "season1Summary" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('season1Summary.started', globalClock.getTime(format='float'))
    # Run 'Begin Routine' code from code_25
    season1SummaryMessage = ( # show message
        f"SEASON 1 SUMMARY\n\n"
        f"Final Position Last Race: P{s1LastRacePosition}\n"
        f"Last Race Points: {s1LastRacePoints}\n"
        f"Total Season Points: {s1SeasonPoints}\n"
        f"Board Confidence: {int(boardConfidence)}%\n"
        f"Remaining Budget: ${team['budget']:,}\n\n"
        "Press spacebar to continue."
    )
    
    text_35.text = season1SummaryMessage # update text for screen
    
    # create starting attributes for key_resp_24
    key_resp_24.keys = []
    key_resp_24.rt = []
    _key_resp_24_allKeys = []
    text_35.setText(season1SummaryMessage)
    # keep track of which components have finished
    season1SummaryComponents = [key_resp_24, text_35]
    for thisComponent in season1SummaryComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "season1Summary" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *key_resp_24* updates
        waitOnFlip = False
        
        # if key_resp_24 is starting this frame...
        if key_resp_24.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_24.frameNStart = frameN  # exact frame index
            key_resp_24.tStart = t  # local t and not account for scr refresh
            key_resp_24.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_24, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp_24.started')
            # update status
            key_resp_24.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_24.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_24.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_24.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_24.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_24_allKeys.extend(theseKeys)
            if len(_key_resp_24_allKeys):
                key_resp_24.keys = _key_resp_24_allKeys[-1].name  # just the last key pressed
                key_resp_24.rt = _key_resp_24_allKeys[-1].rt
                key_resp_24.duration = _key_resp_24_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # *text_35* updates
        
        # if text_35 is starting this frame...
        if text_35.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_35.frameNStart = frameN  # exact frame index
            text_35.tStart = t  # local t and not account for scr refresh
            text_35.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_35, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_35.started')
            # update status
            text_35.status = STARTED
            text_35.setAutoDraw(True)
        
        # if text_35 is active this frame...
        if text_35.status == STARTED:
            # update params
            pass
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in season1SummaryComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "season1Summary" ---
    for thisComponent in season1SummaryComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('season1Summary.stopped', globalClock.getTime(format='float'))
    # check responses
    if key_resp_24.keys in ['', [], None]:  # No response was made
        key_resp_24.keys = None
    thisExp.addData('key_resp_24.keys',key_resp_24.keys)
    if key_resp_24.keys != None:  # we had a response
        thisExp.addData('key_resp_24.rt', key_resp_24.rt)
        thisExp.addData('key_resp_24.duration', key_resp_24.duration)
    thisExp.nextEntry()
    # the Routine "season1Summary" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "season2Introduction" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('season2Introduction.started', globalClock.getTime(format='float'))
    # Run 'Begin Routine' code from code_15
    # move to Season 2
    season = 2
    # reset budget
    team['budget'] = 140000000
    
    # reset the per-season car dev stats (season 1 permanent upgrades still apply)
    currentCarDev['frontWing'] = 0
    currentCarDev['rearWing'] = 0
    currentCarDev['chassis'] = 0
    currentCarDev['underfloor'] = 0
    currentCarDev['engine'] = 0
    # summary message for season 2 prep
    season2Message = (
        "SEASON 2\n\n"
        f"Team: {team['name']}\n"
        f"Current Budget: ${team['budget']:,}\n\n"
        
        "Your budget has been reset for the start of season 2.\n"
        "This means you begin the new season with a fresh $140,000,000,\n"
        "regardless of how much you had left at the end of season 1.\n\n"
        
        "Your car development levels for this new season have also been reset.\n"
        "However, the upgrades you earned from season 1 carry over\n"
        "and continue to improve your overall race performance.\n\n"
        
        "Any development points you chose to send forward from season 1\n"
        "are now available for upgrading your season 2 car.\n\n"
        f"Development points available for season 2: {nextYearCarDev}\n\n"
        
        "Press spacebar to begin upgrading your season 2 car.\n"
        "(If you have no saved development points, press space still.)"
    )
    
    text_37.setText(season2Message)
    # create starting attributes for key_resp_25
    key_resp_25.keys = []
    key_resp_25.rt = []
    _key_resp_25_allKeys = []
    # keep track of which components have finished
    season2IntroductionComponents = [text_37, key_resp_25]
    for thisComponent in season2IntroductionComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "season2Introduction" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_37* updates
        
        # if text_37 is starting this frame...
        if text_37.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_37.frameNStart = frameN  # exact frame index
            text_37.tStart = t  # local t and not account for scr refresh
            text_37.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_37, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_37.started')
            # update status
            text_37.status = STARTED
            text_37.setAutoDraw(True)
        
        # if text_37 is active this frame...
        if text_37.status == STARTED:
            # update params
            pass
        
        # *key_resp_25* updates
        waitOnFlip = False
        
        # if key_resp_25 is starting this frame...
        if key_resp_25.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_25.frameNStart = frameN  # exact frame index
            key_resp_25.tStart = t  # local t and not account for scr refresh
            key_resp_25.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_25, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp_25.started')
            # update status
            key_resp_25.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_25.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_25.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_25.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_25.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_25_allKeys.extend(theseKeys)
            if len(_key_resp_25_allKeys):
                key_resp_25.keys = _key_resp_25_allKeys[-1].name  # just the last key pressed
                key_resp_25.rt = _key_resp_25_allKeys[-1].rt
                key_resp_25.duration = _key_resp_25_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in season2IntroductionComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "season2Introduction" ---
    for thisComponent in season2IntroductionComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('season2Introduction.stopped', globalClock.getTime(format='float'))
    # check responses
    if key_resp_25.keys in ['', [], None]:  # No response was made
        key_resp_25.keys = None
    thisExp.addData('key_resp_25.keys',key_resp_25.keys)
    if key_resp_25.keys != None:  # we had a response
        thisExp.addData('key_resp_25.rt', key_resp_25.rt)
        thisExp.addData('key_resp_25.duration', key_resp_25.duration)
    thisExp.nextEntry()
    # the Routine "season2Introduction" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "season2DevPts" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('season2DevPts.started', globalClock.getTime(format='float'))
    # Run 'Begin Routine' code from code_36
    if nextYearCarDev <= 0: # if lacking delayed dev pts
        continueRoutine = False # next!
    else:
        season2DevMessage = ( # development message
            "SEASON 2 DEVELOPMENT POINTS\n\n"
            f"You saved {nextYearCarDev} development point(s) from Season 1.\n"
            "These points represent research you already paid for earlier,\n"
            "so using them now does NOT reduce your current budget.\n\n"
            "Press A-E to assign points:\n"
            "  A = Front Wing\n"
            "  B = Rear Wing\n"
            "  C = Chassis\n"
            "  D = Underfloor\n"
            "  E = Engine\n\n"
            f"You may use up to {nextYearCarDev} point(s) now.\n"
            "Press enter when you are finished."
        )
    
        text_49.setText(season2DevMessage) # show instructions
    
    # create starting attributes for key_resp_36
    key_resp_36.keys = []
    key_resp_36.rt = []
    _key_resp_36_allKeys = []
    text_49.setText(season2DevMessage)
    # keep track of which components have finished
    season2DevPtsComponents = [key_resp_36, text_49]
    for thisComponent in season2DevPtsComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "season2DevPts" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        # Run 'Each Frame' code from code_36
        if key_resp_36.keys and 'return' in key_resp_36.keys: # if enter is pressed
            continueRoutine = False # next!
        
        
        # *key_resp_36* updates
        waitOnFlip = False
        
        # if key_resp_36 is starting this frame...
        if key_resp_36.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_36.frameNStart = frameN  # exact frame index
            key_resp_36.tStart = t  # local t and not account for scr refresh
            key_resp_36.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_36, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp_36.started')
            # update status
            key_resp_36.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_36.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_36.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_36.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_36.getKeys(keyList=['a','b','c','d','e','return'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_36_allKeys.extend(theseKeys)
            if len(_key_resp_36_allKeys):
                key_resp_36.keys = [key.name for key in _key_resp_36_allKeys]  # storing all keys
                key_resp_36.rt = [key.rt for key in _key_resp_36_allKeys]
                key_resp_36.duration = [key.duration for key in _key_resp_36_allKeys]
        
        # *text_49* updates
        
        # if text_49 is starting this frame...
        if text_49.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_49.frameNStart = frameN  # exact frame index
            text_49.tStart = t  # local t and not account for scr refresh
            text_49.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_49, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_49.started')
            # update status
            text_49.status = STARTED
            text_49.setAutoDraw(True)
        
        # if text_49 is active this frame...
        if text_49.status == STARTED:
            # update params
            pass
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in season2DevPtsComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "season2DevPts" ---
    for thisComponent in season2DevPtsComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('season2DevPts.stopped', globalClock.getTime(format='float'))
    # Run 'End Routine' code from code_36
    keys = key_resp_36.keys or [] # store keys pressed
    
    letters = [k.upper() for k in keys if k.lower() != 'return'] # make keys lower case, ignore return button
    # limit list to max number of dev pts available
    letters = letters[:nextYearCarDev]
    # pts assigned to part
    S2Dev_fw = letters.count('A')
    S2Dev_rw = letters.count('B')
    S2Dev_ch = letters.count('C')
    S2Dev_uf = letters.count('D')
    S2Dev_en = letters.count('E')
    # pts used
    S2Dev_pointsUsed = len(letters)
    # add upgrades
    currentCarDev['frontWing'] += S2Dev_fw
    currentCarDev['rearWing'] += S2Dev_rw
    currentCarDev['chassis'] += S2Dev_ch
    currentCarDev['underfloor'] += S2Dev_uf
    currentCarDev['engine'] += S2Dev_en
    # subtract the used pts
    nextYearCarDev -= S2Dev_pointsUsed
    if nextYearCarDev < 0: # ensure user cant go negative w/ dev pts
        nextYearCarDev = 0
    
    # check responses
    if key_resp_36.keys in ['', [], None]:  # No response was made
        key_resp_36.keys = None
    thisExp.addData('key_resp_36.keys',key_resp_36.keys)
    if key_resp_36.keys != None:  # we had a response
        thisExp.addData('key_resp_36.rt', key_resp_36.rt)
        thisExp.addData('key_resp_36.duration', key_resp_36.duration)
    thisExp.nextEntry()
    # the Routine "season2DevPts" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    trials_7 = data.TrialHandler(nReps=2.0, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='trials_7')
    thisExp.addLoop(trials_7)  # add the loop to the experiment
    thisTrial_7 = trials_7.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_7.rgb)
    if thisTrial_7 != None:
        for paramName in thisTrial_7:
            globals()[paramName] = thisTrial_7[paramName]
    
    for thisTrial_7 in trials_7:
        currentLoop = trials_7
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_7.rgb)
        if thisTrial_7 != None:
            for paramName in thisTrial_7:
                globals()[paramName] = thisTrial_7[paramName]
        
        # --- Prepare to start Routine "RaceS2Pt1" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('RaceS2Pt1.started', globalClock.getTime(format='float'))
        # Run 'Begin Routine' code from code_26
        raceIndexS2 = raceIndexS2 + 1  
        
        raceMessage = (
            "Season 2 – Race " + str(raceIndexS2) + "\n\n"
            "Team: " + team['name'] + "\n"
            "Budget: $" + str(team['budget']) + "\n\n"
            "Development levels (this season):\n"
            "  Front wing: " + str(currentCarDev['frontWing']) + "\n"
            "  Rear wing: " + str(currentCarDev['rearWing']) + "\n"
            "  Chassis: " + str(currentCarDev['chassis']) + "\n"
            "  Underfloor: " + str(currentCarDev['underfloor']) + "\n"
            "  Engine: " + str(currentCarDev['engine']) + "\n\n"
            "Next-season research level: " + str(nextYearCarDev) + "\n\n"
            "Press the spacebar to simulate this race."
        )
        
        text_38.setText(raceMessage)
        
        
        
        # create starting attributes for key_resp_26
        key_resp_26.keys = []
        key_resp_26.rt = []
        _key_resp_26_allKeys = []
        text_38.setText(raceMessage)
        # keep track of which components have finished
        RaceS2Pt1Components = [key_resp_26, text_38]
        for thisComponent in RaceS2Pt1Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "RaceS2Pt1" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            # Run 'Each Frame' code from code_26
            if 'space' in key_resp_26.keys:
                continueRoutine = False
            
            # *key_resp_26* updates
            waitOnFlip = False
            
            # if key_resp_26 is starting this frame...
            if key_resp_26.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_26.frameNStart = frameN  # exact frame index
                key_resp_26.tStart = t  # local t and not account for scr refresh
                key_resp_26.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_26, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_26.started')
                # update status
                key_resp_26.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_26.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_26.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_26.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_26.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _key_resp_26_allKeys.extend(theseKeys)
                if len(_key_resp_26_allKeys):
                    key_resp_26.keys = _key_resp_26_allKeys[-1].name  # just the last key pressed
                    key_resp_26.rt = _key_resp_26_allKeys[-1].rt
                    key_resp_26.duration = _key_resp_26_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # *text_38* updates
            
            # if text_38 is starting this frame...
            if text_38.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_38.frameNStart = frameN  # exact frame index
                text_38.tStart = t  # local t and not account for scr refresh
                text_38.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_38, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_38.started')
                # update status
                text_38.status = STARTED
                text_38.setAutoDraw(True)
            
            # if text_38 is active this frame...
            if text_38.status == STARTED:
                # update params
                pass
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in RaceS2Pt1Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "RaceS2Pt1" ---
        for thisComponent in RaceS2Pt1Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('RaceS2Pt1.stopped', globalClock.getTime(format='float'))
        # Run 'End Routine' code from code_26
        import random
        
        devTotal = (
            currentCarDev['frontWing'] +
            currentCarDev['rearWing'] +
            currentCarDev['chassis'] +
            currentCarDev['underfloor'] +
            currentCarDev['engine']
        )
        
        devBonus = devTotal * 2.0 
        teamScore = driverPerf + carPerf + devBonus 
        
        driverExp = team['driverRatings']['Experience']
        
        carStats = [
            currentCarDev['frontWing'],
            currentCarDev['rearWing'],
            currentCarDev['chassis'],
            currentCarDev['underfloor'],
            currentCarDev['engine']
        ]
        carAvg = sum(carStats) / len(carStats)
        
        finishScore = (driverExp + carAvg) / 2.0
        
        roll = random.uniform(0, 100)
        
        crashed = False
        s2AccidentMessage = "No accident"
        s2RepairCost = 0
        
        if roll > finishScore:
            crashed = True
            position = 20
            racePoints = 0
            s2LastRacePosition = "DNF"
            s2LastRacePoints = 0
        
            if driverExp < carAvg:
                s2RepairCost = 1000000
                s2AccidentMessage = f"The driver crashed. Cost: ${s2RepairCost:,}"
            else:
                s2RepairCost = 300000 
                s2AccidentMessage = f"The car broke. Cost: ${s2RepairCost:,}"
            team['budget'] -= s2RepairCost
        
        if crashed:
            position = 20
        
        if team['budget'] < 0:
            bankrupt = True
            fired = True
            endReasonText = "GAME OVER\nYou went over budget.\nPress spacebar to close."
        
        thisExp.addData('s2AccidentMessage', s2AccidentMessage)
        thisExp.addData('s2RepairCost', s2RepairCost)
        if not crashed:
            aiScores = []
            for i in range(19):
                aiScore = random.uniform(0, 100)
                aiScores.append(aiScore)
        
            allScores = aiScores + [teamScore]
            sortedScores = sorted(allScores, reverse=True)
        
            position = sortedScores.index(teamScore) + 1  # 1 = P1
        
            pointsTable = {
                1: 25, 2: 18, 3: 15, 4: 12, 5: 10,
                6: 8, 7: 6, 8: 4, 9: 2, 10: 1
            }
        
            racePoints = pointsTable.get(position, 0)
        
            s2SeasonPoints += racePoints
        
            s2LastRacePosition = position
            s2LastRacePoints = racePoints
        
        if boardPressure == "1":  
            winBoost = 8
            midPenalty = -5
            crashPenalty = -25
        else: 
            winBoost = 4
            midPenalty = -2
            crashPenalty = -12
        
        change = 0
        
        if crashed:
            change = crashPenalty
        elif position <= 5:
            change = winBoost
        else:
            change = midPenalty
        
        boardConfidence = boardConfidence + change
        
        if boardConfidence > 100:
            boardConfidence = 100
        if boardConfidence < 0:
            boardConfidence = 0
        
        if boardConfidence <= firingThreshold:
            fired = True
        
        thisExp.addData('boardConfidence', boardConfidence)
        thisExp.addData('boardPressureCondition', boardPressure)
        thisExp.addData('s2RaceIndex', raceIndexS2)
        thisExp.addData('s2Position', s2LastRacePosition)
        thisExp.addData('s2RacePoints', s2LastRacePoints)
        thisExp.addData('s2SeasonPoints_total', s2SeasonPoints)
        thisExp.addData('s2BudgetAfterRace', team['budget'])
        
        # check responses
        if key_resp_26.keys in ['', [], None]:  # No response was made
            key_resp_26.keys = None
        trials_7.addData('key_resp_26.keys',key_resp_26.keys)
        if key_resp_26.keys != None:  # we had a response
            trials_7.addData('key_resp_26.rt', key_resp_26.rt)
            trials_7.addData('key_resp_26.duration', key_resp_26.duration)
        # the Routine "RaceS2Pt1" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "RaceResultsS2" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('RaceResultsS2.started', globalClock.getTime(format='float'))
        # Run 'Begin Routine' code from code_30
        if fired or bankrupt:
            raceResultsMessage2 = (
                "GAME OVER\n"
                "You have been fired.\n\n"
                "Press spacebar to end the study."
            )
            s2AccidentMessage = ""
        else:
            raceResultsMessage2 = (
                f"Season 2 – Race {raceIndexS2}\n\n"
                f"Final Position: P{s2LastRacePosition}\n"
                f"Points This Race: {s2LastRacePoints}\n"
                f"Total Season Points: {s2SeasonPoints}\n\n"
                f"Board Confidence (after this race): {int(boardConfidence)}%\n\n"
                f"Updated Budget: ${team['budget']:,}\n\n"
                "Press spacebar to continue."
            )
        
        text_42.setText(raceResultsMessage2)
        text_43.setText(s2AccidentMessage)
        
        text_42.setText(raceResultsMessage2)
        text_43.setText(s2AccidentMessage)
        # create starting attributes for key_resp_30
        key_resp_30.keys = []
        key_resp_30.rt = []
        _key_resp_30_allKeys = []
        # keep track of which components have finished
        RaceResultsS2Components = [text_42, text_43, key_resp_30]
        for thisComponent in RaceResultsS2Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "RaceResultsS2" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_42* updates
            
            # if text_42 is starting this frame...
            if text_42.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_42.frameNStart = frameN  # exact frame index
                text_42.tStart = t  # local t and not account for scr refresh
                text_42.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_42, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_42.started')
                # update status
                text_42.status = STARTED
                text_42.setAutoDraw(True)
            
            # if text_42 is active this frame...
            if text_42.status == STARTED:
                # update params
                pass
            
            # *text_43* updates
            
            # if text_43 is starting this frame...
            if text_43.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_43.frameNStart = frameN  # exact frame index
                text_43.tStart = t  # local t and not account for scr refresh
                text_43.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_43, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_43.started')
                # update status
                text_43.status = STARTED
                text_43.setAutoDraw(True)
            
            # if text_43 is active this frame...
            if text_43.status == STARTED:
                # update params
                pass
            
            # *key_resp_30* updates
            waitOnFlip = False
            
            # if key_resp_30 is starting this frame...
            if key_resp_30.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_30.frameNStart = frameN  # exact frame index
                key_resp_30.tStart = t  # local t and not account for scr refresh
                key_resp_30.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_30, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_30.started')
                # update status
                key_resp_30.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_30.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_30.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_30.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_30.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _key_resp_30_allKeys.extend(theseKeys)
                if len(_key_resp_30_allKeys):
                    key_resp_30.keys = _key_resp_30_allKeys[-1].name  # just the last key pressed
                    key_resp_30.rt = _key_resp_30_allKeys[-1].rt
                    key_resp_30.duration = _key_resp_30_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in RaceResultsS2Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "RaceResultsS2" ---
        for thisComponent in RaceResultsS2Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('RaceResultsS2.stopped', globalClock.getTime(format='float'))
        # Run 'End Routine' code from code_30
        if fired or bankrupt:
            thisExp.status = FINISHED
        
        # check responses
        if key_resp_30.keys in ['', [], None]:  # No response was made
            key_resp_30.keys = None
        trials_7.addData('key_resp_30.keys',key_resp_30.keys)
        if key_resp_30.keys != None:  # we had a response
            trials_7.addData('key_resp_30.rt', key_resp_30.rt)
            trials_7.addData('key_resp_30.duration', key_resp_30.duration)
        # the Routine "RaceResultsS2" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 2.0 repeats of 'trials_7'
    
    
    # --- Prepare to start Routine "devPause4" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('devPause4.started', globalClock.getTime(format='float'))
    # Run 'Begin Routine' code from code_31
    if fired or bankrupt:
        text_44.text = endReasonText
        continueRoutine = False
    else:
        costInfo = (
            f"\n\nEach development point costs ${devPointCost:,}.\n"
            "The total cost of the points you use at this stop "
            "will be subtracted from your budget.\n"
            f"Current budget before this stop: ${team['budget']:,}"
        )
        text_44.setText(text_44.text + costInfo)
    # create starting attributes for key_resp_31
    key_resp_31.keys = []
    key_resp_31.rt = []
    _key_resp_31_allKeys = []
    # keep track of which components have finished
    devPause4Components = [key_resp_31, text_44]
    for thisComponent in devPause4Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "devPause4" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        # Run 'Each Frame' code from code_31
        if key_resp_31.keys and 'return' in key_resp_31.keys:
            continueRoutine = False
        
        
        # *key_resp_31* updates
        waitOnFlip = False
        
        # if key_resp_31 is starting this frame...
        if key_resp_31.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_31.frameNStart = frameN  # exact frame index
            key_resp_31.tStart = t  # local t and not account for scr refresh
            key_resp_31.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_31, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp_31.started')
            # update status
            key_resp_31.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_31.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_31.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_31.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_31.getKeys(keyList=['a','b','c','d','e','return'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_31_allKeys.extend(theseKeys)
            if len(_key_resp_31_allKeys):
                key_resp_31.keys = [key.name for key in _key_resp_31_allKeys]  # storing all keys
                key_resp_31.rt = [key.rt for key in _key_resp_31_allKeys]
                key_resp_31.duration = [key.duration for key in _key_resp_31_allKeys]
        
        # *text_44* updates
        
        # if text_44 is starting this frame...
        if text_44.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_44.frameNStart = frameN  # exact frame index
            text_44.tStart = t  # local t and not account for scr refresh
            text_44.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_44, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_44.started')
            # update status
            text_44.status = STARTED
            text_44.setAutoDraw(True)
        
        # if text_44 is active this frame...
        if text_44.status == STARTED:
            # update params
            pass
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in devPause4Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "devPause4" ---
    for thisComponent in devPause4Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('devPause4.stopped', globalClock.getTime(format='float'))
    # Run 'End Routine' code from code_31
    keys = key_resp_31.keys or []
    
    letters = []
    for k in keys:
        if k != 'return':
            L = k.upper()
            if L in ['A','B','C','D','E']:
                letters.append(L)
        if len(letters) == 8:
            break
    
    fw = letters.count('A')
    rw = letters.count('B')
    ch = letters.count('C')
    uf = letters.count('D')
    en = letters.count('E')
    
    currentCarDev['frontWing'] += fw
    currentCarDev['rearWing'] += rw
    currentCarDev['chassis'] += ch
    currentCarDev['underfloor'] += uf
    currentCarDev['engine'] += en
    
    Dev4_pointsUsed = len(letters)
    totalCost4 = Dev4_pointsUsed * devPointCost
    team['budget'] -= totalCost4
    
    if team['budget'] < 0:
        bankrupt = True
        fired = True
        endReasonText = "GAME OVER\nYou went over budget.\nPress spacebar to end."
    
    thisExp.addData('DevStop4_letters_raw', letters)
    thisExp.addData('DevStop4_pointsUsed', Dev4_pointsUsed)
    thisExp.addData('DevStop4_fw_added', Dev4_fw)
    thisExp.addData('DevStop4_rw_added', Dev4_rw)
    thisExp.addData('DevStop4_ch_added', Dev4_ch)
    thisExp.addData('DevStop4_uf_added', Dev4_uf)
    thisExp.addData('DevStop4_en_added', Dev4_en)
    thisExp.addData('DevStop4_currentDev_frontWing_total', currentCarDev['frontWing'])
    thisExp.addData('DevStop4_currentDev_rearWing_total', currentCarDev['rearWing'])
    thisExp.addData('DevStop4_currentDev_chassis_total', currentCarDev['chassis'])
    thisExp.addData('DevStop4_currentDev_underfloor_total', currentCarDev['underfloor'])
    thisExp.addData('DevStop4_currentDev_engine_total', currentCarDev['engine'])
    thisExp.addData('DevStop4_totalDevCost', totalCost4)
    thisExp.addData('DevStop4_budget_after_cost', team['budget'])
    # check responses
    if key_resp_31.keys in ['', [], None]:  # No response was made
        key_resp_31.keys = None
    thisExp.addData('key_resp_31.keys',key_resp_31.keys)
    if key_resp_31.keys != None:  # we had a response
        thisExp.addData('key_resp_31.rt', key_resp_31.rt)
        thisExp.addData('key_resp_31.duration', key_resp_31.duration)
    thisExp.nextEntry()
    # the Routine "devPause4" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    trials_8 = data.TrialHandler(nReps=2.0, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='trials_8')
    thisExp.addLoop(trials_8)  # add the loop to the experiment
    thisTrial_8 = trials_8.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_8.rgb)
    if thisTrial_8 != None:
        for paramName in thisTrial_8:
            globals()[paramName] = thisTrial_8[paramName]
    
    for thisTrial_8 in trials_8:
        currentLoop = trials_8
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_8.rgb)
        if thisTrial_8 != None:
            for paramName in thisTrial_8:
                globals()[paramName] = thisTrial_8[paramName]
        
        # --- Prepare to start Routine "RaceS2Pt2" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('RaceS2Pt2.started', globalClock.getTime(format='float'))
        # Run 'Begin Routine' code from code_27
        raceIndexS2 = raceIndexS2 + 1 
        
        raceMessage = (
            "Season 2 – Race " + str(raceIndexS2) + "\n\n"
            "Team: " + team['name'] + "\n"
            "Budget: $" + str(team['budget']) + "\n\n"
            "Development levels (this season):\n"
            "  Front wing: " + str(currentCarDev['frontWing']) + "\n"
            "  Rear wing: " + str(currentCarDev['rearWing']) + "\n"
            "  Chassis: " + str(currentCarDev['chassis']) + "\n"
            "  Underfloor: " + str(currentCarDev['underfloor']) + "\n"
            "  Engine: " + str(currentCarDev['engine']) + "\n\n"
            "Next-season research level: " + str(nextYearCarDev) + "\n\n"
            "Press the spacebar to simulate this race."
        )
        
        text_39.setText(raceMessage)
        
        
        # create starting attributes for key_resp_27
        key_resp_27.keys = []
        key_resp_27.rt = []
        _key_resp_27_allKeys = []
        text_39.setText(raceMessage)
        # keep track of which components have finished
        RaceS2Pt2Components = [key_resp_27, text_39]
        for thisComponent in RaceS2Pt2Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "RaceS2Pt2" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            # Run 'Each Frame' code from code_27
            if 'space' in key_resp_27.keys:
                continueRoutine = False
            
            # *key_resp_27* updates
            waitOnFlip = False
            
            # if key_resp_27 is starting this frame...
            if key_resp_27.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_27.frameNStart = frameN  # exact frame index
                key_resp_27.tStart = t  # local t and not account for scr refresh
                key_resp_27.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_27, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_27.started')
                # update status
                key_resp_27.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_27.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_27.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_27.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_27.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _key_resp_27_allKeys.extend(theseKeys)
                if len(_key_resp_27_allKeys):
                    key_resp_27.keys = _key_resp_27_allKeys[-1].name  # just the last key pressed
                    key_resp_27.rt = _key_resp_27_allKeys[-1].rt
                    key_resp_27.duration = _key_resp_27_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # *text_39* updates
            
            # if text_39 is starting this frame...
            if text_39.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_39.frameNStart = frameN  # exact frame index
                text_39.tStart = t  # local t and not account for scr refresh
                text_39.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_39, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_39.started')
                # update status
                text_39.status = STARTED
                text_39.setAutoDraw(True)
            
            # if text_39 is active this frame...
            if text_39.status == STARTED:
                # update params
                pass
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in RaceS2Pt2Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "RaceS2Pt2" ---
        for thisComponent in RaceS2Pt2Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('RaceS2Pt2.stopped', globalClock.getTime(format='float'))
        # Run 'End Routine' code from code_27
        import random
        
        devTotal = (
            currentCarDev['frontWing'] +
            currentCarDev['rearWing'] +
            currentCarDev['chassis'] +
            currentCarDev['underfloor'] +
            currentCarDev['engine']
        )
        
        devBonus = devTotal * 2.0 
        teamScore = driverPerf + carPerf + devBonus 
        
        driverExp = team['driverRatings']['Experience']
        
        carStats = [
            currentCarDev['frontWing'],
            currentCarDev['rearWing'],
            currentCarDev['chassis'],
            currentCarDev['underfloor'],
            currentCarDev['engine']
        ]
        carAvg = sum(carStats) / len(carStats)
        
        finishScore = (driverExp + carAvg) / 2.0
        
        roll = random.uniform(0, 100)
        
        crashed = False
        s2AccidentMessage = "No accident"
        s2RepairCost = 0
        
        if roll > finishScore:
            crashed = True
            position = 20
            racePoints = 0
            s2LastRacePosition = "DNF"
            s2LastRacePoints = 0
        
            if driverExp < carAvg:
                s2RepairCost = 1000000
                s2AccidentMessage = f"The driver crashed. Cost: ${s2RepairCost:,}"
            else:
                s2RepairCost = 300000 
                s2AccidentMessage = f"The car broke. Cost: ${s2RepairCost:,}"
            team['budget'] -= s2RepairCost
        
        if crashed:
            position = 20
        
        if team['budget'] < 0:
            bankrupt = True
            fired = True
            endReasonText = "GAME OVER\nYou went over budget.\nPress spacebar to close."
        
        thisExp.addData('s2AccidentMessage', s2AccidentMessage)
        thisExp.addData('s2RepairCost', s2RepairCost)
        
        if not crashed:
            aiScores = []
            for i in range(19):
                aiScore = random.uniform(0, 100)
                aiScores.append(aiScore)
        
            allScores = aiScores + [teamScore]
            sortedScores = sorted(allScores, reverse=True)
        
            position = sortedScores.index(teamScore) + 1  # 1 = P1
        
            pointsTable = {
                1: 25, 2: 18, 3: 15, 4: 12, 5: 10,
                6: 8, 7: 6, 8: 4, 9: 2, 10: 1
            }
        
            racePoints = pointsTable.get(position, 0)
        
            s2SeasonPoints += racePoints
        
            s2LastRacePosition = position
            s2LastRacePoints = racePoints
        
        if boardPressure == "1":  
            winBoost = 8
            midPenalty = -5
            crashPenalty = -25
        else: 
            winBoost = 4
            midPenalty = -2
            crashPenalty = -12
        
        change = 0
        
        if crashed:
            change = crashPenalty
        elif position <= 5:
            change = winBoost
        else:
            change = midPenalty
        
        boardConfidence = boardConfidence + change
        
        if boardConfidence > 100:
            boardConfidence = 100
        if boardConfidence < 0:
            boardConfidence = 0
        
        if boardConfidence <= firingThreshold:
            fired = True
        
        thisExp.addData('boardConfidence', boardConfidence)
        thisExp.addData('boardPressureCondition', boardPressure)
        thisExp.addData('s2RaceIndex', raceIndexS2)
        thisExp.addData('s2Position', s2LastRacePosition)
        thisExp.addData('s2RacePoints', s2LastRacePoints)
        thisExp.addData('s2SeasonPoints_total', s2SeasonPoints)
        thisExp.addData('s2BudgetAfterRace', team['budget'])
        
        # check responses
        if key_resp_27.keys in ['', [], None]:  # No response was made
            key_resp_27.keys = None
        trials_8.addData('key_resp_27.keys',key_resp_27.keys)
        if key_resp_27.keys != None:  # we had a response
            trials_8.addData('key_resp_27.rt', key_resp_27.rt)
            trials_8.addData('key_resp_27.duration', key_resp_27.duration)
        # the Routine "RaceS2Pt2" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "RaceResultsS2" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('RaceResultsS2.started', globalClock.getTime(format='float'))
        # Run 'Begin Routine' code from code_30
        if fired or bankrupt:
            raceResultsMessage2 = (
                "GAME OVER\n"
                "You have been fired.\n\n"
                "Press spacebar to end the study."
            )
            s2AccidentMessage = ""
        else:
            raceResultsMessage2 = (
                f"Season 2 – Race {raceIndexS2}\n\n"
                f"Final Position: P{s2LastRacePosition}\n"
                f"Points This Race: {s2LastRacePoints}\n"
                f"Total Season Points: {s2SeasonPoints}\n\n"
                f"Board Confidence (after this race): {int(boardConfidence)}%\n\n"
                f"Updated Budget: ${team['budget']:,}\n\n"
                "Press spacebar to continue."
            )
        
        text_42.setText(raceResultsMessage2)
        text_43.setText(s2AccidentMessage)
        
        text_42.setText(raceResultsMessage2)
        text_43.setText(s2AccidentMessage)
        # create starting attributes for key_resp_30
        key_resp_30.keys = []
        key_resp_30.rt = []
        _key_resp_30_allKeys = []
        # keep track of which components have finished
        RaceResultsS2Components = [text_42, text_43, key_resp_30]
        for thisComponent in RaceResultsS2Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "RaceResultsS2" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_42* updates
            
            # if text_42 is starting this frame...
            if text_42.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_42.frameNStart = frameN  # exact frame index
                text_42.tStart = t  # local t and not account for scr refresh
                text_42.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_42, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_42.started')
                # update status
                text_42.status = STARTED
                text_42.setAutoDraw(True)
            
            # if text_42 is active this frame...
            if text_42.status == STARTED:
                # update params
                pass
            
            # *text_43* updates
            
            # if text_43 is starting this frame...
            if text_43.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_43.frameNStart = frameN  # exact frame index
                text_43.tStart = t  # local t and not account for scr refresh
                text_43.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_43, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_43.started')
                # update status
                text_43.status = STARTED
                text_43.setAutoDraw(True)
            
            # if text_43 is active this frame...
            if text_43.status == STARTED:
                # update params
                pass
            
            # *key_resp_30* updates
            waitOnFlip = False
            
            # if key_resp_30 is starting this frame...
            if key_resp_30.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_30.frameNStart = frameN  # exact frame index
                key_resp_30.tStart = t  # local t and not account for scr refresh
                key_resp_30.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_30, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_30.started')
                # update status
                key_resp_30.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_30.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_30.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_30.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_30.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _key_resp_30_allKeys.extend(theseKeys)
                if len(_key_resp_30_allKeys):
                    key_resp_30.keys = _key_resp_30_allKeys[-1].name  # just the last key pressed
                    key_resp_30.rt = _key_resp_30_allKeys[-1].rt
                    key_resp_30.duration = _key_resp_30_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in RaceResultsS2Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "RaceResultsS2" ---
        for thisComponent in RaceResultsS2Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('RaceResultsS2.stopped', globalClock.getTime(format='float'))
        # Run 'End Routine' code from code_30
        if fired or bankrupt:
            thisExp.status = FINISHED
        
        # check responses
        if key_resp_30.keys in ['', [], None]:  # No response was made
            key_resp_30.keys = None
        trials_8.addData('key_resp_30.keys',key_resp_30.keys)
        if key_resp_30.keys != None:  # we had a response
            trials_8.addData('key_resp_30.rt', key_resp_30.rt)
            trials_8.addData('key_resp_30.duration', key_resp_30.duration)
        # the Routine "RaceResultsS2" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 2.0 repeats of 'trials_8'
    
    
    # --- Prepare to start Routine "devPause5" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('devPause5.started', globalClock.getTime(format='float'))
    # Run 'Begin Routine' code from code_32
    if fired or bankrupt:
        text_45.text = endReasonText
        continueRoutine = False
    else:
        costInfo = (
            f"\n\nEach development point costs ${devPointCost:,}.\n"
            "The total cost of the points you use at this stop "
            "will be subtracted from your budget.\n"
            f"Current budget before this stop: ${team['budget']:,}"
        )
        text_45.setText(text_45.text + costInfo)
    # create starting attributes for key_resp_32
    key_resp_32.keys = []
    key_resp_32.rt = []
    _key_resp_32_allKeys = []
    # keep track of which components have finished
    devPause5Components = [text_45, key_resp_32]
    for thisComponent in devPause5Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "devPause5" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        # Run 'Each Frame' code from code_32
        if key_resp_32.keys and 'return' in key_resp_32.keys:
            continueRoutine = False
        
        
        # *text_45* updates
        
        # if text_45 is starting this frame...
        if text_45.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_45.frameNStart = frameN  # exact frame index
            text_45.tStart = t  # local t and not account for scr refresh
            text_45.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_45, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_45.started')
            # update status
            text_45.status = STARTED
            text_45.setAutoDraw(True)
        
        # if text_45 is active this frame...
        if text_45.status == STARTED:
            # update params
            pass
        
        # *key_resp_32* updates
        waitOnFlip = False
        
        # if key_resp_32 is starting this frame...
        if key_resp_32.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_32.frameNStart = frameN  # exact frame index
            key_resp_32.tStart = t  # local t and not account for scr refresh
            key_resp_32.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_32, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp_32.started')
            # update status
            key_resp_32.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_32.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_32.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_32.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_32.getKeys(keyList=['a','b','c','d','e','return'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_32_allKeys.extend(theseKeys)
            if len(_key_resp_32_allKeys):
                key_resp_32.keys = [key.name for key in _key_resp_32_allKeys]  # storing all keys
                key_resp_32.rt = [key.rt for key in _key_resp_32_allKeys]
                key_resp_32.duration = [key.duration for key in _key_resp_32_allKeys]
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in devPause5Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "devPause5" ---
    for thisComponent in devPause5Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('devPause5.stopped', globalClock.getTime(format='float'))
    # Run 'End Routine' code from code_32
    keys = key_resp_32.keys or []
    
    letters = []
    for k in keys:
        if k != 'return':
            L = k.upper()
            if L in ['A','B','C','D','E']:
                letters.append(L)
        if len(letters) == 8:
            break
    
    fw = letters.count('A')
    rw = letters.count('B')
    ch = letters.count('C')
    uf = letters.count('D')
    en = letters.count('E')
    
    currentCarDev['frontWing']  += fw
    currentCarDev['rearWing']   += rw
    currentCarDev['chassis']    += ch
    currentCarDev['underfloor'] += uf
    currentCarDev['engine']     += en
    
    Dev5_pointsUsed = len(letters)
    totalCost5 = Dev5_pointsUsed * devPointCost
    team['budget'] -= totalCost5
    
    if team['budget'] < 0:
        bankrupt = True
        fired = True
        endReasonText = "GAME OVER\nYou went over budget.\nPress spacebar to end."
    
    thisExp.addData('DevStop5_letters_raw', letters)
    thisExp.addData('DevStop5_pointsUsed', Dev5_pointsUsed)
    thisExp.addData('DevStop5_fw_added', Dev5_fw)
    thisExp.addData('DevStop5_rw_added', Dev5_rw)
    thisExp.addData('DevStop5_ch_added', Dev5_ch)
    thisExp.addData('DevStop5_uf_added', Dev5_uf)
    thisExp.addData('DevStop5_en_added', Dev5_en)
    thisExp.addData('DevStop5_currentDev_frontWing_total', currentCarDev['frontWing'])
    thisExp.addData('DevStop5_currentDev_rearWing_total', currentCarDev['rearWing'])
    thisExp.addData('DevStop5_currentDev_chassis_total', currentCarDev['chassis'])
    thisExp.addData('DevStop5_currentDev_underfloor_total', currentCarDev['underfloor'])
    thisExp.addData('DevStop5_currentDev_engine_total', currentCarDev['engine'])
    thisExp.addData('DevStop5_totalDevCost', totalCost5)
    thisExp.addData('DevStop5_budget_after_cost', team['budget'])
    # check responses
    if key_resp_32.keys in ['', [], None]:  # No response was made
        key_resp_32.keys = None
    thisExp.addData('key_resp_32.keys',key_resp_32.keys)
    if key_resp_32.keys != None:  # we had a response
        thisExp.addData('key_resp_32.rt', key_resp_32.rt)
        thisExp.addData('key_resp_32.duration', key_resp_32.duration)
    thisExp.nextEntry()
    # the Routine "devPause5" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    trials_9 = data.TrialHandler(nReps=2.0, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='trials_9')
    thisExp.addLoop(trials_9)  # add the loop to the experiment
    thisTrial_9 = trials_9.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_9.rgb)
    if thisTrial_9 != None:
        for paramName in thisTrial_9:
            globals()[paramName] = thisTrial_9[paramName]
    
    for thisTrial_9 in trials_9:
        currentLoop = trials_9
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_9.rgb)
        if thisTrial_9 != None:
            for paramName in thisTrial_9:
                globals()[paramName] = thisTrial_9[paramName]
        
        # --- Prepare to start Routine "RaceS2Pt3" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('RaceS2Pt3.started', globalClock.getTime(format='float'))
        # Run 'Begin Routine' code from code_28
        raceIndexS2 = raceIndexS2 + 1 
        
        raceMessage = (
            "Season 2 – Race " + str(raceIndexS2) + "\n\n"
            "Team: " + team['name'] + "\n"
            "Budget: $" + str(team['budget']) + "\n\n"
            "Development levels (this season):\n"
            "  Front wing: " + str(currentCarDev['frontWing']) + "\n"
            "  Rear wing: " + str(currentCarDev['rearWing']) + "\n"
            "  Chassis: " + str(currentCarDev['chassis']) + "\n"
            "  Underfloor: " + str(currentCarDev['underfloor']) + "\n"
            "  Engine: " + str(currentCarDev['engine']) + "\n\n"
            "Next-season research level: " + str(nextYearCarDev) + "\n\n"
            "Press the spacebar to simulate this race."
        )
        
        text_40.setText(raceMessage)
        
        
        # create starting attributes for key_resp_28
        key_resp_28.keys = []
        key_resp_28.rt = []
        _key_resp_28_allKeys = []
        text_40.setText(raceMessage)
        # keep track of which components have finished
        RaceS2Pt3Components = [key_resp_28, text_40]
        for thisComponent in RaceS2Pt3Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "RaceS2Pt3" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            # Run 'Each Frame' code from code_28
            if 'space' in key_resp_28.keys:
                continueRoutine = False
            
            
            # *key_resp_28* updates
            waitOnFlip = False
            
            # if key_resp_28 is starting this frame...
            if key_resp_28.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_28.frameNStart = frameN  # exact frame index
                key_resp_28.tStart = t  # local t and not account for scr refresh
                key_resp_28.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_28, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_28.started')
                # update status
                key_resp_28.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_28.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_28.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_28.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_28.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _key_resp_28_allKeys.extend(theseKeys)
                if len(_key_resp_28_allKeys):
                    key_resp_28.keys = _key_resp_28_allKeys[-1].name  # just the last key pressed
                    key_resp_28.rt = _key_resp_28_allKeys[-1].rt
                    key_resp_28.duration = _key_resp_28_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # *text_40* updates
            
            # if text_40 is starting this frame...
            if text_40.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_40.frameNStart = frameN  # exact frame index
                text_40.tStart = t  # local t and not account for scr refresh
                text_40.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_40, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_40.started')
                # update status
                text_40.status = STARTED
                text_40.setAutoDraw(True)
            
            # if text_40 is active this frame...
            if text_40.status == STARTED:
                # update params
                pass
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in RaceS2Pt3Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "RaceS2Pt3" ---
        for thisComponent in RaceS2Pt3Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('RaceS2Pt3.stopped', globalClock.getTime(format='float'))
        # Run 'End Routine' code from code_28
        import random
        
        devTotal = (
            currentCarDev['frontWing'] +
            currentCarDev['rearWing'] +
            currentCarDev['chassis'] +
            currentCarDev['underfloor'] +
            currentCarDev['engine']
        )
        
        devBonus = devTotal * 2.0 
        teamScore = driverPerf + carPerf + devBonus 
        
        driverExp = team['driverRatings']['Experience']
        
        carStats = [
            currentCarDev['frontWing'],
            currentCarDev['rearWing'],
            currentCarDev['chassis'],
            currentCarDev['underfloor'],
            currentCarDev['engine']
        ]
        carAvg = sum(carStats) / len(carStats)
        
        finishScore = (driverExp + carAvg) / 2.0
        
        roll = random.uniform(0, 100)
        
        crashed = False
        s2AccidentMessage = "No accident"
        s2RepairCost = 0
        
        if roll > finishScore:
            crashed = True
            position = 20
            racePoints = 0
            s2LastRacePosition = "DNF"
            s2LastRacePoints = 0
        
            if driverExp < carAvg:
                s2RepairCost = 1000000
                s2AccidentMessage = f"The driver crashed. Cost: ${s2RepairCost:,}"
            else:
                s2RepairCost = 300000 
                s2AccidentMessage = f"The car broke. Cost: ${s2RepairCost:,}"
            team['budget'] -= s2RepairCost
        
        if crashed:
            position = 20
        
        if team['budget'] < 0:
            bankrupt = True
            fired = True
            endReasonText = "GAME OVER\nYou went over budget.\nPress spacebar to close."
        
        thisExp.addData('s2AccidentMessage', s2AccidentMessage)
        thisExp.addData('s2RepairCost', s2RepairCost)
        
        if not crashed:
            aiScores = []
            for i in range(19):
                aiScore = random.uniform(0, 100)
                aiScores.append(aiScore)
        
            allScores = aiScores + [teamScore]
            sortedScores = sorted(allScores, reverse=True)
        
            position = sortedScores.index(teamScore) + 1  # 1 = P1
        
            pointsTable = {
                1: 25, 2: 18, 3: 15, 4: 12, 5: 10,
                6: 8, 7: 6, 8: 4, 9: 2, 10: 1
            }
        
            racePoints = pointsTable.get(position, 0)
        
            s2SeasonPoints += racePoints
        
            s2LastRacePosition = position
            s2LastRacePoints = racePoints
        
        if boardPressure == "1":  
            winBoost = 8
            midPenalty = -5
            crashPenalty = -25
        else: 
            winBoost = 4
            midPenalty = -2
            crashPenalty = -12
        
        change = 0
        
        if crashed:
            change = crashPenalty
        elif position <= 5:
            change = winBoost
        else:
            change = midPenalty
        
        boardConfidence = boardConfidence + change
        
        if boardConfidence > 100:
            boardConfidence = 100
        if boardConfidence < 0:
            boardConfidence = 0
        
        if boardConfidence <= firingThreshold:
            fired = True
        
        thisExp.addData('boardConfidence', boardConfidence)
        thisExp.addData('boardPressureCondition', boardPressure)
        thisExp.addData('s2RaceIndex', raceIndexS2)
        thisExp.addData('s2Position', s2LastRacePosition)
        thisExp.addData('s2RacePoints', s2LastRacePoints)
        thisExp.addData('s2SeasonPoints_total', s2SeasonPoints)
        thisExp.addData('s2BudgetAfterRace', team['budget'])
        
        # check responses
        if key_resp_28.keys in ['', [], None]:  # No response was made
            key_resp_28.keys = None
        trials_9.addData('key_resp_28.keys',key_resp_28.keys)
        if key_resp_28.keys != None:  # we had a response
            trials_9.addData('key_resp_28.rt', key_resp_28.rt)
            trials_9.addData('key_resp_28.duration', key_resp_28.duration)
        # the Routine "RaceS2Pt3" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "RaceResultsS2" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('RaceResultsS2.started', globalClock.getTime(format='float'))
        # Run 'Begin Routine' code from code_30
        if fired or bankrupt:
            raceResultsMessage2 = (
                "GAME OVER\n"
                "You have been fired.\n\n"
                "Press spacebar to end the study."
            )
            s2AccidentMessage = ""
        else:
            raceResultsMessage2 = (
                f"Season 2 – Race {raceIndexS2}\n\n"
                f"Final Position: P{s2LastRacePosition}\n"
                f"Points This Race: {s2LastRacePoints}\n"
                f"Total Season Points: {s2SeasonPoints}\n\n"
                f"Board Confidence (after this race): {int(boardConfidence)}%\n\n"
                f"Updated Budget: ${team['budget']:,}\n\n"
                "Press spacebar to continue."
            )
        
        text_42.setText(raceResultsMessage2)
        text_43.setText(s2AccidentMessage)
        
        text_42.setText(raceResultsMessage2)
        text_43.setText(s2AccidentMessage)
        # create starting attributes for key_resp_30
        key_resp_30.keys = []
        key_resp_30.rt = []
        _key_resp_30_allKeys = []
        # keep track of which components have finished
        RaceResultsS2Components = [text_42, text_43, key_resp_30]
        for thisComponent in RaceResultsS2Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "RaceResultsS2" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_42* updates
            
            # if text_42 is starting this frame...
            if text_42.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_42.frameNStart = frameN  # exact frame index
                text_42.tStart = t  # local t and not account for scr refresh
                text_42.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_42, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_42.started')
                # update status
                text_42.status = STARTED
                text_42.setAutoDraw(True)
            
            # if text_42 is active this frame...
            if text_42.status == STARTED:
                # update params
                pass
            
            # *text_43* updates
            
            # if text_43 is starting this frame...
            if text_43.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_43.frameNStart = frameN  # exact frame index
                text_43.tStart = t  # local t and not account for scr refresh
                text_43.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_43, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_43.started')
                # update status
                text_43.status = STARTED
                text_43.setAutoDraw(True)
            
            # if text_43 is active this frame...
            if text_43.status == STARTED:
                # update params
                pass
            
            # *key_resp_30* updates
            waitOnFlip = False
            
            # if key_resp_30 is starting this frame...
            if key_resp_30.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_30.frameNStart = frameN  # exact frame index
                key_resp_30.tStart = t  # local t and not account for scr refresh
                key_resp_30.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_30, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_30.started')
                # update status
                key_resp_30.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_30.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_30.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_30.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_30.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _key_resp_30_allKeys.extend(theseKeys)
                if len(_key_resp_30_allKeys):
                    key_resp_30.keys = _key_resp_30_allKeys[-1].name  # just the last key pressed
                    key_resp_30.rt = _key_resp_30_allKeys[-1].rt
                    key_resp_30.duration = _key_resp_30_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in RaceResultsS2Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "RaceResultsS2" ---
        for thisComponent in RaceResultsS2Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('RaceResultsS2.stopped', globalClock.getTime(format='float'))
        # Run 'End Routine' code from code_30
        if fired or bankrupt:
            thisExp.status = FINISHED
        
        # check responses
        if key_resp_30.keys in ['', [], None]:  # No response was made
            key_resp_30.keys = None
        trials_9.addData('key_resp_30.keys',key_resp_30.keys)
        if key_resp_30.keys != None:  # we had a response
            trials_9.addData('key_resp_30.rt', key_resp_30.rt)
            trials_9.addData('key_resp_30.duration', key_resp_30.duration)
        # the Routine "RaceResultsS2" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 2.0 repeats of 'trials_9'
    
    
    # --- Prepare to start Routine "devPause6" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('devPause6.started', globalClock.getTime(format='float'))
    # Run 'Begin Routine' code from code_33
    if fired or bankrupt:
        text_46.text = endReasonText
        continueRoutine = False
    else:
        costInfo = (
            f"\n\nEach development point costs ${devPointCost:,}.\n"
            "The total cost of the points you use at this stop "
            "will be subtracted from your budget.\n"
            f"Current budget before this stop: ${team['budget']:,}"
        )
        text_46.setText(text_46.text + costInfo)
    # create starting attributes for key_resp_33
    key_resp_33.keys = []
    key_resp_33.rt = []
    _key_resp_33_allKeys = []
    # keep track of which components have finished
    devPause6Components = [key_resp_33, text_46]
    for thisComponent in devPause6Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "devPause6" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        # Run 'Each Frame' code from code_33
        if key_resp_33.keys and 'return' in key_resp_33.keys:
            continueRoutine = False
        
        # *key_resp_33* updates
        waitOnFlip = False
        
        # if key_resp_33 is starting this frame...
        if key_resp_33.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_33.frameNStart = frameN  # exact frame index
            key_resp_33.tStart = t  # local t and not account for scr refresh
            key_resp_33.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_33, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp_33.started')
            # update status
            key_resp_33.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_33.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_33.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_33.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_33.getKeys(keyList=['a','b','c','d','e','return'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_33_allKeys.extend(theseKeys)
            if len(_key_resp_33_allKeys):
                key_resp_33.keys = _key_resp_33_allKeys[-1].name  # just the last key pressed
                key_resp_33.rt = _key_resp_33_allKeys[-1].rt
                key_resp_33.duration = _key_resp_33_allKeys[-1].duration
        
        # *text_46* updates
        
        # if text_46 is starting this frame...
        if text_46.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_46.frameNStart = frameN  # exact frame index
            text_46.tStart = t  # local t and not account for scr refresh
            text_46.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_46, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_46.started')
            # update status
            text_46.status = STARTED
            text_46.setAutoDraw(True)
        
        # if text_46 is active this frame...
        if text_46.status == STARTED:
            # update params
            pass
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in devPause6Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "devPause6" ---
    for thisComponent in devPause6Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('devPause6.stopped', globalClock.getTime(format='float'))
    # Run 'End Routine' code from code_33
    keys = key_resp_33.keys or []
    
    letters = []
    for k in keys:
        if k != 'return':
            L = k.upper()
            if L in ['A','B','C','D','E']:
                letters.append(L)
        if len(letters) == 8:
            break
    
    fw = letters.count('A')
    rw = letters.count('B')
    ch = letters.count('C')
    uf = letters.count('D')
    en = letters.count('E')
    
    currentCarDev['frontWing']  += fw
    currentCarDev['rearWing']   += rw
    currentCarDev['chassis']    += ch
    currentCarDev['underfloor'] += uf
    currentCarDev['engine']     += en
    
    Dev6_pointsUsed = len(letters)
    totalCost6 = Dev6_pointsUsed * devPointCost
    team['budget'] -= totalCost6
    
    if team['budget'] < 0:
        bankrupt = True
        fired = True
        endReasonText = "GAME OVER\nYou went over budget.\nPress spacebar to end."
    
    thisExp.addData('DevStop6_letters_raw', letters)
    thisExp.addData('DevStop6_pointsUsed', Dev6_pointsUsed)
    thisExp.addData('DevStop6_fw_added', Dev6_fw)
    thisExp.addData('DevStop6_rw_added', Dev6_rw)
    thisExp.addData('DevStop6_ch_added', Dev6_ch)
    thisExp.addData('DevStop6_uf_added', Dev6_uf)
    thisExp.addData('DevStop6_en_added', Dev6_en)
    thisExp.addData('DevStop6_currentDev_frontWing_total', currentCarDev['frontWing'])
    thisExp.addData('DevStop6_currentDev_rearWing_total', currentCarDev['rearWing'])
    thisExp.addData('DevStop6_currentDev_chassis_total', currentCarDev['chassis'])
    thisExp.addData('DevStop6_currentDev_underfloor_total', currentCarDev['underfloor'])
    thisExp.addData('DevStop6_currentDev_engine_total', currentCarDev['engine'])
    thisExp.addData('DevStop6_totalDevCost', totalCost6)
    thisExp.addData('DevStop6_budget_after_cost', team['budget'])
    # check responses
    if key_resp_33.keys in ['', [], None]:  # No response was made
        key_resp_33.keys = None
    thisExp.addData('key_resp_33.keys',key_resp_33.keys)
    if key_resp_33.keys != None:  # we had a response
        thisExp.addData('key_resp_33.rt', key_resp_33.rt)
        thisExp.addData('key_resp_33.duration', key_resp_33.duration)
    thisExp.nextEntry()
    # the Routine "devPause6" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    trials_10 = data.TrialHandler(nReps=4.0, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='trials_10')
    thisExp.addLoop(trials_10)  # add the loop to the experiment
    thisTrial_10 = trials_10.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_10.rgb)
    if thisTrial_10 != None:
        for paramName in thisTrial_10:
            globals()[paramName] = thisTrial_10[paramName]
    
    for thisTrial_10 in trials_10:
        currentLoop = trials_10
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
        )
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_10.rgb)
        if thisTrial_10 != None:
            for paramName in thisTrial_10:
                globals()[paramName] = thisTrial_10[paramName]
        
        # --- Prepare to start Routine "RaceS2Pt4" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('RaceS2Pt4.started', globalClock.getTime(format='float'))
        # Run 'Begin Routine' code from code_29
        raceIndexS2 = raceIndexS2 + 1
        
        raceMessage = (
            "Season 2 – Race " + str(raceIndexS2) + "\n\n"
            "Team: " + team['name'] + "\n"
            "Budget: $" + str(team['budget']) + "\n\n"
            "Development levels (this season):\n"
            "  Front wing: " + str(currentCarDev['frontWing']) + "\n"
            "  Rear wing: " + str(currentCarDev['rearWing']) + "\n"
            "  Chassis: " + str(currentCarDev['chassis']) + "\n"
            "  Underfloor: " + str(currentCarDev['underfloor']) + "\n"
            "  Engine: " + str(currentCarDev['engine']) + "\n\n"
            "Next-season research level: " + str(nextYearCarDev) + "\n\n"
            "Press the spacebar to simulate this race."
        )
        
        text_41.setText(raceMessage)
        
        
        # create starting attributes for key_resp_29
        key_resp_29.keys = []
        key_resp_29.rt = []
        _key_resp_29_allKeys = []
        text_41.setText(raceMessage)
        # keep track of which components have finished
        RaceS2Pt4Components = [key_resp_29, text_41]
        for thisComponent in RaceS2Pt4Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "RaceS2Pt4" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            # Run 'Each Frame' code from code_29
            if 'space' in key_resp_29.keys:
                continueRoutine = False
            
            
            # *key_resp_29* updates
            waitOnFlip = False
            
            # if key_resp_29 is starting this frame...
            if key_resp_29.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_29.frameNStart = frameN  # exact frame index
                key_resp_29.tStart = t  # local t and not account for scr refresh
                key_resp_29.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_29, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_29.started')
                # update status
                key_resp_29.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_29.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_29.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_29.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_29.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _key_resp_29_allKeys.extend(theseKeys)
                if len(_key_resp_29_allKeys):
                    key_resp_29.keys = _key_resp_29_allKeys[-1].name  # just the last key pressed
                    key_resp_29.rt = _key_resp_29_allKeys[-1].rt
                    key_resp_29.duration = _key_resp_29_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # *text_41* updates
            
            # if text_41 is starting this frame...
            if text_41.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_41.frameNStart = frameN  # exact frame index
                text_41.tStart = t  # local t and not account for scr refresh
                text_41.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_41, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_41.started')
                # update status
                text_41.status = STARTED
                text_41.setAutoDraw(True)
            
            # if text_41 is active this frame...
            if text_41.status == STARTED:
                # update params
                pass
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in RaceS2Pt4Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "RaceS2Pt4" ---
        for thisComponent in RaceS2Pt4Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('RaceS2Pt4.stopped', globalClock.getTime(format='float'))
        # Run 'End Routine' code from code_29
        import random
        
        devTotal = (
            currentCarDev['frontWing'] +
            currentCarDev['rearWing'] +
            currentCarDev['chassis'] +
            currentCarDev['underfloor'] +
            currentCarDev['engine']
        )
        
        devBonus = devTotal * 2.0 
        teamScore = driverPerf + carPerf + devBonus 
        
        driverExp = team['driverRatings']['Experience']
        
        carStats = [
            currentCarDev['frontWing'],
            currentCarDev['rearWing'],
            currentCarDev['chassis'],
            currentCarDev['underfloor'],
            currentCarDev['engine']
        ]
        carAvg = sum(carStats) / len(carStats)
        
        finishScore = (driverExp + carAvg) / 2.0
        
        roll = random.uniform(0, 100)
        
        crashed = False
        s2AccidentMessage = "No accident"
        s2RepairCost = 0
        
        if roll > finishScore:
            crashed = True
            position = 20
            racePoints = 0
            s2LastRacePosition = "DNF"
            s2LastRacePoints = 0
        
            if driverExp < carAvg:
                s2RepairCost = 1000000
                s2AccidentMessage = f"The driver crashed. Cost: ${s2RepairCost:,}"
        
            else:
                s2RepairCost = 300000 
                s2AccidentMessage = f"The car broke. Cost: ${s2RepairCost:,}"
            team['budget'] -= s2RepairCost
        
        if crashed:
            position = 20
        
        if team['budget'] < 0:
            bankrupt = True
            fired = True
            endReasonText = "GAME OVER\nYou went over budget.\nPress spacebar to close."
        
        thisExp.addData('s2AccidentMessage', s2AccidentMessage)
        thisExp.addData('s2RepairCost', s2RepairCost)
        
        if not crashed:
            aiScores = []
            for i in range(19):
                aiScore = random.uniform(0, 100)
                aiScores.append(aiScore)
        
            allScores = aiScores + [teamScore]
            sortedScores = sorted(allScores, reverse=True)
        
            position = sortedScores.index(teamScore) + 1  # 1 = P1
        
            pointsTable = {
                1: 25, 2: 18, 3: 15, 4: 12, 5: 10,
                6: 8, 7: 6, 8: 4, 9: 2, 10: 1
            }
        
            racePoints = pointsTable.get(position, 0)
        
            s2SeasonPoints += racePoints
        
            s2LastRacePosition = position
            s2LastRacePoints = racePoints
        
        if boardPressure == "1":  
            winBoost = 8
            midPenalty = -5
            crashPenalty = -25
        else: 
            winBoost = 4
            midPenalty = -2
            crashPenalty = -12
        
        change = 0
        
        if crashed:
            change = crashPenalty
        elif position <= 5:
            change = winBoost
        else:
            change = midPenalty
        
        boardConfidence = boardConfidence + change
        
        if boardConfidence > 100:
            boardConfidence = 100
        if boardConfidence < 0:
            boardConfidence = 0
        
        if boardConfidence <= firingThreshold:
            fired = True
        
        thisExp.addData('boardConfidence', boardConfidence)
        thisExp.addData('boardPressureCondition', boardPressure)
        thisExp.addData('s2RaceIndex', raceIndexS2)
        thisExp.addData('s2Position', s2LastRacePosition)
        thisExp.addData('s2RacePoints', s2LastRacePoints)
        thisExp.addData('s2SeasonPoints_total', s2SeasonPoints)
        thisExp.addData('s2BudgetAfterRace', team['budget'])
        
        # check responses
        if key_resp_29.keys in ['', [], None]:  # No response was made
            key_resp_29.keys = None
        trials_10.addData('key_resp_29.keys',key_resp_29.keys)
        if key_resp_29.keys != None:  # we had a response
            trials_10.addData('key_resp_29.rt', key_resp_29.rt)
            trials_10.addData('key_resp_29.duration', key_resp_29.duration)
        # the Routine "RaceS2Pt4" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "RaceResultsS2" ---
        continueRoutine = True
        # update component parameters for each repeat
        thisExp.addData('RaceResultsS2.started', globalClock.getTime(format='float'))
        # Run 'Begin Routine' code from code_30
        if fired or bankrupt:
            raceResultsMessage2 = (
                "GAME OVER\n"
                "You have been fired.\n\n"
                "Press spacebar to end the study."
            )
            s2AccidentMessage = ""
        else:
            raceResultsMessage2 = (
                f"Season 2 – Race {raceIndexS2}\n\n"
                f"Final Position: P{s2LastRacePosition}\n"
                f"Points This Race: {s2LastRacePoints}\n"
                f"Total Season Points: {s2SeasonPoints}\n\n"
                f"Board Confidence (after this race): {int(boardConfidence)}%\n\n"
                f"Updated Budget: ${team['budget']:,}\n\n"
                "Press spacebar to continue."
            )
        
        text_42.setText(raceResultsMessage2)
        text_43.setText(s2AccidentMessage)
        
        text_42.setText(raceResultsMessage2)
        text_43.setText(s2AccidentMessage)
        # create starting attributes for key_resp_30
        key_resp_30.keys = []
        key_resp_30.rt = []
        _key_resp_30_allKeys = []
        # keep track of which components have finished
        RaceResultsS2Components = [text_42, text_43, key_resp_30]
        for thisComponent in RaceResultsS2Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "RaceResultsS2" ---
        routineForceEnded = not continueRoutine
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_42* updates
            
            # if text_42 is starting this frame...
            if text_42.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_42.frameNStart = frameN  # exact frame index
                text_42.tStart = t  # local t and not account for scr refresh
                text_42.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_42, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_42.started')
                # update status
                text_42.status = STARTED
                text_42.setAutoDraw(True)
            
            # if text_42 is active this frame...
            if text_42.status == STARTED:
                # update params
                pass
            
            # *text_43* updates
            
            # if text_43 is starting this frame...
            if text_43.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_43.frameNStart = frameN  # exact frame index
                text_43.tStart = t  # local t and not account for scr refresh
                text_43.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_43, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_43.started')
                # update status
                text_43.status = STARTED
                text_43.setAutoDraw(True)
            
            # if text_43 is active this frame...
            if text_43.status == STARTED:
                # update params
                pass
            
            # *key_resp_30* updates
            waitOnFlip = False
            
            # if key_resp_30 is starting this frame...
            if key_resp_30.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_30.frameNStart = frameN  # exact frame index
                key_resp_30.tStart = t  # local t and not account for scr refresh
                key_resp_30.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_30, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_30.started')
                # update status
                key_resp_30.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_30.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_30.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_30.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_30.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _key_resp_30_allKeys.extend(theseKeys)
                if len(_key_resp_30_allKeys):
                    key_resp_30.keys = _key_resp_30_allKeys[-1].name  # just the last key pressed
                    key_resp_30.rt = _key_resp_30_allKeys[-1].rt
                    key_resp_30.duration = _key_resp_30_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in RaceResultsS2Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "RaceResultsS2" ---
        for thisComponent in RaceResultsS2Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        thisExp.addData('RaceResultsS2.stopped', globalClock.getTime(format='float'))
        # Run 'End Routine' code from code_30
        if fired or bankrupt:
            thisExp.status = FINISHED
        
        # check responses
        if key_resp_30.keys in ['', [], None]:  # No response was made
            key_resp_30.keys = None
        trials_10.addData('key_resp_30.keys',key_resp_30.keys)
        if key_resp_30.keys != None:  # we had a response
            trials_10.addData('key_resp_30.rt', key_resp_30.rt)
            trials_10.addData('key_resp_30.duration', key_resp_30.duration)
        # the Routine "RaceResultsS2" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
    # completed 4.0 repeats of 'trials_10'
    
    
    # --- Prepare to start Routine "season2Summary" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('season2Summary.started', globalClock.getTime(format='float'))
    # Run 'Begin Routine' code from code_35
    season2SummaryMessage = ( # summary of season
        "SEASON 2 SUMMARY\n\n"
        f"Final Race Position: P{s2LastRacePosition}\n"
        f"Last Race Points: {s2LastRacePoints}\n"
        f"Total Season Points: {s2SeasonPoints}\n\n"
        f"Board Confidence: {int(boardConfidence)}%\n"
        f"Final Budget: ${team['budget']:,}\n\n"
        "Press spacebar to continue."
    )
    # display message
    text_48.text = season2SummaryMessage
    
    # create starting attributes for key_resp_35
    key_resp_35.keys = []
    key_resp_35.rt = []
    _key_resp_35_allKeys = []
    text_48.setText(season2SummaryMessage)
    # keep track of which components have finished
    season2SummaryComponents = [key_resp_35, text_48]
    for thisComponent in season2SummaryComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "season2Summary" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *key_resp_35* updates
        waitOnFlip = False
        
        # if key_resp_35 is starting this frame...
        if key_resp_35.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_35.frameNStart = frameN  # exact frame index
            key_resp_35.tStart = t  # local t and not account for scr refresh
            key_resp_35.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_35, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp_35.started')
            # update status
            key_resp_35.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_35.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_35.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_35.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_35.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_35_allKeys.extend(theseKeys)
            if len(_key_resp_35_allKeys):
                key_resp_35.keys = _key_resp_35_allKeys[-1].name  # just the last key pressed
                key_resp_35.rt = _key_resp_35_allKeys[-1].rt
                key_resp_35.duration = _key_resp_35_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # *text_48* updates
        
        # if text_48 is starting this frame...
        if text_48.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_48.frameNStart = frameN  # exact frame index
            text_48.tStart = t  # local t and not account for scr refresh
            text_48.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_48, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_48.started')
            # update status
            text_48.status = STARTED
            text_48.setAutoDraw(True)
        
        # if text_48 is active this frame...
        if text_48.status == STARTED:
            # update params
            pass
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in season2SummaryComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "season2Summary" ---
    for thisComponent in season2SummaryComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('season2Summary.stopped', globalClock.getTime(format='float'))
    # check responses
    if key_resp_35.keys in ['', [], None]:  # No response was made
        key_resp_35.keys = None
    thisExp.addData('key_resp_35.keys',key_resp_35.keys)
    if key_resp_35.keys != None:  # we had a response
        thisExp.addData('key_resp_35.rt', key_resp_35.rt)
        thisExp.addData('key_resp_35.duration', key_resp_35.duration)
    thisExp.nextEntry()
    # the Routine "season2Summary" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "conclusion" ---
    continueRoutine = True
    # update component parameters for each repeat
    thisExp.addData('conclusion.started', globalClock.getTime(format='float'))
    # keep track of which components have finished
    conclusionComponents = [text]
    for thisComponent in conclusionComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "conclusion" ---
    routineForceEnded = not continueRoutine
    while continueRoutine and routineTimer.getTime() < 4.0:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text* updates
        
        # if text is starting this frame...
        if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text.frameNStart = frameN  # exact frame index
            text.tStart = t  # local t and not account for scr refresh
            text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text.started')
            # update status
            text.status = STARTED
            text.setAutoDraw(True)
        
        # if text is active this frame...
        if text.status == STARTED:
            # update params
            pass
        
        # if text is stopping this frame...
        if text.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text.tStartRefresh + 4.0-frameTolerance:
                # keep track of stop time/frame for later
                text.tStop = t  # not accounting for scr refresh
                text.tStopRefresh = tThisFlipGlobal  # on global time
                text.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text.stopped')
                # update status
                text.status = FINISHED
                text.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in conclusionComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "conclusion" ---
    for thisComponent in conclusionComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.addData('conclusion.stopped', globalClock.getTime(format='float'))
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if routineForceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-4.000000)
    thisExp.nextEntry()
    
    # mark experiment as finished
    endExperiment(thisExp, win=win)


def saveData(thisExp):
    """
    Save data from this experiment
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    filename = thisExp.dataFileName
    # these shouldn't be strictly necessary (should auto-save)
    thisExp.saveAsWideText(filename + '.csv', delim='auto')
    thisExp.saveAsPickle(filename)


def endExperiment(thisExp, win=None):
    """
    End this experiment, performing final shut down operations.
    
    This function does NOT close the window or end the Python process - use `quit` for this.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    """
    if win is not None:
        # remove autodraw from all current components
        win.clearAutoDraw()
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed
        win.flip()
    # mark experiment handler as finished
    thisExp.status = FINISHED
    # shut down eyetracker, if there is one
    if deviceManager.getDevice('eyetracker') is not None:
        deviceManager.removeDevice('eyetracker')
    logging.flush()


def quit(thisExp, win=None, thisSession=None):
    """
    Fully quit, closing the window and ending the Python process.
    
    Parameters
    ==========
    win : psychopy.visual.Window
        Window to close.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    thisExp.abort()  # or data files will save again on exit
    # make sure everything is closed down
    if win is not None:
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed before quitting
        win.flip()
        win.close()
    # shut down eyetracker, if there is one
    if deviceManager.getDevice('eyetracker') is not None:
        deviceManager.removeDevice('eyetracker')
    logging.flush()
    if thisSession is not None:
        thisSession.stop()
    # terminate Python process
    core.quit()


# if running this experiment as a script...
if __name__ == '__main__':
    # call all functions in order
    expInfo = showExpInfoDlg(expInfo=expInfo)
    thisExp = setupData(expInfo=expInfo)
    logFile = setupLogging(filename=thisExp.dataFileName)
    win = setupWindow(expInfo=expInfo)
    setupDevices(expInfo=expInfo, thisExp=thisExp, win=win)
    run(
        expInfo=expInfo, 
        thisExp=thisExp, 
        win=win,
        globalClock='float'
    )
    saveData(thisExp=thisExp)
    quit(thisExp=thisExp, win=win)
